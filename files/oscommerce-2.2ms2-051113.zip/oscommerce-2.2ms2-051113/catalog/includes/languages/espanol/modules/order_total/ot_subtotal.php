<?php
/*
  $Id: ot_subtotal.php,v 1.2 2002/11/19 01:03:17 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SUBTOTAL_TITLE', 'Subtotal');
  define('MODULE_ORDER_TOTAL_SUBTOTAL_DESCRIPTION', 'Subtotal del Pedido');
?>
