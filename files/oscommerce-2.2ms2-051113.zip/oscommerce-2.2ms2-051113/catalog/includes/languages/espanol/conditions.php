<?php
/*
  $Id: conditions.php,v 1.4 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Condiciones de Uso');
define('HEADING_TITLE', 'Condiciones de Uso');

define('TEXT_INFORMATION', 'Ponga aqui sus condiciones de uso.');
?>
