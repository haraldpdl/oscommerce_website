<?
  if (!defined($include_file . '__')) {
    define($include_file . '__', 1);
	include($include_file);
  }
?>