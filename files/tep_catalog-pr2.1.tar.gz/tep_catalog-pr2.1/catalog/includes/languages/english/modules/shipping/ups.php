<?
  /* $Id */
  define('SHIPPING_UPS_NAME', 'United Parcel Service');
  define('SHIPPING_UPS_OPT_GND', 'UPS Ground');
  define('SHIPPING_UPS_OPT_1DM', 'Next Day Air Early AM');
  define('SHIPPING_UPS_OPT_1DA', 'Next Day Air');
  define('SHIPPING_UPS_OPT_1DP', 'Next Day Air Saver');
  define('SHIPPING_UPS_OPT_2DM', '2nd Day Air Early AM');
  define('SHIPPING_UPS_OPT_3DS', '3 Day Select');
  define('SHIPPING_UPS_OPT_STD', 'Canada Standard');
  define('SHIPPING_UPS_OPT_XPR', 'Worldwide Express');
  define('SHIPPING_UPS_OPT_XDM', 'Worldwide Express Plus');
  define('SHIPPING_UPS_OPT_XPD', 'Worldwide Expedited');
?>
