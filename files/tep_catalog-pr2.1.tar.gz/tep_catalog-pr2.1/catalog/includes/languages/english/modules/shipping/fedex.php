<?php
	/* $Id: fedex.php,v 1.2 2001/02/07 21:04:31 pkellum Exp $ */
	define('SHIPPING_FEDEX_NAME', 'Federal Express Ground'); // It's a trademark, can't translate
	define('SHIPPING_FEDEX_NOTAVAILABLE', 'The requested service is unavailable between the selected locations.');
?>