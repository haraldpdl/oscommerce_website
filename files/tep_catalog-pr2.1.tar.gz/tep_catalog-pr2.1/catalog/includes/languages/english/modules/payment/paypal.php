<?
  define('TEXT_PAYPAL', 'PayPal');
?>