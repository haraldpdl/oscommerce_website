<?
  define('TEXT_CREDIT_CARD', 'Credit Card');
  define('TEXT_CREDIT_CARD_OWNER', 'Credit Card Owner:');
  define('TEXT_CREDIT_CARD_NUMBER', 'Credit Card Number:');
  define('TEXT_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('JS_CC_OWNER', '* The owner\'s name of the credit card must be atleast ' . CC_OWNER_MIN_LENGTH . ' characters.\n');
  define('JS_CC_NUMBER', '* The credit card number must be atleast ' . CC_NUMBER_MIN_LENGTH . ' characters.\n');
?>