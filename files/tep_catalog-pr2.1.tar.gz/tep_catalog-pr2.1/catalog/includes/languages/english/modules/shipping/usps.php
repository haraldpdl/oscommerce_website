<?
  /* $Id */
  define('SHIPPING_USPS_NAME', 'United States Postal Service');
  define('SHIPPING_USPS_OPT_PP', 'Parcel Post');
  define('SHIPPING_USPS_OPT_PM', 'Priority Mail');
  define('SHIPPING_USPS_OPT_EX', 'Express Mail');
?>
