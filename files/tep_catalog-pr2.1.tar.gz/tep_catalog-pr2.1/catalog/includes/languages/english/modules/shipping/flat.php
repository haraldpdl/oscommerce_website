<?
  /* $Id */
  // define('SHIPPING_FLAT_COST', '5.00'); // This is in DB
  define('SHIPPING_FLAT_NAME', 'Flat Rate');
  define('SHIPPING_FLAT_WAY', 'Best Way');
?>
