<?
  /* $Id */
  // define('SHIPPING_ITEM_COST', '2.50'); // In DB
  define('SHIPPING_ITEM_NAME', 'Per Item');
  define('SHIPPING_ITEM_WAY', 'Best Way');
?>
