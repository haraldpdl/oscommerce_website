<?
  define('TEXT_CASH_ON_DELIVERY', 'Cash on Delivery');
?>