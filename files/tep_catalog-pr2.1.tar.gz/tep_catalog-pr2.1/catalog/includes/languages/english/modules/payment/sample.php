<?
  define('TEXT_SAMPLE', 'Sample Payment Module');
?>