<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Checkout');
define('NAVBAR_TITLE_2', 'Payment Method');
define('TOP_BAR_TITLE', 'Checkout Procedure');
define('HEADING_TITLE', 'Payment Method');
define('TABLE_HEADING_COMMENTS', 'Add Comments About Your Order');
define('TABLE_HEADING_METHODS', 'Methods');
define('TABLE_HEADING_SELECTION', 'Selection');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Delivery Address');
define('TABLE_HEADING_SHIPPING_INFO', 'Shipping Carrier');
define('TABLE_HEADING_SHIPPING_QUOTE', 'Select Preferred Rate');
define('CHANGE_DELIVERY_ADDRESS', 'Change Address or Shipping Options');

define('IMAGE_NEXT', 'Next');
?>
