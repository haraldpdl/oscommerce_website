<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Address Book');
define('NAVBAR_TITLE_ADD_ENTRY', 'New Entry');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Modify Entry');
define('TOP_BAR_TITLE_ADD_ENTRY', 'Add A New Address Book Entry');
define('TOP_BAR_TITLE_MODIFY_ENTRY', 'Modify an Entry');
define('HEADING_TITLE_ADD_ENTRY', 'New Address Book Entry');
define('HEADING_TITLE_MODIFY_ENTRY', 'Address Book Entry');
define('PLEASE_SELECT', 'Please Select');

define('IMAGE_INSERT', 'Insert');
define('IMAGE_CANCEL', 'Cancel');
define('IMAGE_UPDATE', 'Update');
define('IMAGE_DELETE', 'Delete');
?>