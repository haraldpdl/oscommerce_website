<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Contenido de la Cesta');
define('TOP_BAR_TITLE', 'Contenido de la Cesta');
define('HEADING_TITLE', 'Que hay en mi Cesta?');
define('TABLE_HEADING_QUANTITY', 'Cantidad');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Producto(s)');
define('TABLE_HEADING_TOTAL', 'Total');
define('TEXT_CART_EMPTY', 'Tu Cesta de la Compra esta vacia!');
define('SUB_TITLE_SUB_TOTAL', 'Subtotal:');
define('SUB_TITLE_TOTAL', 'Total:');

define('IMAGE_CHECKOUT', 'Realizar Pedido');
define('IMAGE_REMOVE_ALL', 'Vaciar Cesta');
define('IMAGE_MAIN_MENU', 'Menu Principal');
define('IMAGE_UPDATE_CART', 'Actualizar la Cesta con las nuevas Cantidades');
?>
