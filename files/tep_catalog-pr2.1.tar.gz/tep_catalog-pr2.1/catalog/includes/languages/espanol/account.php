<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Mi Cuenta');
define('TOP_BAR_TITLE', 'Mi Cuenta');
define('HEADING_TITLE', 'Informacion de Mi Cuenta');

define('IMAGE_EDIT_ACCOUNT', 'Editar Cuenta');
define('IMAGE_ADDRESS_BOOK', 'Otras Direcciones');
define('IMAGE_HISTORY', 'Historial');
?>