<?
  define('TEXT_CASH_ON_DELIVERY', 'Contra Reembolso');
?>