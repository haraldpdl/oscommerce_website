<?
  /* $Id */
  // define('SHIPPING_ITEM_COST', '2.50'); // In DB
  define('SHIPPING_ITEM_NAME', 'Por art�culo');
  define('SHIPPING_ITEM_WAY', 'La Mejor Manera');
?>
