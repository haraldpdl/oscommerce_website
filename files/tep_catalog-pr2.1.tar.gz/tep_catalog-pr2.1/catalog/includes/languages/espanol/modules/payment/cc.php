<?
  define('TEXT_CREDIT_CARD', 'Tarjeta de Credito');
  define('TEXT_CREDIT_CARD_OWNER', 'Titular de la Tarjeta:');
  define('TEXT_CREDIT_CARD_NUMBER', 'Numero de la Tarjeta:');
  define('TEXT_CREDIT_CARD_EXPIRES', 'Fecha de Caducidad:');
  define('JS_CC_OWNER', '* El titular de la tarjeta de credito debe de tener al menos ' . CC_OWNER_MIN_LENGTH . ' letras.\n');
  define('JS_CC_NUMBER', '* El numero de la tarjeta de credito debe de tener al menos ' . CC_NUMBER_MIN_LENGTH . ' numeros.\n');
?>