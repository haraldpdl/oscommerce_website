<?php
	/* $Id: fedex.php,v 1.2 2001/02/07 21:05:20 pkellum Exp $ */
	define('SHIPPING_FEDEX_NAME', 'Federal Express Ground'); // It's a trademark, can't translate
	define('SHIPPING_FEDEX_NOTAVAILABLE', 'El servicio solicitado es inasequible entre las localizaciones seleccionadas.'); // can someone check this?
?>
