<?
  define('TEXT_SAMPLE', 'Modulo de Pago de Ejemplo');
?>