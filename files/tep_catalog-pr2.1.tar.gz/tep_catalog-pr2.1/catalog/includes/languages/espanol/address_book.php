<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Otras Direcciones');
define('TOP_BAR_TITLE', 'Direcciones');
define('HEADING_TITLE', 'Otras Direcciones de Envio');
define('TABLE_HEADING_NUMBER', 'N�');
define('TABLE_HEADING_NAME', 'Nombre');
define('TABLE_HEADING_CITY_COUNTRY', 'Ciudad / Pais');
define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'No tiene ningun direccion alternativa!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> Se permiten un maximo de ' . MAX_ADDRESS_BOOK_ENTRIES . ' direcciones.');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>NOTA:</b></font> Se ha alcanzado el tope de ' . MAX_ADDRESS_BOOK_ENTRIES . ' direcciones.');

define('IMAGE_ADD_ENTRY', 'A�adir Direccion');
define('IMAGE_BACK', 'Volver');
?>