<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Historial');
define('NAVBAR_TITLE_3', 'Detalle del Pedido');
define('TOP_BAR_TITLE', 'Historial de Pedidos');
define('HEADING_TITLE', 'Detalle del Pedido');
define('TABLE_HEADING_COMMENTS', 'Comentarios');
define('TABLE_HEADING_QUANTITY', 'Cantidad');
define('TABLE_HEADING_PRODUCT', 'Producto');
define('TABLE_HEADING_TAX', 'Impuestos');
define('TABLE_HEADING_TOTAL', 'Total');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Direccion de Entrega');
define('TABLE_HEADING_PAYMENT_METHOD', 'Forma de Pago');
define('TABLE_SUBHEADING_SUBTOTAL', 'Subtotal:');
define('TABLE_SUBHEADING_TAX', 'Impuestos');
define('TABLE_SUBHEADING_SHIPPING', 'Gastos de Envio:');
define('TABLE_SUBHEADING_TOTAL', 'Total:');
define('TEXT_COD', 'Contra Reembolso');
define('TEXT_CC', 'Tarjeta de Credito');
define('TEXT_PAYPAL', 'PayPal.com Proceso de Tarjetas de Credito/eCheck');

define('IMAGE_BACK', 'Volver');
?>
