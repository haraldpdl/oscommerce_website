<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

if ($HTTP_GET_VARS['action'] == 'success') {
  define('SUB_BAR_TITLE', 'Consulta Enviada');
} else {
  define('SUB_BAR_TITLE', 'Tiene alguna pregunta que hacer?');
}
define('TOP_BAR_TITLE', 'Contactenos');
define('HEADING_TITLE', 'Contactenos');
define('NAVBAR_TITLE', 'Contactenos');
define('TEXT_SUCCESS', 'Su consulta ha sido enviada al encargado de la tienda.');
define('EMAIL_SUBJECT', 'Consulta desde ' . STORE_NAME);

define('ENTRY_NAME', 'Nombre Completo:');
define('ENTRY_EMAIL', 'Direccion E-Mail:');
define('ENTRY_ENQUIRY', 'Consulta:');

define('IMAGE_SUBMIT', 'Enviar');
?>