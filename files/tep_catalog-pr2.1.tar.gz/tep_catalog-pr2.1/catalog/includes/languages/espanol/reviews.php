<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Comentarios');
define('TOP_BAR_TITLE', 'Comentarios Recientes');
define('HEADING_TITLE', 'Lea lo que estan diciendo los demas');
define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');

define('IMAGE_MAIN_MENU', 'Menu Principal');
?>