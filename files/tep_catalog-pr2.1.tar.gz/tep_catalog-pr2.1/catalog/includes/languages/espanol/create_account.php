<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Crear una Cuenta');
define('TOP_BAR_TITLE', 'Crear una Cuenta');
define('HEADING_TITLE', 'Informacion de Mi Cuenta');
define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>NOTA:</b></font></small> Si ya tiene una cuenta con nosotros, por favor use esta pagina para <a href="' . tep_href_link(FILENAME_LOGIN, 'origin=checkout_address&connection=' . $HTTP_GET_VARS['connection'], 'NONSSL') . '"><u>Entrar</u></a>.');
define('PLEASE_SELECT', 'Seleccione');

define('IMAGE_DONE', 'Terminado');
?>