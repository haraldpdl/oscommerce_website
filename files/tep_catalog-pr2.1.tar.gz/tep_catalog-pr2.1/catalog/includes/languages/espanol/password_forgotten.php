<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Entrar');
define('NAVBAR_TITLE_2', 'Constrase�a Olvidada');
define('TOP_BAR_TITLE', 'Contrase�a Olvidada');
define('HEADING_TITLE', 'He olvidado mi Contrase�a!');
define('ENTRY_EMAIL_ADDRESS', 'E-Mail:');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', '<font color="#ff0000"><b>NOTA:</b></font> Ese E-Mail no figura en nuestros datos, intentelo de nuevo.');
define('EMAIL_PASSWORD_REMINDER_SUBJECT', STORE_NAME . ' - Recuperar Contrase�a');
define('EMAIL_PASSWORD_REMINDER_BODY', 'Ha solicitado recuperar su Contrase�a desde ' . $REMOTE_ADDR . '.' . "\n\n" . 'Su contrase�a para \'' . STORE_NAME . '\' es:' . "\n\n" . '   %s' . "\n\n");

define('IMAGE_EMAIL_ME', 'Enviamela');
?>