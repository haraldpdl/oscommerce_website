<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Realizar Pedido');
define('NAVBAR_TITLE_2', 'Forma de Pago');
define('TOP_BAR_TITLE', 'Realizar Pedido');
define('HEADING_TITLE', 'Forma de Pago');
define('TABLE_HEADING_COMMENTS', 'Agregue Los Comentarios Sobre Su Orden');
define('TABLE_HEADING_METHODS', 'Formas');
define('TABLE_HEADING_SELECTION', 'Seleccion');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Direccion de Envio');
define('TABLE_HEADING_SHIPPING_INFO', 'Portador Del Env�o');
define('TABLE_HEADING_SHIPPING_QUOTE', 'Seleccione Preferida La Tarifa');
define('CHANGE_DELIVERY_ADDRESS', 'Cambie las opciones del direccionamiento o del env�o');

define('IMAGE_NEXT', 'Siguiente');
?>
