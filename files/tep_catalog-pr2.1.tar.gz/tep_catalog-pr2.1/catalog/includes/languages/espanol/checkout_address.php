<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Realizar Pedido');
define('NAVBAR_TITLE_2', 'Direccion de Envio');
define('TOP_BAR_TITLE', 'Realizar Pedido');
define('HEADING_TITLE', 'Entrega del Producto');
define('TABLE_HEADING_MY_ADDRESS', 'Mi Direccion');
define('TABLE_HEADING_SHIPPING_INFO', 'Forma de Envio');
define('TABLE_HEADING_SHIPPING_QUOTE', 'Cotizaci�n De la Tarifa');
define('TABLE_HEADING_DELIVER_TO', 'Enviar A');
define('TABLE_HEADING_ADDRESS_BOOK', 'Otras Direcciones');
define('TEXT_ADDRESS_BOOK_NO_ENTRIES', 'No hay direcciones adicionales!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>NOTA:</b></font> Es imposible a�adir mas direcciones - se ha alcanzado el maximo de ' . MAX_ADDRESS_BOOK_ENTRIES . ' direcciones.');

define('IMAGE_ADD_ENTRY', 'A�adir Direccion');
define('IMAGE_NEXT', 'Siguiente');
?>
