<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE1', 'B�squeda');
define('NAVBAR_TITLE2', 'Resultados de la B�squeda');
define('TOP_BAR_TITLE', 'Resultados de la B�squeda');
define('HEADING_TITLE', 'Productos que satisfacen los criterios de b�squeda');
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Descripcion');
define('TABLE_HEADING_MANUFACTURER', 'Fabricante');
define('TABLE_HEADING_QUANTITY', 'Cantidad');
define('TABLE_HEADING_PRICE', 'Precio');
define('TABLE_HEADING_WEIGHT', 'Peso');
define('TABLE_HEADING_BUY_NOW', 'Compre Ahora');
define('TEXT_NO_PRODUCTS', 'No hay productos que corresponden con los criterios de b�squeda.');
define('TEXT_NO_PRODUCTS2', 'No hay productos que corresponden con los criterios de b�squeda.');
define('TEXT_SORT_PRODUCTS', 'Ordenar Productos ');
define('TEXT_DESCENDINGLY', 'Descendentemente');
define('TEXT_ASCENDINGLY', 'Ascendentemente');
define('TEXT_BY', ' por ');
define('TEXT_BUY', 'Compre 1 \'');
define('TEXT_NOW', '\' ahora');
?>
