<?
  /* $Id */
  // define('SHIPPING_FLAT_COST', '5.00'); // This is in DB
  define('SHIPPING_FLAT_NAME', 'Einzelne Kosten');
  define('SHIPPING_FLAT_WAY', 'Beste Weise');
?>
