<?php
	/* $Id: fedex.php,v 1.3 2001/02/09 12:05:04 mkowalkowski Exp $ */
	define('SHIPPING_FEDEX_NAME', 'Federal Express Ground'); // It's a trademark, can't translate
	define('SHIPPING_FEDEX_NOTAVAILABLE', 'Die Lieferung ist zwischen den ausgew&auml;hlten Standorten nicht m&ouml;glich.'); // can someone check this?
?>
