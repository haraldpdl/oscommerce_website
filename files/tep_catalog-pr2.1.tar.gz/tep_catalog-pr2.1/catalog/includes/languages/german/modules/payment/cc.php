<?
  define('TEXT_CREDIT_CARD', 'Kreditkarte');
  define('TEXT_CREDIT_CARD_OWNER', 'Name des Eigent�mers:');
  define('TEXT_CREDIT_CARD_NUMBER', 'Kreditkartenr.:');
  define('TEXT_CREDIT_CARD_EXPIRES', 'G�ltig bis:');
  define('JS_CC_OWNER', '* Der \'Name des Eigent�mers\' mu� mindestens aus ' . CC_OWNER_MIN_LENGTH . ' Buchstaben bestehen.\n');
  define('JS_CC_NUMBER', '* Die \'Kreditkartenr.\' mu� mindestens aus ' . CC_NUMBER_MIN_LENGTH . ' Zahlen bestehen.\n');
?>