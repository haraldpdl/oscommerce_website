<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'pers&ouml;nliche Daten &auml;ndern');
define('TOP_BAR_TITLE', 'Mein Konto');
define('HEADING_TITLE', 'pers&ouml;nliche Daten &auml;ndern :');
define('PLEASE_SELECT', 'Bitte w&auml;hlen');

define('IMAGE_UPDATE', 'Aktualisieren');
define('IMAGE_CANCEL', 'Abbrechen');
?>