<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Erfolg');
define('TOP_BAR_TITLE', 'Bestellassistent fertig');
define('HEADING_TITLE', 'Ihr Bestellung ist ausgef&uuml;hrt worden.');
define('TEXT_SUCCESS', 'Ihre Bestellung ist eingegangen und wird bearbeitet! Die Lieferung erfolgt innerhalb von ca. 2-5 Werktagen.<br><br>Sie k&ouml;nnen ihre Bestellung auf der Seite <a href="' . tep_href_link(FILENAME_ACCOUNT, '', 'NONSSL') . '">\'Mein Konto\'</a> nochmals abfragen.<br><br>Falls Sie Fragen bez&uuml;glich Ihrer Bestellung haben, wenden Sie sich an unseren <a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">Vertrieb</a>.<br><br><font size="3">Vielen Dank f&uuml;r ihre Bestellung!</font>');

define('IMAGE_MAIN_MENU', 'Startseite');
?>