<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE1', 'Erweiterte Suche');
define('NAVBAR_TITLE2', 'Suchergebnisse');
define('TOP_BAR_TITLE', 'Suchergebnisse');
define('HEADING_TITLE', 'Artikel, welche den Suchkriterien entsprechen');
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Artikelnummer');
define('TABLE_HEADING_PRODUCTS', 'Bezeichnung');
define('TABLE_HEADING_MANUFACTURER', 'Hersteller');
define('TABLE_HEADING_QUANTITY', 'Anzahl');
define('TABLE_HEADING_PRICE', 'Einzelpreis');
define('TABLE_HEADING_WEIGHT', 'Gewicht');
define('TABLE_HEADING_BUY_NOW', 'jetzt bestellen');
define('TEXT_NO_PRODUCTS', 'Es wurden keine Artikel gefunden, die den Suchkriterien entsprechen.');
define('TEXT_NO_PRODUCTS2', 'Es wurden keine Artikel gefunden, die den Suchkriterien entsprechen.');
define('TEXT_SORT_PRODUCTS', 'Sortierung der Artikel ist ');
define('TEXT_DESCENDINGLY', 'absteigend');
define('TEXT_ASCENDINGLY', 'aufsteiogenmd');
define('TEXT_BY', ' durch ');
define('TEXT_BUY', 'Kaufen 1 \'');
define('TEXT_NOW', '\' jetzt');
?>
