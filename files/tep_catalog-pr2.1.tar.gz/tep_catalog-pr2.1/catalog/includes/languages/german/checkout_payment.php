<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Zahlungsweise');
define('TOP_BAR_TITLE', 'Bestellassistent');
define('HEADING_TITLE', 'Zahlungsweise :');
define('TABLE_HEADING_COMMENTS', 'F�gen Sie Kommentar �ber Ihre Ordnung Hinzu');
define('TABLE_HEADING_METHODS', 'Zahlungsmethoden');
define('TABLE_HEADING_SELECTION', 'Zahlungsweise');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Lieferanschrift');
define('TABLE_HEADING_SHIPPING_INFO', 'VerschiffenF�rdermaschine');
define('TABLE_HEADING_SHIPPING_QUOTE', 'W�hlen Sie Bevorzugte Kosten Aus');
define('CHANGE_DELIVERY_ADDRESS', '�ndern Sie Adresse oder Verschiffenoptionen');

define('IMAGE_NEXT', 'Weiter');
?>
