<?php
	/* $Id: configuration.php,v 1.1 2001/02/23 04:54:34 pkellum Exp $
   *
   * Configuration
   */
  define('DB_SERVER', 'exchange');
  define('DB_SERVER_USERNAME', 'mysql');
  define('DB_SERVER_PASSWORD', '');
  define('DB_DATABASE', 'catalog');
  define('USE_GZIP', 0);  // Change to 1 if your server supports GZip
?>