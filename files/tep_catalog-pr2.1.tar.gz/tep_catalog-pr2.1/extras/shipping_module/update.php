<?php
	// this must point to the update.php file
	include '../update.php';
?>
