<?php
/*
  $Id: products_expected.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'erwartete Artikel');

define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_DATE_EXPECTED', 'verf&uuml;gbar ab:');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_DATE_EXPECTED', 'verf&uuml;gbar ab:');
?>