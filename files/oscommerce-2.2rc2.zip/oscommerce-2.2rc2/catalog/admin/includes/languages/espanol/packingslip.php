<?php
/*
  $Id: packingslip.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Comentario');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Productos');

define('ENTRY_SOLD_TO', 'VENDIDO A:');
define('ENTRY_SHIP_TO', 'ENVIAR A:');
define('ENTRY_PAYMENT_METHOD', 'M&eacute;todo de Pago:');
?>
