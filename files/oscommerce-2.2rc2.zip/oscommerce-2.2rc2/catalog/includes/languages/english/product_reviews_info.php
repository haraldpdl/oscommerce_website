<?php
/*
  $Id: product_reviews_info.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');
define('HEADING_TITLE', ' %s Reviews');
define('SUB_TITLE_PRODUCT', 'Product:');
define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_DATE', 'Date:');
define('SUB_TITLE_REVIEW', 'Review:');
define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_OF_5_STARS', '%s of 5 Stars!');
define('TEXT_CLICK_TO_ENLARGE', 'Click to enlarge');
?>