<?php
/*
  $Id: table.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_TABLE_TEXT_TITLE', 'Table Rate');
define('MODULE_SHIPPING_TABLE_TEXT_DESCRIPTION', 'Table Rate');
define('MODULE_SHIPPING_TABLE_TEXT_WAY', 'Best Way');
define('MODULE_SHIPPING_TABLE_TEXT_WEIGHT', 'Weight');
define('MODULE_SHIPPING_TABLE_TEXT_AMOUNT', 'Amount');
?>
