<?php
/*
  $Id: account_edit.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Ihr Konto');
define('NAVBAR_TITLE_2', 'Ihre pers&ouml;nliche Daten &auml;ndern');

define('HEADING_TITLE', 'Ihre pers&ouml;nliche Daten &auml;ndern');

define('MY_ACCOUNT_TITLE', 'Ihr Konto');

define('SUCCESS_ACCOUNT_UPDATED', 'Ihre Daten wurden erfolgreich aktualisiert!');
?>
