<?php
/*
  $Id: ot_tax.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_TAX_TITLE', 'MwSt.');
  define('MODULE_ORDER_TOTAL_TAX_DESCRIPTION', 'Mehrwertsteuer');
?>
