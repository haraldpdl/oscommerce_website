<?php
/*
  $Id: cc.php 1793 2008-01-11 13:48:20Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_CC_TEXT_TITLE', 'Kreditkarte (Nicht Einsatzf&auml;hig)');
  define('MODULE_PAYMENT_CC_TEXT_PUBLIC_TITLE', 'Kreditkarte');
  define('MODULE_PAYMENT_CC_TEXT_DESCRIPTION', 'Dieser Modul speichert die Kartennummer ohne Verschl&uuml;sselung in die Datenbank und ist im Einsatz nicht geeignet.<br><br>Kreditkarten Test Info:<br><br>CC#: 4111111111111111<br>G&uuml;ltig bis: Any');
  define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_OWNER', 'Kreditkarteninhaber:');
  define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_NUMBER', 'Kreditkarten-Nr.:');
  define('MODULE_PAYMENT_CC_TEXT_CREDIT_CARD_EXPIRES', 'G&uuml;ltig bis:');
  define('MODULE_PAYMENT_CC_TEXT_ERROR', 'Fehler bei der &Uuml;berp&uuml;fung der Kreditkarte!');
?>