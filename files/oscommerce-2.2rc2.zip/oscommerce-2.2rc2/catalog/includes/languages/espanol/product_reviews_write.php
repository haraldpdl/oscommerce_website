<?php
/*
  $Id: product_reviews_write.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');

define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_REVIEW', 'Comentario:');
define('SUB_TITLE_RATING', 'Evaluaci&oacute;n:');

define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>NOTA:</b></font></small>&nbsp;No se traducir&aacute; el codigo HTML!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>MALO</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>BUENO</b></font></small>');

define('TEXT_CLICK_TO_ENLARGE', 'Haga Click para agrandar');
?>
