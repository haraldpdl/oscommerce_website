<?php
/*
  $Id: account_newsletters.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Subscripci&oacute;n a Boletines');

define('HEADING_TITLE', 'Subscripci&oacute;n a Boletines');

define('MY_NEWSLETTERS_TITLE', 'Mis Subscripciones');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Bolet&iacute;n General');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Incluye noticias, nuevos productos, ofertas especiales y otros anuncios promocionales.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Se han actualizado sus subscrictiones correctamente.');
?>
