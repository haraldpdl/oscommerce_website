<?php
/*
  $Id: ipayment_cc.php 1811 2008-01-13 12:25:10Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_TITLE', 'iPayment');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_PUBLIC_TITLE', 'Tarjeta de Cr&eacute;dito');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" target="_blank" style="text-decoration: underline; font-weight: bold;">Visita la web de iPayment</a>');
  define('MODULE_PAYMENT_IPAYMENT_CC_ERROR_HEADING', 'Ha ocurrido un error procesando su tarjeta de cr&eacute;dito');
  define('MODULE_PAYMENT_IPAYMENT_CC_ERROR_MESSAGE', '�Revise los datos de su tarjeta de cr&eacute;dito!');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_OWNER', 'Titular de la Tarjeta:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_NUMBER', 'N&uacute;mero de la Tarjeta:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_EXPIRES', 'Fecha de Caducidad:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_CHECKNUMBER', 'N&uacute;mero de Comprobaci&oacute;n:');
?>
