<?
/*
English Text for The Exchange Project Administration Tool Preview Release 1.1
Last Update: 12/06/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Statistics');
define('HEADING_TITLE', 'Best Products Purchased');

define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_SUBCATEGORIES', 'Subcategories');
define('TABLE_HEADING_PURCHASED', 'Purchased');
?>