<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor="#000000" height="19">
    <td align="left"><font face="<?=FOOTER_BAR_FONT_FACE;?>" color="<?=FOOTER_BAR_FONT_COLOR;?>" size="<?=FOOTER_BAR_FONT_SIZE;?>"><b>&nbsp;&nbsp;<?=date('l, jS F, Y'); ?></b></font></td>
  </tr>
</table>
<br>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><font face="Verdana, Arial" size="1">&copy; 2000 <a href="http://theexchangeproject.org">The Exchange Project</a> : <a href="mailto:hpdl@theexchangeproject.org">Harald Ponce de Leon</a><br>Hosted by <a href="http://www.xcom.de" target="_blank">XCOM AG - The Solution People</a></font></td>
  </tr>
</table>
