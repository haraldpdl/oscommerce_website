# osCommerce Online Merchant
#
# @copyright Copyright (c) 2011 osCommerce; http://www.oscommerce.com
# @license BSD License; http://www.oscommerce.com/bsdlicense.txt

app_title = Error Log

heading_title = Error Log

table_heading_date = Date
table_heading_message = Message

dialog_delete_error_log_title = Delete Error Log
dialog_delete_error_log_desc = All Error Log entries will be permanently deleted and cannot be recovered. Are you sure?
