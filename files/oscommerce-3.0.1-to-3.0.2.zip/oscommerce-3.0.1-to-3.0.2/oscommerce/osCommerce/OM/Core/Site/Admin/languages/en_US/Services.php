# osCommerce Online Merchant
#
# @copyright Copyright (c) 2011 osCommerce; http://www.oscommerce.com
# @license BSD License; http://www.oscommerce.com/bsdlicense.txt

app_title = Services

heading_title = Services

table_heading_service_modules = Service Modules
table_heading_action = Action

introduction_edit_service_module = Please make the necessary changes for this service module.

dialog_uninstall_module_title = Uninstall Module
dialog_uninstall_module_desc = The selected module will be uninstalled. Are you sure?
