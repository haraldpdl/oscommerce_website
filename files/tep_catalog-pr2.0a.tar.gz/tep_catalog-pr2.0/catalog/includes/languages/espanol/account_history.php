<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Historial');
define('TOP_BAR_TITLE', 'Historial de Mi Cuenta');
define('HEADING_TITLE', 'Historial de Pedidos');
define('TABLE_HEADING_ORDER_NUMBER', 'Pedido Numero');
define('TABLE_HEADING_ORDER_DATE', 'Fecha');
define('TABLE_HEADING_ORDER_COST', 'Precio');
define('TABLE_HEADING_ORDER_STATUS', 'Estado');
define('TEXT_NO_PURCHASES', 'No ha realizado ningun pedido aun..');
define('TABLE_TEXT', 'Haga click en la \'Fecha\' para ver el detalle del pedido');

define('IMAGE_BACK', 'Volver');
?>