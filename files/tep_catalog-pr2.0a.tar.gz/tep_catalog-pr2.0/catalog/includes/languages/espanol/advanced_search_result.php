<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE1', 'B�squeda Avanzada');
define('NAVBAR_TITLE2', 'B�squeda Avanzada Resulta');
define('TOP_BAR_TITLE', 'B�squeda Avanzada Resulta');
define('HEADING_TITLE', 'Productos que satisfacen los criterios de b�squeda');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Descripcion');
define('TABLE_HEADING_PRICE', 'Precio');
define('TEXT_NO_PRODUCTS', 'No hay productos que corresponden con los criterios de la b�squeda.');
define('TEXT_NO_PRODUCTS2', 'No hay productos que corresponden con los criterios de la b�squeda.');
?>
