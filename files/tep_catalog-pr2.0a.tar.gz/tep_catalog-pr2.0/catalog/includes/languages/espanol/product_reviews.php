<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Comentarios');
define('TOP_BAR_TITLE', 'Comentarios');
define('HEADING_TITLE', '%s Comentarios');
define('TABLE_HEADING_NUMBER', 'N�');
define('TABLE_HEADING_AUTHOR', 'Autor');
define('TABLE_HEADING_RATING', 'Evaluacion');
define('TABLE_HEADING_READ', 'Leer');
define('TABLE_HEADING_DATE_ADDED', 'Fecha Alta');
define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');
define('TEXT_NO_REVIEWS', 'No hay comentarios escritos para este producto!');

define('IMAGE_WRITE_A_REVIEW', 'Deje su Comentario');
define('IMAGE_BACK', 'Volver');
?>