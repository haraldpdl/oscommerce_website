<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Pedido');
define('NAVBAR_TITLE_2', 'Realizado con Exito');
define('TOP_BAR_TITLE', 'Pedido Completo!');
define('HEADING_TITLE', 'Su Pedido ha sido Procesado!');
define('TEXT_SUCCESS', 'Su pedido ha sido realizado con exito! Sus productos llegaran a su destino de 2 a 5 dias laborales.<br><br>Puede ver su historial de pedidos su pagina de <a href="' . tep_href_link(FILENAME_ACCOUNT, '', 'NONSSL') . '">\'Mi Cuenta\'</a> y haciendo click en su <a href="' . tep_href_link(FILENAME_ACCOUNT_HISTORY, '', 'NONSSL') . '">\'Historial\'</a>.<br><br>Cualquier pregunta que tenga sobre el pedido puede hacerlas por Email a <a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">' . STORE_OWNER_EMAIL_ADDRESS . '</a>.<br><br><font size="3">Gracias por comprar con nosotros!</font>');

define('IMAGE_MAIN_MENU', 'Menu Principal');
?>