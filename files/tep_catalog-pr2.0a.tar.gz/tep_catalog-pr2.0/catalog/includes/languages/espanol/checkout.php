<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Realizar Pedido');
define('NAVBAR_TITLE_2', 'Contenido de la Cesta');
define('TOP_BAR_TITLE', 'Realizar Pedido');
define('HEADING_TITLE', 'Estoy preparado para comprar!');
define('TABLE_HEADING_QUANTITY', 'Cantidad');
define('TABLE_HEADING_PRODUCTS', 'Producto(s)');
define('TABLE_HEADING_TOTAL', 'Total');
define('TEXT_CART_EMPTY', 'Su Cesta esta vacia!');
define('SUB_TITLE_SUB_TOTAL', 'Subtotal:');
define('SUB_TITLE_TAX', 'Impuestos:');
define('SUB_TITLE_TOTAL', 'Total:');
define('TEXT_CURRENT_CONNECT_STATUS_NONSSL', 'Estado Actual (haga click para modificar)');
define('TEXT_CURRENT_CONNECT_STATUS_SSL', 'Estado Actual (haga click para modificar)');
define('NO_SHIPPING_OR_TAX_TEXT', '<font color="#ff0000"><small><b>NOTA:</b></small></font> Puede haber gastos de envio e impuestos adicionales de los que ser� informado antes de terminar el proceso.');

define('IMAGE_SECURE_SERVER', 'Servidor Seguro');
define('IMAGE_UNSECURE_SERVER', 'Servidor no Seguro');
define('IMAGE_NEXT', 'Siguiente');
?>
