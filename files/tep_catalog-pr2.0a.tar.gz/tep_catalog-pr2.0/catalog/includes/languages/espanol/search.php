<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Resultados de la Busqueda');
define('TOP_BAR_TITLE', 'Resultados de la Busqueda');
define('HEADING_TITLE', 'No encuentro lo que buscas');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Nombre del Producto');
define('TABLE_HEADING_PRICE', 'Precio');
define('TEXT_NO_PRODUCTS', 'No hay productos con ese criterio de busqueda.');
?>
