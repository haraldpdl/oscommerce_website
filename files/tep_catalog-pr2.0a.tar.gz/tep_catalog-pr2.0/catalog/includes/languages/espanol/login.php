<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Entrar');
define('TOP_BAR_TITLE', 'Entrar en \'' . STORE_NAME . '\'');
define('HEADING_TITLE', 'Dejame Entrar!');
define('ENTRY_EMAIL_ADDRESS', 'E-Mail:');
define('ENTRY_PASSWORD', 'Contrase�a:');
define('TEXT_COOKIE', '�Guardar informacion en un \'cookie\'?');
define('TEXT_PASSWORD_FORGOTTEN', '�Ha olvidado su contrase�a? Siga este enlace y se la enviamos.');
define('TEXT_CREATE_ACCOUNT', '�No tiene cuenta? Siga este enlace para crear una.');
define('TEXT_VISITORS_CART', '<font color="#ff0000"><b>NOTA:</b></font> El contenido de su &quot;Cesta de Visitante&quot; ser� a�adido a su &quot;Cesta de Asociado&quot; una vez que haya entrado. <a href="javascript:session_win();">[Mas Informacion]</a>');
define('TEXT_LOGIN_ERROR', '<font color="#ff0000"><b>ERROR:</b></font> Ese \'E-Mail\' y/o \'Contrase�a\' no figuran en nuestros datos.');

define('IMAGE_LOGIN', 'Entrar');
?>
