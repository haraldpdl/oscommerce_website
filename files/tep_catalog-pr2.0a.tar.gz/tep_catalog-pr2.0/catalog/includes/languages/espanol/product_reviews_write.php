<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Comentarios');
define('TOP_BAR_TITLE', '%s Comentarios');
define('HEADING_TITLE', '�Tienes algo que decir?');
define('SUB_TITLE_PRODUCT', 'Producto:');
define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_REVIEW', 'Comentario:');
define('SUB_TITLE_RATING', 'Evaluacion:');
define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>NOTA:</b></font></small>&nbsp;No es traduce el codigo HTML!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>MALO</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>BUENO</b></font></small>');

define('IMAGE_INSERT', 'A�adir');
define('IMAGE_CANCEL', 'Cancelar');
?>