<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Otras Direcciones');
define('NAVBAR_TITLE_ADD_ENTRY', 'Nueva Direccion');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Modificar Direccion');
define('TOP_BAR_TITLE_ADD_ENTRY', 'A�adir una nueva direccion de envio');
define('TOP_BAR_TITLE_MODIFY_ENTRY', 'Modificar Direccion');
define('HEADING_TITLE_ADD_ENTRY', 'Nueva Direccion');
define('HEADING_TITLE_MODIFY_ENTRY', 'Direccion');
define('PLEASE_SELECT', 'Seleccione');

define('IMAGE_INSERT', 'A�adir');
define('IMAGE_CANCEL', 'Cancelar');
define('IMAGE_UPDATE', 'Actualizar');
define('IMAGE_DELETE', 'Eliminar');
?>