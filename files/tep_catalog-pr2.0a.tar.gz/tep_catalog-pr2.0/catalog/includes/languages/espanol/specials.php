<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Ofertas');
define('TOP_BAR_TITLE', 'Ofertas');
define('HEADING_TITLE', 'Consiguelas mientras estan Calientes!');

define('IMAGE_MAIN_MENU', 'Menu Principal');
?>