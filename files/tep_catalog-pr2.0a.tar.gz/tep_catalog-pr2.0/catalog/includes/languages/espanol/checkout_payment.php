<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Realizar Pedido');
define('NAVBAR_TITLE_2', 'Forma de Pago');
define('TOP_BAR_TITLE', 'Realizar Pedido');
define('HEADING_TITLE', 'Forma de Pago');
define('TABLE_HEADING_METHODS', 'Formas');
define('TABLE_HEADING_SELECTION', 'Seleccion');
define('SUB_TITLE_CASH_ON_DELIVERY', 'Contra Reembolso');
define('SUB_TITLE_CREDIT_CARD', 'Tarjeta de Credito');
define('SUB_TITLE_CREDIT_CARD_OWNER', 'Titular de la Tarjeta de Credito:');
define('SUB_TITLE_CREDIT_CARD_NUMBER', 'Numero de la Tarjeta de Credito:');
define('SUB_TITLE_CREDIT_CARD_EXPIRES', 'Fecha de Caducidad de la Tarjeta de Credito:');
define('SUB_TITLE_PAYPAL', 'PayPal');

define('IMAGE_NEXT', 'Siguiente');
?>