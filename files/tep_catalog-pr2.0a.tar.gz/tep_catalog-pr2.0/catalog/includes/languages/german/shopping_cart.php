<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Warenkorb');
define('TOP_BAR_TITLE', 'Warenkorb');
define('HEADING_TITLE', 'Ihr Warenkorb enth&auml;t :');
define('TABLE_HEADING_QUANTITY', 'Anzahl');
define('TABLE_HEADING_MODEL', 'Modell');
define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_TOTAL', 'Summe');
define('TEXT_CART_EMPTY', 'Sie haben noch nichts in Ihrem Warenkorb.');
define('SUB_TITLE_SUB_TOTAL', 'Zwischensumme:');
define('SUB_TITLE_TOTAL', 'Summe:');

define('IMAGE_CHECKOUT', 'Kasse');
define('IMAGE_REMOVE_ALL', 'Inhalt l&ouml;schen');
define('IMAGE_MAIN_MENU', 'Startseite');
define('IMAGE_UPDATE_CART', 'Aktualisierungsvorgang Karre mit neuen Quantit�ten');
?>