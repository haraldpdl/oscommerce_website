<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Anmelden');
define('NAVBAR_TITLE_2', 'Passwort Vergessen');
define('TOP_BAR_TITLE', 'Password Vergessen');
define('HEADING_TITLE', 'Wie war noch mal mein Passwort?');
define('ENTRY_EMAIL_ADDRESS', 'E-Mail Adresse:');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', '<font color="#ff0000"><b>ACHTUNG:</b></font> Diese E-Mail Adresse ist nicht registriert. Bitte versuchen Sie es noch mal.');
define('EMAIL_PASSWORD_REMINDER_SUBJECT', STORE_NAME . ' - Ihre Passwort wurdt ermittelt');
define('EMAIL_PASSWORD_REMINDER_BODY', 'Eine Passwort Ermittelung wurde von ' . $REMOTE_ADDR . ' gefragt.' . "\n\n" . 'Ihre Passwort zu dem \'' . STORE_NAME . '\' lautet:' . "\n\n" . '   %s' . "\n\n");

define('IMAGE_EMAIL_ME', 'E-Mail Mich');
?>