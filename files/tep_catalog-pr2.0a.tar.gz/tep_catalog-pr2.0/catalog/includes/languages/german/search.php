<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Suchergebnis');
define('TOP_BAR_TITLE', 'Suchergebnis');
define('HEADING_TITLE', 'Suchen Sie etwas bestimmtes?');
define('TABLE_HEADING_MODEL', 'Modell');
define('TABLE_HEADING_PRODUCTS', 'Produkte');
define('TABLE_HEADING_PRICE', 'Preis');
define('TEXT_NO_PRODUCTS', 'NEs gibt keine Produkte in diese Kategorie.');
?>