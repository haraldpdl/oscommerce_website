<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Zugang erstellen');
define('TOP_BAR_TITLE', 'Zugang erstellen');
define('HEADING_TITLE', 'Meine pers&ouml;nlichen Daten');
define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>ACHTUNG:</b></font></small> Wenn Sie schon bei uns einen Zugang besitzen, so melden Sie sich bitte <a href="' . tep_href_link(FILENAME_LOGIN, 'origin=checkout_address', 'NONSSL') . '"><u>hier</u></a> an.');
define('PLEASE_SELECT', 'Bitte w&auml;hlen');

define('IMAGE_DONE', 'fertig');
?>