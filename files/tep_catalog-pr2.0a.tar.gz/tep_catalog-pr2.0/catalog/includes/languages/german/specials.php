<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Angebote');
define('TOP_BAR_TITLE', 'Angebote');
define('HEADING_TITLE', 'Unsere Angebote :');

define('IMAGE_MAIN_MENU', 'Startseite');
?>