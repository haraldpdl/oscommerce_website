<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Mein Konto');
define('TOP_BAR_TITLE', 'Mein Konto');
define('HEADING_TITLE', 'pers&ouml;nliche Daten :');

define('IMAGE_EDIT_ACCOUNT', 'pers&ouml;nliche Daten &auml;ndern');
define('IMAGE_ADDRESS_BOOK', 'Adre&szlig;buch');
define('IMAGE_HISTORY', 'Bereits get&auml;tigte Bestellungen');
?>