<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Zahlungsweise');
define('TOP_BAR_TITLE', 'Bestellassistent');
define('HEADING_TITLE', 'Zahlungsweise :');
define('TABLE_HEADING_METHODS', 'Zahlungsmethoden');
define('TABLE_HEADING_SELECTION', 'Zahlungsweise');
define('SUB_TITLE_CASH_ON_DELIVERY', 'Nachnahme');
define('SUB_TITLE_CREDIT_CARD', 'Kreditkarte');
define('SUB_TITLE_CREDIT_CARD_OWNER', 'Eigent&uuml;mer:');
define('SUB_TITLE_CREDIT_CARD_NUMBER', 'Nummer:');
define('SUB_TITLE_CREDIT_CARD_EXPIRES', 'G&uuml;ltig bis:');
define('SUB_TITLE_PAYPAL', 'PayPal');

define('IMAGE_NEXT', 'Weiter');
?>