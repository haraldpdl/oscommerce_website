<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Adre&szlig;buch');
define('TOP_BAR_TITLE', 'Vorhandene Eintr&auml;ge');
define('HEADING_TITLE', 'Folgende Eintr&auml;ge verbinden wir zur Zeit mit Ihrer Adresse :');
define('TABLE_HEADING_NUMBER', 'Nummer');
define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_CITY_COUNTRY', 'Wohnort');
define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'Sie haben noch keine Eintr&auml;ge in ihrem Adre&szlig;buch!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben noch ' . MAX_ADDRESS_BOOK_ENTRIES . ' Adre&szlig;bucheintr&auml;ge zur Verf&uuml;gung!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben die maximale Anzahl (' . MAX_ADDRESS_BOOK_ENTRIES . ') der Adre&szlig;bucheintr&auml;ge erreicht!');

define('IMAGE_ADD_ENTRY', 'Neuer Eintrag');
define('IMAGE_BACK', 'Zur&uuml;ck');
?>