<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE1', 'Hochentwickelte Suche');
define('NAVBAR_TITLE2', 'Hochentwickelte Suche Resultiert');
define('TOP_BAR_TITLE', 'Hochentwickelte Suche Resultiert');
define('HEADING_TITLE', 'Produkte, welche treffen die Suchkriterien');
define('TABLE_HEADING_MODEL', 'Produkt Modell');
define('TABLE_HEADING_PRODUCTS', 'Produkt Name');
define('TABLE_HEADING_PRICE', 'Produkt Preis');
define('TEXT_NO_PRODUCTS', 'Es gibt kein Produkt, das die Suchkriterien zusammenbringt.');
define('TEXT_NO_PRODUCTS2', 'Es gibt kein Produkt, das die Suchkriterien zusammenbringt.');
?>
