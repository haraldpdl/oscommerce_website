<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'get&auml;tigte Bestellungen');
define('TOP_BAR_TITLE', 'get&auml;tigte Bestellungen');
define('HEADING_TITLE', 'get&auml;tigten Bestellungen :');
define('TABLE_HEADING_ORDER_NUMBER', 'Auftragsnummer');
define('TABLE_HEADING_ORDER_DATE', 'Bestelldatum');
define('TABLE_HEADING_ORDER_QUANTITY', 'Anzahl');
define('TABLE_HEADING_ORDER_COST', 'Preis');
define('TEXT_NO_PURCHASES', 'Sie haben noch keine Bestellungen get&auml;tigt.');
define('TABLE_TEXT', 'Um Ihre Bestellinformation abzufragen, klicken Sie auf das \'Bestelldatum\'');

define('IMAGE_BACK', 'Zur&uuml;ck');
?>