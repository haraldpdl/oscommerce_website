<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Checkout');
define('NAVBAR_TITLE_2', 'Delivery Address');
define('TOP_BAR_TITLE', 'Checkout Procedure');
define('HEADING_TITLE', 'Product Delivery');
define('TABLE_HEADING_MY_ADDRESS', 'My Address');
define('TABLE_HEADING_SHIPPING_INFO', 'Shipping Method');
define('TABLE_HEADING_DELIVER_TO', 'Deliver To');
define('TABLE_HEADING_ADDRESS_BOOK', 'Address Book');
define('TEXT_ADDRESS_BOOK_NO_ENTRIES', 'Your Address Book has currently no entries!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>NOTE:</b></font> Can\'t add new entries - maximum of ' . MAX_ADDRESS_BOOK_ENTRIES . ' address book entries reached.');

define('IMAGE_ADD_ENTRY', 'Add Entry');
define('IMAGE_NEXT', 'Next');
?>
