<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Checkout');
define('NAVBAR_TITLE_2', 'Payment Method');
define('TOP_BAR_TITLE', 'Checkout Procedure');
define('HEADING_TITLE', 'Payment Method');
define('TABLE_HEADING_METHODS', 'Methods');
define('TABLE_HEADING_SELECTION', 'Selection');
define('SUB_TITLE_CASH_ON_DELIVERY', 'Cash on Delivery');
define('SUB_TITLE_CREDIT_CARD', 'Credit Card');
define('SUB_TITLE_CREDIT_CARD_OWNER', 'Credit Card Owner:');
define('SUB_TITLE_CREDIT_CARD_NUMBER', 'Credit Card Number:');
define('SUB_TITLE_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
define('SUB_TITLE_PAYPAL', 'PayPal');

define('IMAGE_NEXT', 'Next');
?>