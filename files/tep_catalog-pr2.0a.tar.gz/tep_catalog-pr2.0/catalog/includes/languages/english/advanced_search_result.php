<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE1', 'Advanced Search');
define('NAVBAR_TITLE2', 'Advanced Search Results');
define('TOP_BAR_TITLE', 'Advanced Search Results');
define('HEADING_TITLE', 'Products meeting the search criteria');
define('TABLE_HEADING_MODEL', 'Products Model');
define('TABLE_HEADING_PRODUCTS', 'Products Name');
define('TABLE_HEADING_PRICE', 'Products Price');
define('TEXT_NO_PRODUCTS', 'There is no product that matches the search criteria.');
define('TEXT_NO_PRODUCTS2', 'There is no product that matches the search criteria.');
?>
