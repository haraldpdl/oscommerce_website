<?
  class shoppingCart {
  }
?>
