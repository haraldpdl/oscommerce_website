<?
/*
English Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Copia de Seguridad');
define('HEADING_TITLE', 'Copia de Seguridad');
define('SUB_BAR_TITLE', 'Haga copias de sus datos a menudo!');
define('TEXT_MAIN', 'Haga click en el siguiente boton para bajarse una copia de seguridad de sus datos.');
define('IMAGE_BACKUP', 'Copia de Seguridad');
?>