<?
/*
Spanish Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Paises');
define('HEADING_TITLE', 'Paises');

define('TABLE_HEADING_COUNTRY_ID', 'Id');
define('TABLE_HEADING_COUNTRY_NAME', 'Pais');
define('TABLE_HEADING_COUNTRY_CODES', 'Codigos');
define('TABLE_HEADING_ACTION', 'Accion');

define('TEXT_INFO_EDIT_INTRO', 'Haga los cambios necesarios');
define('TEXT_INFO_COUNTRY_NAME', 'Nombre:');
define('TEXT_INFO_COUNTRY_CODE_2', 'Codigo ISO (2):');
define('TEXT_INFO_COUNTRY_CODE_3', 'Codigo ISO (3):');
define('TEXT_INFO_ADDRESS_FORMAT', 'Formato de Direccion:');
define('TEXT_INFO_INSERT_INTRO', 'Introduzca el nuevo pais con sus datos');
define('TEXT_INFO_DELETE_INTRO', 'Seguro que desea eliminar este pais?');
define('TEXT_INFO_HEADING_NEW_COUNTRY', 'Nuevo Pais');
?>
