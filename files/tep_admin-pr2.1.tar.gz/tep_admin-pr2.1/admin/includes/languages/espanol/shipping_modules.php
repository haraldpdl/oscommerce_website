<?
/*
Spanish Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Modulos de Envio');
define('HEADING_TITLE', 'Modulos de Envio');

define('TABLE_HEADING_CONFIGURATION_TITLE', 'Fichero');
define('TABLE_HEADING_CONFIGURATION_VALUE', 'Instalado');
define('TABLE_HEADING_ACTION', 'Instalar/Desinstalar');

define('IMAGE_INSTALL_REMOVE', 'Haga click para instalar/desinstalar este modulo');
?>
