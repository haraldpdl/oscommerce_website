<?
/*
Spanish Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Configuracion');
define('HEADING_TITLE', 'Configuracion');

define('TABLE_HEADING_CONFIGURATION_TITLE', 'Titulo');
define('TABLE_HEADING_CONFIGURATION_VALUE', 'Valor');
define('TABLE_HEADING_ACTION', 'Accion');

define('TEXT_INFO_EDIT_INTRO', 'Haga los cambios necesarios');
define('TEXT_INFO_KEY', 'Clave:');
define('TEXT_INFO_VALUE', 'Valor:');
define('TEXT_INFO_FUNCTION', 'Funcion:');
define('TEXT_INFO_DATE_ADDED', 'Fecha de Alta:');
define('TEXT_INFO_LAST_MODIFIED', 'Ultima Modificacion:');
define('TEXT_INFO_DESCRIPTION', 'Descripcion:');
define('TEXT_INFO_DEFINE_NOTE', '<small><b>NOTA:</b></small> La Clave es el nombre de la constante, y el Valor es el valor que tiene esa constante');
define('TEXT_INFO_FUNCTION_NOTE', '<small><b>NOTA:</b></small> Si la clave debe usar una funcion para recuperar su valor, indiquela sin los parentesis');
?>