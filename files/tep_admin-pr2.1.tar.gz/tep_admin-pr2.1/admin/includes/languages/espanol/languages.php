<?
/*
English Text for The Exchange Project Administration Tool Preview Release 2.1
Last Update: 24/02/2001
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Lenguaje');
define('HEADING_TITLE', 'Lenguaje');

define('TABLE_HEADING_LANGUAGE_ID', 'ID');
define('TABLE_HEADING_LANGUAGE_NAME', 'Lenguaje');
define('TABLE_HEADING_LANGUAGE_CODE', 'Codigo');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_EDIT_INTRO', 'Haga los cambios necesarios');
define('TEXT_INFO_LANGUAGE_NAME', 'Nombre:');
define('TEXT_INFO_LANGUAGE_CODE', 'Codigo:');
define('TEXT_INFO_LANGUAGE_IMAGE', 'Imagen:');
define('TEXT_INFO_LANGUAGE_DIRECTORY', 'Directorio:');
define('TEXT_INFO_LANGUAGE_SORT_ORDER', 'Orden:');
define('TEXT_INFO_INSERT_INTRO', 'Introduzca los datos de la nueva lenguaje');
define('TEXT_INFO_DELETE_INTRO', 'Seguro que quiere eliminar esta lenguaje?');
define('TEXT_INFO_HEADING_NEW_CURRENCY', 'Nueva Lenguaje');
?>
