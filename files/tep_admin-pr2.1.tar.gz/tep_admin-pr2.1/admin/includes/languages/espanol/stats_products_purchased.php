<?
/*
Spanish Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('TOP_BAR_TITLE', 'Estadisticas');
define('HEADING_TITLE', 'Productos Mas Comprados');

define('TABLE_HEADING_NUMBER', 'N�');
define('TABLE_HEADING_PRODUCTS', 'Productos');
define('TABLE_HEADING_PURCHASED', 'Comprados');
?>