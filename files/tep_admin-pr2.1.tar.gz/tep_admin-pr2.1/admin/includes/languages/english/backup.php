<?
/*
English Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Backup');
define('HEADING_TITLE', 'Backup');
define('SUB_BAR_TITLE', 'Backup your data often!');
define('TEXT_MAIN', 'Click the button below to download a backup copy of the database.');
define('IMAGE_BACKUP', 'Backup');
?>