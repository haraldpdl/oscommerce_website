<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('TOP_BAR_TITLE', 'Zonen');
define('HEADING_TITLE', 'Zonen');

define('TABLE_HEADING_COUNTRY_NAME', 'Land');
define('TABLE_HEADING_ZONE_NAME', 'Zonen');
define('TABLE_HEADING_ZONE_CODE', 'Code');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_EDIT_INTRO', 'Bitte f&uuml;hren Sie die notwendigen &Auml;nderungen durch');
define('TEXT_INFO_ZONES_NAME', 'Name der Zone:');
define('TEXT_INFO_ZONES_CODE', 'Code der Zone:');
define('TEXT_INFO_COUNTRY_NAME', 'Land:');
define('TEXT_INFO_INSERT_INTRO', 'Bitte geben Sie die neue Zone mit den dazugeh&ouml;rigen Daten ein');
define('TEXT_INFO_DELETE_INTRO', 'Wollen Sie diese Zone wirklich l&ouml;schen ?');
define('TEXT_INFO_HEADING_NEW_ZONE', 'Neue Zone');
?>