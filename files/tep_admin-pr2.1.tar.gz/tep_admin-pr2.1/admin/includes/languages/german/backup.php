<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.1
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Datensicherung');
define('HEADING_TITLE', 'Datensicherung'); 
define('SUB_BAR_TITLE', 'Sichern Sie Ihre Daten so oft wie m�glich!'); 
define('TEXT_MAIN', 'Klicken Sie auf die Schaltfl�che um eine Datensicherung Ihrer Datenbank anzulegen.');
define('IMAGE_BACKUP', 'Datensicherung');
?>