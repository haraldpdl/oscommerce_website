<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('TOP_BAR_TITLE', 'Artikelmerkmale');
define('HEADING_TITLE_OPT', 'Artikelmerkmale');
define('HEADING_TITLE_VAL', 'Optionswert');
define('HEADING_TITLE_ATRIB', 'Artikelmerkmale');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_PRODUCT', 'Artikelname');
define('TABLE_HEADING_OPT_NAME', 'Optionsname');
define('TABLE_HEADING_OPT_VALUE', 'Optionswert');
define('TABLE_HEADING_OPT_PRICE', 'Preis');
define('TABLE_HEADING_OPT_PRICE_PREFIX', 'Prefix (+/-)');
define('TABLE_HEADING_ACTION', 'Aktion');

define('MAX_ROW_LISTS_OPTIONS', 10);

define('TEXT_WARNING_OF_DELETE', 'Mit dieser Option sind Artikel sowie Optionsmerkmale verbunden - Es wird nicht empfohlen sie zu l&ouml;schen.');
define('TEXT_OK_TO_DELETE', 'Mit dieser Option sind keine Artikel sowie Optionsmerkmale verbunden - Sie kann gel&ouml;scht werden.');
?>