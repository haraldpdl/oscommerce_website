<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('TOP_BAR_TITLE', 'Statistiken');
define('HEADING_TITLE', 'Kunden mit den h�ufigsten Bestellungen (ohne MwSt)');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_CUSTOMERS', 'Kunde');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Gesamtsumme');
?>