<?
  $include_file = DIR_BOXES . 'categories.php'; include(DIR_INCLUDES . 'include_once.php');
  $include_file = DIR_BOXES . 'whats_new.php'; include(DIR_INCLUDES . 'include_once.php');
  $include_file = DIR_BOXES . 'search.php'; include(DIR_INCLUDES . 'include_once.php');
  $include_file = DIR_BOXES . 'add_a_quickie.php'; include(DIR_INCLUDES . 'include_once.php');
?>
