<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Vorherige Bestellung');
define('TOP_BAR_TITLE', 'Vorherige Bestellung');
define('HEADING_TITLE', 'Meine vorherige Bestellung');
define('TABLE_HEADING_ORDER_NUMBER', 'Bestell-Nr.');
define('TABLE_HEADING_ORDER_DATE', 'Bestell-Datum');
define('TABLE_HEADING_ORDER_QUANTITY', 'Bestell-Menge');
define('TABLE_HEADING_ORDER_COST', 'Bestell-Preis');
define('TEXT_NO_PURCHASES', 'Sie haben noch keine Bestellung get&auml;tigt..');
define('TABLE_TEXT', 'Um ihre Bestellinformation zuabfragen, klicken Sie auf den \'Bestell-Datum\' link');

define('IMAGE_BACK', 'Zur&uuml;ck');
?>