<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Zahlungsart');
define('TOP_BAR_TITLE', 'Bestellungswegweiser');
define('HEADING_TITLE', 'Zahlungsart');
define('TABLE_HEADING_METHODS', 'Zahlungsmethoden');
define('TABLE_HEADING_SELECTION', 'Zahlungsart');
define('SUB_TITLE_CASH_ON_DELIVERY', 'Nachnahme');
define('SUB_TITLE_CREDIT_CARD', 'Kredit Karte');
define('SUB_TITLE_CREDIT_CARD_TYPE', 'Typ:');
define('SUB_TITLE_CREDIT_CARD_OWNER', 'Eigent&uuml;mer:');
define('SUB_TITLE_CREDIT_CARD_NUMBER', 'Nummer:');
define('SUB_TITLE_CREDIT_CARD_EXPIRES', 'G&uuml;ltig bis:');

define('IMAGE_NEXT', 'Weiter');
?>