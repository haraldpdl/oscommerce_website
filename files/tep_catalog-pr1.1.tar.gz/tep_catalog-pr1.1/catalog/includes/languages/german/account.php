<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Mein Konto');
define('TOP_BAR_TITLE', 'Mein Konto');
define('HEADING_TITLE', 'Information &uuml;ber mein Konto');

define('IMAGE_EDIT_ACCOUNT', 'Konto &Auml;nderung');
define('IMAGE_ADDRESS_BOOK', 'Adre&szlig;buch');
define('IMAGE_HISTORY', 'Vorherige Bestellung');
?>