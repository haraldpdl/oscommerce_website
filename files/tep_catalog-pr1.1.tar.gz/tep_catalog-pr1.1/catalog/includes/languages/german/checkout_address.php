<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Zustelleradresse');
define('TOP_BAR_TITLE', 'Bestellungswegweiser');
define('HEADING_TITLE', 'Zu ihren Zustelladressen');
define('TABLE_HEADING_MY_ADDRESS', 'Meine Adresse');
define('TABLE_HEADING_DELIVER_TO', 'Ausgesuchte Adresse');
define('TABLE_HEADING_ADDRESS_BOOK', 'Adre&szlig;buch Eintr&auml;ge');
define('TEXT_ADDRESS_BOOK_NO_ENTRIES', 'Ihr Adre&szlig;buch ist leer!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben ' . MAX_ADDRESS_BOOK_ENTRIES . ' Adre&szlig;bucheintr&auml;ge erreicht!');

define('IMAGE_ADD_ENTRY', 'Neue Eintr&auml;ge');
define('IMAGE_NEXT', 'Weiter');
?>