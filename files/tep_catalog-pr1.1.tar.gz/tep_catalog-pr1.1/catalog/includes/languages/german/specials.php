<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Angebote');
define('TOP_BAR_TITLE', 'Angebote');
define('HEADING_TITLE', 'Super Angebote!');

define('IMAGE_MAIN_MENU', 'Haupt-Seite');
?>