<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Einkaufswagen Inhalt');
define('TOP_BAR_TITLE', 'Einkaufswagen Inhalt');
define('HEADING_TITLE', 'Was habe ich schon im Einkaufswagen?');
define('TABLE_HEADING_QUANTITY', 'Menge');
define('TABLE_HEADING_PRODUCTS', 'Produkte');
define('TABLE_HEADING_TOTAL', 'Summe');
define('TEXT_CART_EMPTY', 'Ihre Einkaufswagen ist leer!');
define('SUB_TITLE_SUB_TOTAL', 'Zwischensumme:');
define('SUB_TITLE_TAX', 'Mwst. (' . TAX_VALUE . '%):');
define('SUB_TITLE_TOTAL', 'Summe:');

define('IMAGE_CHECKOUT', 'Kasse');
define('IMAGE_REMOVE_ALL', 'Alles L&ouml;schen');
define('IMAGE_MAIN_MENU', 'Haupt-Seite');
?>