<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Konto Erstellen');
define('NAVBAR_TITLE_2', 'Erfolg');
define('TOP_BAR_TITLE', 'Konto mit Erfolg er&ouml;ffnet');
define('HEADING_TITLE', 'Konto mit Erfolg er&ouml;ffnet!');
define('TEXT_ACCOUNT_CREATED', 'Herzlichen Gl&uuml;ckwunsch! Ihr neues Konto ist erfolgreich er&ouml;ffnet! Sie k&ouml;nnen jetzt durch ihre Mitgliedschaft unsere \'Member-Services\' benutzen. Wenn Sie Fragen &uuml;ber dieses Gesch&auml;ft haben, wenden Sie sich bitte an den <a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">Gesch&auml;ftsinhaber</a>.<br><br>Eine Best&auml;tigung &uuml;ber ihr neues Konto wird ihnen zugeschickt. Falls Sie dieses E-Mail nicht innerhalb einer Stunde erhalten, wenden Sie sich bitte an den <a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">Gesch&auml;ftsinhaber</a>.');

define('IMAGE_LETS_SHOP', 'Jetzt Einkaufen!');
?>