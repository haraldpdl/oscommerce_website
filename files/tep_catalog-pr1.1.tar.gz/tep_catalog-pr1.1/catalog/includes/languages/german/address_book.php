<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Adre&szlig;buch');
define('TOP_BAR_TITLE', 'Adre&szlig;bucheintr&auml;ge');
define('HEADING_TITLE', 'Mein Pers&ouml;nilches Adre&szlig;buch');
define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_CITY_COUNTRY', 'Stadt / Land');
define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'Sie haben keine Eintr&auml;ge in ihrem Adre&szlig;buch!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben ' . MAX_ADDRESS_BOOK_ENTRIES . ' Adre&szlig;bucheintr&auml;ge zur Verf&uuml;gung!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben ' . MAX_ADDRESS_BOOK_ENTRIES . ' Adre&szlig;bucheintr&auml;ge erreicht!');

define('IMAGE_ADD_ENTRY', 'Neue Eintr&auml;ge');
define('IMAGE_BACK', 'Zur&uuml;ck');
?>