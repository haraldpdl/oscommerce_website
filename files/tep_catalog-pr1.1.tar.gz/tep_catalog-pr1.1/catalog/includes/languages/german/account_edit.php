<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Konto &Auml;nderung');
define('TOP_BAR_TITLE', 'Mein Konto');
define('HEADING_TITLE', 'Information &uuml;ber mein Konto');

define('IMAGE_UPDATE', 'Aktualisieren');
define('IMAGE_CANCEL', 'Abbrechen');
?>