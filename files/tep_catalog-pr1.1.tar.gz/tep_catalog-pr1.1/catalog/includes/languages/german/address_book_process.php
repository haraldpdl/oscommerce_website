<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Adre&szlig;buch');
define('NAVBAR_TITLE_ADD_ENTRY', 'Neue Eintr&auml;ge');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Eingabe &Auml;nderung');
define('TOP_BAR_TITLE_ADD_ENTRY', 'Neue Adre&szlig;bucheintr&auml;ge');
define('TOP_BAR_TITLE_MODIFY_ENTRY', 'Eingabe &Auml;nderung');
define('HEADING_TITLE_ADD_ENTRY', 'Neue Adre&szlig;bucheintr&auml;ge');
define('HEADING_TITLE_MODIFY_ENTRY', 'Adre&szlig;bucheintr&auml;ge');

define('IMAGE_INSERT', 'Einf&uuml;gen');
define('IMAGE_CANCEL', 'Abbrechen');
define('IMAGE_UPDATE', 'Aktualisieren');
define('IMAGE_DELETE', 'L&ouml;schen');
?>