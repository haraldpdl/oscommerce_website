<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Erfolg');
define('TOP_BAR_TITLE', 'Bestellungswegweiser durchgegangen');
define('HEADING_TITLE', 'Ihr Bestellung ist eingegeben');
define('TEXT_SUCCESS', 'Ihre Bestellung ist registeriert und wird Bearbeitet! Lieferung erfolgt innerhalb von ca. 2-5 Werktagen.<br><br>Sie k&ouml;nnen ihre Bestellung auf der seite <a href="' . tep_href_link(FILENAME_ACCOUNT, '', 'NONSSL') . '">\'Mein Konto\'</a> noch mals abfragen.<br><br>Falls Sie Fragen &uuml;ber ihre Bestellung haben, wenden Sie sich an den <a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">Gesch&auml;ftsinhaber</a>.<br><br><font size="3">Vielen Dank f&uuml;r ihre Bestellung!</font>');

define('IMAGE_MAIN_MENU', 'Haupt-Seite');
?>