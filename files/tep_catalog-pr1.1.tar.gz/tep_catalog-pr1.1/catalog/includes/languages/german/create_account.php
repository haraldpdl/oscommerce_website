<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Konto Erstellen');
define('TOP_BAR_TITLE', 'Konto Erstellen');
define('HEADING_TITLE', 'Meine Konto Information');
define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>ACHTUNG:</b></font></small> Wenn Sie schon ein Konto bei uns haben, dann gehen Sie bitte zu der <a href="' . tep_href_link(FILENAME_LOGIN, 'origin=checkout_address', 'NONSSL') . '"><u>Anmelde seite</u></a>.');

define('IMAGE_DONE', 'Fertig');
?>