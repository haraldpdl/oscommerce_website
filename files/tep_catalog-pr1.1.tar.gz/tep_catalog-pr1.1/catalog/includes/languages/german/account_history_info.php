<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Vorherige Bestellung');
define('NAVBAR_TITLE_3', 'Bestellunginformation');
define('TOP_BAR_TITLE', 'Vorherige Bestellung');
define('HEADING_TITLE', 'Bestellinformation');
define('TABLE_HEADING_QUANTITY', 'Menge');
define('TABLE_HEADING_PRODUCT', 'Produkte');
define('TABLE_HEADING_TOTAL', 'Summe');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Lieferadresse');
define('TABLE_HEADING_PAYMENT_METHOD', 'Zahlungs Methode');
define('TABLE_SUBHEADING_SUBTOTAL', 'Zwischensumme:');
define('TABLE_SUBHEADING_TAX', 'Mwst.');
define('TABLE_SUBHEADING_TOTAL', 'Summe:');
define('TEXT_COD', 'Nachnahme');
define('TEXT_CC', 'Kredit Karte');

define('IMAGE_BACK', 'Zur&uuml;ck');
?>