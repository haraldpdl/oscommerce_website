<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Suchergebnis');
define('TOP_BAR_TITLE', 'Suchergebnis');
define('HEADING_TITLE', 'Suchen Sie etwas bestimmtes?');
define('TABLE_HEADING_PRODUCTS_NAME', 'Produkt Name');
define('TABLE_HEADING_PRODUCTS_PRICE', 'Produkt Preis');
define('TEXT_FOUND_MATCHES', '%s Produkte gefunden..');
define('TEXT_MAXIMUM_SEARCH_RESULTS_REACHED', ' maximum Suchergebnis erreicht');
?>