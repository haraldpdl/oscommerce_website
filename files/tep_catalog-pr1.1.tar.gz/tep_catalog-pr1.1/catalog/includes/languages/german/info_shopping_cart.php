<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('HEADING_TITLE', 'Besuchereinkaufswagen / Mitgliedseinkaufswagen');
define('SUB_HEADING_TITLE_1', 'Besuchereinkaufswagen');
define('SUB_HEADING_TITLE_2', 'Mitgliedseinkaufswagen');
define('SUB_HEADING_TITLE_3', 'Info');
define('SUB_HEADING_TEXT_1', 'Jeder Besucher zu unserem Gesch&auml;ft bekommt ein \'Besuchereinkaufswagen\'. Damit kann er seine ausgew&auml;hlten Produkte sammeln. Sobald der Besucher das Gesch&auml;ft verl&auml;sst, verliert er diese Produkte.');
define('SUB_HEADING_TEXT_2', 'Jedes angemeldete Mitglied bekommt ein \'Mitgliedseinkaufswagen\' zum Einkaufen, mit dem er auch zu einem sp&auml;terem Zeitpunkt den Einkauf beenden kann. Jeder Artikel bleibt registriert bis das Mitglied zu der Kasse geht, oder die Produkte l&ouml;scht.');
define('SUB_HEADING_TEXT_3', 'Die Besuchereingaben werden automatisch bei Anmeldung in den Mitgliedseinkaufswagen gebucht.');
define('TEXT_CLOSE_WINDOW', '[ fenster schlie&szlig;en ]');
?>