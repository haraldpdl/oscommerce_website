<?
/*
German Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Best&auml;tigung');
define('TOP_BAR_TITLE', 'Bestellungswegweiser');
define('HEADING_TITLE', 'Ich bin zum Einkauf bereit!');
define('TABLE_HEADING_QUANTITY', 'Menge');
define('TABLE_HEADING_PRODUCTS', 'Produkte');
define('TABLE_HEADING_TOTAL', 'Summe');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Lieferadresse');
define('TABLE_HEADING_PAYMENT_METHOD', 'Zahlungsart');
define('SUB_TITLE_SUB_TOTAL', 'Zwischensumme:');
define('SUB_TITLE_TAX', 'Mwst. (' . TAX_VALUE . '%):');
define('SUB_TITLE_TOTAL', 'Summe:');
define('TEXT_CASH_ON_DELIVERY', 'Nachnahme');
define('TEXT_CREDIT_CARD', 'Kredit Karte');
define('TEXT_TYPE', 'Typ:');
define('TEXT_OWNER', 'Eigent&uuml;mer:');
define('TEXT_NUMBER', 'Nummer:');
define('TEXT_EXPIRES', 'G&uuml;ltig bis:');

define('IMAGE_PROCESS', 'Best&auml;tigung');
?>