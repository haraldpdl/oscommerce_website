<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'History');
define('NAVBAR_TITLE_3', 'Order Information');
define('TOP_BAR_TITLE', 'Order History');
define('HEADING_TITLE', 'Order Information');
define('TABLE_HEADING_QUANTITY', 'Qty.');
define('TABLE_HEADING_PRODUCT', 'Product');
define('TABLE_HEADING_TOTAL', 'Total');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Delivery Address');
define('TABLE_HEADING_PAYMENT_METHOD', 'Payment Method');
define('TABLE_SUBHEADING_SUBTOTAL', 'Sub-Total:');
define('TABLE_SUBHEADING_TAX', 'Tax');
define('TABLE_SUBHEADING_TOTAL', 'Total:');
define('TEXT_COD', 'Cash on Delivery');
define('TEXT_CC', 'Credit Card');

define('IMAGE_BACK', 'Back');
?>