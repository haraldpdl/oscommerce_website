<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Reviews');
define('TOP_BAR_TITLE', 'Product Reviews');
define('HEADING_TITLE', '%s Reviews');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_AUTHOR', 'Author');
define('TABLE_HEADING_RATING', 'Rating');
define('TABLE_HEADING_READ', 'Read');
define('TABLE_HEADING_DATE_ADDED', 'Date Added');
define('TEXT_OF_5_STARS', '%s of 5 Stars!');
define('TEXT_NO_REVIEWS', 'No reviews have been curently written for this product!');

define('IMAGE_WRITE_A_REVIEW', 'Write a Review');
define('IMAGE_BACK', 'Back');
?>