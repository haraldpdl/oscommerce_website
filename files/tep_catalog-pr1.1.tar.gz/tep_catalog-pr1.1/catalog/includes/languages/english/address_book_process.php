<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Address Book');
define('NAVBAR_TITLE_ADD_ENTRY', 'New Entry');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Modify Entry');
define('TOP_BAR_TITLE_ADD_ENTRY', 'Add A New Address Book Entry');
define('TOP_BAR_TITLE_MODIFY_ENTRY', 'Modify an Entry');
define('HEADING_TITLE_ADD_ENTRY', 'New Address Book Entry');
define('HEADING_TITLE_MODIFY_ENTRY', 'Address Book Entry');

define('IMAGE_INSERT', 'Insert');
define('IMAGE_CANCEL', 'Cancel');
define('IMAGE_UPDATE', 'Update');
define('IMAGE_DELETE', 'Delete');
?>