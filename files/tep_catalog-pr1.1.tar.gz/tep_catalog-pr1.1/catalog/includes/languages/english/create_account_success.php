<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Create an Account');
define('NAVBAR_TITLE_2', 'Success');
define('TOP_BAR_TITLE', 'Account Created Successfully!');
define('HEADING_TITLE', 'Your Account Has Been Created!');
define('TEXT_ACCOUNT_CREATED', 'Congrations! Your new account has been successfully created! You can now take advantage of member priviledges to enhance your online shopping experience with us. If you have <small><b>ANY</b></small> questions about the operation of this online shop, please email the webmaster at <a href="mailto:' . OWNER_EMAIL_ADDRESS . '">' . OWNER_EMAIL_ADDRESS . '</a>.<br><br>A confirmation has been sent to the provided email address. If you have not recieved it within the hour, please contact us.');

define('IMAGE_LETS_SHOP', 'Lets Shop!');
?>