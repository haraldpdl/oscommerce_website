<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'Login');
define('NAVBAR_TITLE_2', 'Password Forgotten');
define('TOP_BAR_TITLE', 'Password Forgotten');
define('HEADING_TITLE', 'I\'ve Forgotten My Password!');
define('ENTRY_EMAIL_ADDRESS', 'E-Mail Address:');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', '<font color="#ff0000"><b>NOTE:</b></font> The E-Mail Address was not found in our records, please try again.');
define('EMAIL_PASSWORD_REMINDER_SUBJECT', STORE_NAME . ' - Password Reminder');
define('EMAIL_PASSWORD_REMINDER_BODY', 'A password reminder was requested from ' . $REMOTE_ADDR . '.' . "\n\n" . 'Your password to \'' . STORE_NAME . '\' is:' . "\n\n" . '   %s' . "\n\n");

define('IMAGE_EMAIL_ME', 'E-Mail Me');
?>