<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Online Products');
define('HEADING_TITLE', 'Lets See What We\'ve Got Here');
define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_PRICE', 'Price');
define('TEXT_NO_PRODUCTS', 'There are no products to list in this category.');
define('TEXT_NUMBER_OF_PRODUCTS', 'Number of Products: ');
?>