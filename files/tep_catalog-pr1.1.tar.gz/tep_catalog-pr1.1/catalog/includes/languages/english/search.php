<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Search Results');
define('TOP_BAR_TITLE', 'Search Results');
define('HEADING_TITLE', 'Can\'t Find What Your Looking For?');
define('TABLE_HEADING_PRODUCTS_NAME', 'Products Name');
define('TABLE_HEADING_PRODUCTS_PRICE', 'Products Price');
define('TEXT_FOUND_MATCHES', 'Found %s matches..');
define('TEXT_MAXIMUM_SEARCH_RESULTS_REACHED', ' maximum search results reached');
?>