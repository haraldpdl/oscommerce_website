<?
/*
English Text for The Exchange Project Preview Release 1.1
Last Update: 14/05/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Reviews');
define('TOP_BAR_TITLE', '%s Reviews');
define('HEADING_TITLE', 'Have You Got Something To Say?');
define('SUB_TITLE_PRODUCT', 'Product:');
define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_REVIEW', 'Review:');
define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>NOTE:</b></font></small>&nbsp;HTML is not translated!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>BAD</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>GOOD</b></font></small>');

define('IMAGE_INSERT', 'Insert');
define('IMAGE_CANCEL', 'Cancel');
?>