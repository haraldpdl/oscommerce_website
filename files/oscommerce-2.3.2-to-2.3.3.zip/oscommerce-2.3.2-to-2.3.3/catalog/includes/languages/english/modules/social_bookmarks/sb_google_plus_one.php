<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_PLUS_ONE_TITLE', 'Google+ +1 Button');
  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_PLUS_ONE_DESCRIPTION', 'Recommend products through Google+ +1 Button.');
  define('MODULE_SOCIAL_BOOKMARKS_GOOGLE_PLUS_ONE_PUBLIC_TITLE', 'Recommend on Google+');
?>
