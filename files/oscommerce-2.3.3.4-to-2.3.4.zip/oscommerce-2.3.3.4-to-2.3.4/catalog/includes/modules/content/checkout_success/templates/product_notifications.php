<div class="contentText">
  <?php echo MODULE_CONTENT_CHECKOUT_SUCCESS_PRODUCT_NOTIFICATIONS_TEXT_NOTIFY_PRODUCTS; ?>

  <p class="productsNotifications">
    <?php echo $products_notifications; ?>
  </p>
</div>
