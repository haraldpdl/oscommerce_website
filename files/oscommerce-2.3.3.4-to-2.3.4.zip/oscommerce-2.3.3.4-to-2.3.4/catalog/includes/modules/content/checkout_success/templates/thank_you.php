<div class="contentText">
  <?php echo MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SUCCESS; ?>
</div>

<div class="contentText">
  <?php echo sprintf(MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_SEE_ORDERS, tep_href_link(FILENAME_ACCOUNT_HISTORY, '', 'SSL')) . '<br /><br />' . sprintf(MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_CONTACT_STORE_OWNER, tep_href_link(FILENAME_CONTACT_US)); ?>
</div>

<div class="contentText">
  <h3><?php echo MODULE_CONTENT_CHECKOUT_SUCCESS_TEXT_THANKS_FOR_SHOPPING; ?></h3>
</div>
