<?php
/*
  $Id: flat.php,v 1.7 2003/07/11 09:04:23 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FLAT_TEXT_TITLE', 'Pauschale Versandkosten');
define('MODULE_SHIPPING_FLAT_TEXT_DESCRIPTION', 'Pauschale Versandkosten');
define('MODULE_SHIPPING_FLAT_TEXT_WAY', '');
?>
