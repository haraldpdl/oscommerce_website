<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_CHRONOPAY_TEXT_TITLE', 'ChronoPay');
  define('MODULE_PAYMENT_CHRONOPAY_TEXT_PUBLIC_TITLE', 'Kreditkarte');
  define('MODULE_PAYMENT_CHRONOPAY_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://www.chronopay.com" style="text-decoration: underline; font-weight: bold;">ChronoPay Webseite besuchen</a>');
?>
