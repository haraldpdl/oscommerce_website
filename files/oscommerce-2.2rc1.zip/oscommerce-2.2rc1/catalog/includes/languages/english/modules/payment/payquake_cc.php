<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYQUAKE_CC_TEXT_TITLE', 'PayQuake (Credit Card)');
  define('MODULE_PAYMENT_PAYQUAKE_CC_TEXT_PUBLIC_TITLE', 'Credit Card');
  define('MODULE_PAYMENT_PAYQUAKE_CC_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://www.payquake.com" style="text-decoration: underline; font-weight: bold;">Visit PayQuake Website</a><br><br>PayQuake QuickSale Credit Card Processing<br><br>cURL is required for this module to function properly (either as an extension to PHP or as an executable program)');
  define('MODULE_PAYMENT_PAYQUAKE_CC_CREDIT_CARD_OWNER', 'Credit Card Owner:');
  define('MODULE_PAYMENT_PAYQUAKE_CC_CREDIT_CARD_NUMBER', 'Credit Card Number:');
  define('MODULE_PAYMENT_PAYQUAKE_CC_CREDIT_CARD_EXPIRES', 'Credit Card Expiry Date:');
  define('MODULE_PAYMENT_PAYQUAKE_CC_CREDIT_CARD_CVC', 'Credit Card Check Number (CVC):');
  define('MODULE_PAYMENT_PAYQUAKE_CC_ERROR_GENERAL', 'There has been an error processing your credit card. Please try again.');
  define('MODULE_PAYMENT_PAYQUAKE_CC_TEXT_ERROR', 'Credit Card Error!');
?>
