<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_TEXT_TITLE', 'iPayment');
  define('MODULE_PAYMENT_IPAYMENT_TEXT_PUBLIC_TITLE', 'Tarjeta de Cr&eacute;dito');
  define('MODULE_PAYMENT_IPAYMENT_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" style="text-decoration: underline; font-weight: bold;">Visita la web de iPayment</a>');
  define('IPAYMENT_ERROR_HEADING', 'Ha ocurrido un error procesando su tarjeta de cr&eacute;dito');
  define('IPAYMENT_ERROR_MESSAGE', '�Revise los datos de su tarjeta de cr&eacute;dito!');
  define('MODULE_PAYMENT_IPAYMENT_TEXT_CREDIT_CARD_OWNER', 'Titular de la Tarjeta:');
  define('MODULE_PAYMENT_IPAYMENT_TEXT_CREDIT_CARD_NUMBER', 'N&uacute;mero de la Tarjeta:');
  define('MODULE_PAYMENT_IPAYMENT_TEXT_CREDIT_CARD_EXPIRES', 'Fecha de Caducidad:');
  define('MODULE_PAYMENT_IPAYMENT_TEXT_CREDIT_CARD_CHECKNUMBER', 'N&uacute;mero de Comprobaci&oacute;n:');
?>
