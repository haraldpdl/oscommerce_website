<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPAL_IPN_TEXT_TITLE', 'PayPal IPN');
  define('MODULE_PAYMENT_PAYPAL_IPN_TEXT_PUBLIC_TITLE', 'PayPal');
  define('MODULE_PAYMENT_PAYPAL_IPN_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com/mrb/pal=PS2X9Q773CKG4" style="text-decoration: underline; font-weight: bold;">Visita la web de PayPal</a>');
?>
