<?php
/*
  $Id: itransact.php,v 1.4 2002/03/30 16:07:00 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Open Your Transaction Control Panel');
define('SUB_BAR_TITLE', 'Click the image below.  Your Gateway ID and Password are required.');

define('CPANEL_URL', 'https://secure.itransact.com/support/login.html');
define('CPANEL_URL_NAME', 'ctrlpan');
?>