<?php
/*
  $Id: configuration.php,v 1.7 2002/01/04 03:51:40 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_CONFIGURATION_TITLE', 'Titulo');
define('TABLE_HEADING_CONFIGURATION_VALUE', 'Valor');
define('TABLE_HEADING_ACTION', 'Accion');

define('TEXT_INFO_EDIT_INTRO', 'Haga los cambios necesarios');
define('TEXT_INFO_DATE_ADDED', 'Fecha de Alta:');
define('TEXT_INFO_LAST_MODIFIED', 'Ultima Modificacion:');
?>