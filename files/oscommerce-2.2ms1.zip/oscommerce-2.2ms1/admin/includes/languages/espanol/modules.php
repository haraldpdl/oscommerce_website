<?php
/*
  $Id: modules.php,v 1.6 2002/04/03 23:25:41 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE_MODULES_PAYMENT', 'Modulos de Pago');
define('HEADING_TITLE_MODULES_SHIPPING', 'Modulos de Envio');
define('HEADING_TITLE_MODULES_ORDER_TOTAL', 'Order Total Modules');

define('TABLE_HEADING_MODULES', 'Modulos');
define('TABLE_HEADING_SORT_ORDER', 'Sort Order');
define('TABLE_HEADING_STATUS', 'Estado');
define('TABLE_HEADING_ACTION', 'Accion');

define('TEXT_MODULE_DIRECTORY', 'Directorio para Modulos:');
?>
