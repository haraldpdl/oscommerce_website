<?php
/*
  $Id: stats_products_purchased.php,v 1.4 2002/03/30 16:21:18 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Productos Mas Comprados');

define('TABLE_HEADING_NUMBER', 'N�');
define('TABLE_HEADING_PRODUCTS', 'Productos');
define('TABLE_HEADING_PURCHASED', 'Comprados');
?>