<?php
/*
  $Id: packingslip.php,v 1.1 2002/06/11 17:41:56 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Comentario');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Productos');

define('ENTRY_SOLD_TO', 'VENDIDO A:');
define('ENTRY_SHIP_TO', 'ENVIAR A');
define('ENTRY_PAYMENT_METHOD', 'M�todo de Pago:');
?>
