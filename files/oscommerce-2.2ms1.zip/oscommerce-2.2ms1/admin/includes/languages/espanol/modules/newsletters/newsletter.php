<?php
/*
  $Id: newsletter.php,v 1.1 2002/03/09 20:18:24 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Clientes que recibiran el boletin: %s');
?>