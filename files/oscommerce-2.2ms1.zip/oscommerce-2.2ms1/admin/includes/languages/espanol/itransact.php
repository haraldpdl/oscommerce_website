<?php
/*
  $Id: itransact.php,v 1.4 2002/03/30 16:21:18 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Acceda a su Panel de Control');
define('SUB_BAR_TITLE', 'Haga click en la imagen. Necesitaras tu ID y contrase&ntilde;a para acceder.');

define('CPANEL_URL', 'https://secure.itransact.com/support/login.html');
define('CPANEL_URL_NAME', 'ctrlpan');
?>