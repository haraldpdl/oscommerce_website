<?php
/*
  $Id: product_reviews.php,v 1.5 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');
define('HEADING_TITLE', '%s Reviews');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_AUTHOR', 'Author');
define('TABLE_HEADING_RATING', 'Rating');
define('TABLE_HEADING_READ', 'Read');
define('TABLE_HEADING_DATE_ADDED', 'Date Added');
define('TEXT_OF_5_STARS', '%s of 5 Stars!');
define('TEXT_NO_REVIEWS', 'No reviews have been curently written for this product!');
?>