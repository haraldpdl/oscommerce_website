<?php
/*
  $Id: product_reviews_write.php,v 1.6 2003/02/06 14:11:52 thomasamoulton Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');
define('HEADING_TITLE', 'Have You Got Something To Say?');
define('SUB_TITLE_PRODUCT', 'Product:');
define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_REVIEW', 'Review:');
define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>NOTE:</b></font></small>&nbsp;HTML is not translated!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>BAD</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>GOOD</b></font></small>');
define('ERROR_INVALID_PRODUCT', 'That product is no longer available. Please try again.');
?>
