<?php
/*
  $Id: address_book_process.php,v 1.7 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Address Book');
define('NAVBAR_TITLE_ADD_ENTRY', 'New Entry');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Modify Entry');
define('HEADING_TITLE_ADD_ENTRY', 'New Address Book Entry');
define('HEADING_TITLE_MODIFY_ENTRY', 'Address Book Entry');
?>