<?php
/*
  $Id: advanced_search_result.php,v 1.10 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE1', 'Search');
define('NAVBAR_TITLE2', 'Search Results');
define('HEADING_TITLE', 'Products meeting the search criteria');
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS', 'Product Name');
define('TABLE_HEADING_MANUFACTURER', 'Manufacturer');
define('TABLE_HEADING_QUANTITY', 'Quantity');
define('TABLE_HEADING_PRICE', 'Price');
define('TABLE_HEADING_WEIGHT', 'Weight');
define('TABLE_HEADING_BUY_NOW', 'Buy Now');
define('TEXT_NO_PRODUCTS', 'There is no product that matches the search criteria.');
define('TEXT_NO_PRODUCTS2', 'There is no product that matches the search criteria.');
define('TEXT_BUY', 'Buy 1 \'');
define('TEXT_NOW', '\' now');
?>