<?php
/*
  $Id: address_book.php,v 1.6 2002/05/23 22:56:20 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Address Book');
define('HEADING_TITLE', 'My Personal Address Book');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_LOCATION', 'Location');
define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'You have no entries in your address book!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTE:</b></font> A maximum of %s address book entries allowed.');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>NOTE:</b></font> Maximum of %s address book entries reached.');
?>