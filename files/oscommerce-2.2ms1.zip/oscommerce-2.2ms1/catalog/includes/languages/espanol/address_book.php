<?php
/*
  $Id: address_book.php,v 1.7 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Otras Direcciones');
define('HEADING_TITLE', 'Otras Direcciones de Envio');
define('TABLE_HEADING_NUMBER', 'N�');
define('TABLE_HEADING_NAME', 'Nombre');
define('TABLE_HEADING_LOCATION', 'Lugar');
define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'No tiene ningun direccion alternativa!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> Se permiten un maximo de %s direcciones.');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>NOTA:</b></font> Se ha alcanzado el tope de %s direcciones.');
?>