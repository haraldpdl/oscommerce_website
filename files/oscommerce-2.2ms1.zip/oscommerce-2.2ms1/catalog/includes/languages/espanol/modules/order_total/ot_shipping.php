<?php
/*
  $Id: ot_shipping.php,v 1.3 2003/02/05 22:34:46 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Gastos de Envio');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Gastos de Envio del Pedido');

  define('FREE_SHIPPING_TITLE', 'Free Shipping');
  define('FREE_SHIPPING_DESCRIPTION', 'Free shipping for orders over %s');
?>
