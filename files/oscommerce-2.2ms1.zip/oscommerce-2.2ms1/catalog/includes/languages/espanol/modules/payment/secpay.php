<?php
/*
  $Id: secpay.php,v 1.7 2002/11/19 01:34:56 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_SECPAY_TEXT_TITLE', 'SECPay');
  define('MODULE_PAYMENT_SECPAY_TEXT_DESCRIPTION', 'Tarjeta de Credito para Pruebas:<br><br>Numero: 4444333322221111<br>Caducidad Cualquiera');
  define('MODULE_PAYMENT_SECPAY_TEXT_ERROR', 'Error de Tarjeta de Credito!');
  define('MODULE_PAYMENT_SECPAY_TEXT_ERROR_MESSAGE', 'Ha ocurrido un error procesando su tarjeta de credito. Por favor, intentelo de nuevo.');
?>
