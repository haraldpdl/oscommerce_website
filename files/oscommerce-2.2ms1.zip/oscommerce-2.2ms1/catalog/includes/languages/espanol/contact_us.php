<?php
/*
  $Id: contact_us.php,v 1.6 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Contactenos');
define('NAVBAR_TITLE', 'Contactenos');
define('TEXT_SUCCESS', 'Su consulta ha sido enviada al encargado de la tienda.');
define('EMAIL_SUBJECT', 'Consulta desde ' . STORE_NAME);

define('ENTRY_NAME', 'Nombre Completo:');
define('ENTRY_EMAIL', 'Direccion E-Mail:');
define('ENTRY_ENQUIRY', 'Consulta:');
?>