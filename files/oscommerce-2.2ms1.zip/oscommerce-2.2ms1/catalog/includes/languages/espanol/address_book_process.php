<?php
/*
  $Id: address_book_process.php,v 1.6 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Otras Direcciones');
define('NAVBAR_TITLE_ADD_ENTRY', 'Nueva Direccion');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Modificar Direccion');
define('HEADING_TITLE_ADD_ENTRY', 'Nueva Direccion');
define('HEADING_TITLE_MODIFY_ENTRY', 'Direccion');
?>