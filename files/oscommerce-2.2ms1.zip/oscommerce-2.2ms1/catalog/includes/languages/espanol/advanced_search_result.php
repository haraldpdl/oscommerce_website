<?php
/*
  $Id: advanced_search_result.php,v 1.12 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE1', 'B�squeda');
define('NAVBAR_TITLE2', 'Resultados de la B�squeda');
define('HEADING_TITLE', 'Productos que satisfacen los criterios de b�squeda');
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Modelo');
define('TABLE_HEADING_PRODUCTS', 'Descripcion');
define('TABLE_HEADING_MANUFACTURER', 'Fabricante');
define('TABLE_HEADING_QUANTITY', 'Cantidad');
define('TABLE_HEADING_PRICE', 'Precio');
define('TABLE_HEADING_WEIGHT', 'Peso');
define('TABLE_HEADING_BUY_NOW', 'Compre Ahora');
define('TEXT_NO_PRODUCTS', 'No hay productos que corresponden con los criterios de b�squeda.');
define('TEXT_NO_PRODUCTS2', 'No hay productos que corresponden con los criterios de b�squeda.');
define('TEXT_BUY', 'Compre 1 \'');
define('TEXT_NOW', '\' ahora');
?>