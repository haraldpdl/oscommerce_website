<?php
/*
  $Id: account_history.php,v 1.7 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Historial');

define('HEADING_TITLE', 'Historial de Pedidos');

define('TEXT_ORDER_NUMBER', 'Pedido Numero:');
define('TEXT_ORDER_STATUS', 'Estado:');
define('TEXT_ORDER_DATE', 'Fecha:');
define('TEXT_ORDER_SHIPPED_TO', 'Enviado A:');
define('TEXT_ORDER_PRODUCTS', 'Productos:');
define('TEXT_ORDER_COST', 'Precio:');
define('TEXT_VIEW_ORDER', 'Ver Pedido');

define('TEXT_NO_PURCHASES', 'No ha realizado ningun pedido aun...');
?>