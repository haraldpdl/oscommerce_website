<?php
/*
  $Id: product_reviews_write.php,v 1.7 2003/02/06 14:11:52 thomasamoulton Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');
define('HEADING_TITLE', '�Tienes algo que decir?');
define('SUB_TITLE_PRODUCT', 'Producto:');
define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_REVIEW', 'Comentario:');
define('SUB_TITLE_RATING', 'Evaluacion:');
define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>NOTA:</b></font></small>&nbsp;No se traduce el codigo HTML!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>MALO</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>BUENO</b></font></small>');
define('ERROR_INVALID_PRODUCT', 'That product is no longer available. Please try again.');
?>
