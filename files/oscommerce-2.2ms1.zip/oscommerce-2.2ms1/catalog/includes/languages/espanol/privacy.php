<?php
/*
  $Id: privacy.php,v 1.4 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Confidencialidad');
define('HEADING_TITLE', 'Confidencialidad');

define('TEXT_INFORMATION', 'Ponga aqui informacion sobre el tratamiento de los datos.');
?>
