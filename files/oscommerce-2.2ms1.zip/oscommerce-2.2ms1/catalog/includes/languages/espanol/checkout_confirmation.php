<?php
/*
  $Id: checkout_confirmation.php,v 1.19 2003/02/06 17:38:16 thomasamoulton Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Realizar Pedido');
define('NAVBAR_TITLE_2', 'Confirmaci�n');

define('HEADING_TITLE', 'Estoy preparado para Comprar!');

define('HEADING_DELIVERY_ADDRESS', 'Direcci�n de Entrega');
define('HEADING_SHIPPING_METHOD', 'Forma de Envio');
define('HEADING_PRODUCTS', 'Producto');
define('HEADING_TAX', 'Impuestos');
define('HEADING_TOTAL', 'Total');
define('HEADING_BILLING_INFORMATION', 'Datos de Facturacion');
define('HEADING_BILLING_ADDRESS', 'Direccion de Facturacion');
define('HEADING_PAYMENT_METHOD', 'Forma de Pago');
define('HEADING_PAYMENT_INFORMATION', 'Datos del Pago');
define('HEADING_ORDER_COMMENTS', 'Comentarios Sobre Su Orden');

define('TEXT_EDIT', 'Cambio');
?>
