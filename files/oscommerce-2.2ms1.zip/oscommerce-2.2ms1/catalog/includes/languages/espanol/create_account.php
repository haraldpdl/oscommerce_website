<?php
/*
  $Id: create_account.php,v 1.7 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Crear una Cuenta');
define('HEADING_TITLE', 'Informacion de Mi Cuenta');
define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>NOTA:</b></font></small> Si ya tiene una cuenta con nosotros, por favor use esta pagina para <a href="%s"><u>Entrar</u></a>.');
?>