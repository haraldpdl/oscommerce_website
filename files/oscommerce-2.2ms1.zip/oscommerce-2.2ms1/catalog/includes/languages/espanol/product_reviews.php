<?php
/*
  $Id: product_reviews.php,v 1.5 2002/11/12 00:45:21 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');
define('HEADING_TITLE', '%s Comentarios');
define('TABLE_HEADING_NUMBER', 'N�');
define('TABLE_HEADING_AUTHOR', 'Autor');
define('TABLE_HEADING_RATING', 'Evaluacion');
define('TABLE_HEADING_READ', 'Leer');
define('TABLE_HEADING_DATE_ADDED', 'Fecha Alta');
define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');
define('TEXT_NO_REVIEWS', 'No hay comentarios escritos para este producto!');
?>