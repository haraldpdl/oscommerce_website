<?php
/*
  $Id: info_shopping_cart.php,v 1.6 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Besucherwarenkorb / Kundenwarenkorb');
define('SUB_HEADING_TITLE_1', 'Besucherwarenkorb');
define('SUB_HEADING_TITLE_2', 'Kundenwarenkorb');
define('SUB_HEADING_TITLE_3', 'Information');
define('SUB_HEADING_TEXT_1', 'Jeder Besucher unseres Online-Shops bekommt einen \'Besucherwarenkorb\'. Damit kann er seine ausgew&auml;hlten Produkte sammeln. Sobald der Besucher den Online-Shop verl&auml;sst, verf&auml;llt dessen Inhalt.');
define('SUB_HEADING_TEXT_2', 'Jeder angemeldete Kunde verf&uuml;gt &uuml;ber einen \'Kundenwarenkorb\' zum Einkaufen, mit dem er auch zu einem sp&auml;terem Zeitpunkt den Einkauf beenden kann. Jeder Artikel bleibt darin registriert bis der Kunde zur Kasse geht, oder die Produkte darin l&ouml;scht.');
define('SUB_HEADING_TEXT_3', 'Die Besuchereingaben werden automatisch bei der Registrierung als Kunde in den Kundenwarenkorb &uuml;bernommen.');
define('TEXT_CLOSE_WINDOW', '<b><u>[Fenster schliessen]</b></u>');
?>