<?php
/*
  $Id: product_reviews.php,v 1.7 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Meinungen');
define('HEADING_TITLE', 'Meinungen zu \'%s\'');
define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_AUTHOR', 'Autor');
define('TABLE_HEADING_RATING', 'Bewertung');
define('TABLE_HEADING_READ', 'Gelesen');
define('TABLE_HEADING_DATE_ADDED', 'Datum');
?>