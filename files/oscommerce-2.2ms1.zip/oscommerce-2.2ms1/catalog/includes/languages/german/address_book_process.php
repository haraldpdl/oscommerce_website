<?php
/*
  $Id: address_book_process.php,v 1.12 2003/02/16 00:42:02 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Ihr Konto');
define('NAVBAR_TITLE_2', 'Adressbuch');
define('NAVBAR_TITLE_ADD_ENTRY', 'Neuer Eintrag');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Eintrag &auml;ndern');
define('HEADING_TITLE_ADD_ENTRY', 'Adressbuch: Neuer Eintrag');
define('HEADING_TITLE_MODIFY_ENTRY', 'Adressbuch: Eintrag &auml;ndern');
?>