<?php
/*
  $Id: account_history.php,v 1.14 2003/02/16 00:42:02 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Ihr Konto');
define('NAVBAR_TITLE_2', 'Ihre get&auml;tigten Bestellungen');

define('HEADING_TITLE', 'Ihre get&auml;tigten Bestellungen');

define('TEXT_ORDER_NUMBER', 'Bestellnummer:');
define('TEXT_ORDER_STATUS', 'Bestellstatus:');
define('TEXT_ORDER_DATE', 'Bestelldatum:');
define('TEXT_ORDER_SHIPPED_TO', 'Versenden an:');
define('TEXT_ORDER_PRODUCTS', 'Artikel:');
define('TEXT_ORDER_COST', 'Summe:');
define('TEXT_VIEW_ORDER', 'Bestellung ansehen');

define('TEXT_NO_PURCHASES', 'Sie haben noch keine Bestellungen get&auml;tigt.');
?>