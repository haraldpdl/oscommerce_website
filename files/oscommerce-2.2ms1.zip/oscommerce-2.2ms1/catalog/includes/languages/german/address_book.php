<?php
/*
  $Id: address_book.php,v 1.13 2003/02/16 00:42:02 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Ihr Konto');
define('NAVBAR_TITLE_2', 'Adressbuch');
define('HEADING_TITLE', 'Folgende Eintr&auml;ge verbinden wir z.Z. mit Ihrem Konto:');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_LOCATION', 'Wohnort');

define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'Sie haben noch keine Eintr&auml;ge in Ihrem Adressbuch!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>Hinweis:</b></font> Ihnen stehen %s Adressbucheintr&auml;ge zur Verf&uuml;gung!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben die maximale Anzahl (%s) an Adressbucheintr&auml;gen erreicht!');
?>