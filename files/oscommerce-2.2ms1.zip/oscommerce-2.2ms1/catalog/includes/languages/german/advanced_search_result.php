<?php
/*
  $Id: advanced_search_result.php,v 1.12 2003/02/16 00:42:02 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE1', 'Erweiterte Suche');
define('NAVBAR_TITLE2', 'Suchergebnisse');
define('HEADING_TITLE', 'Artikel, welche den Suchkriterien entsprechen');
define('TABLE_HEADING_IMAGE', '');
define('TABLE_HEADING_MODEL', 'Artikelnummer');
define('TABLE_HEADING_PRODUCTS', 'Bezeichnung');
define('TABLE_HEADING_MANUFACTURER', 'Hersteller');
define('TABLE_HEADING_QUANTITY', 'Anzahl');
define('TABLE_HEADING_PRICE', 'Einzelpreis');
define('TABLE_HEADING_WEIGHT', 'Gewicht');
define('TABLE_HEADING_BUY_NOW', 'jetzt bestellen');
define('TEXT_NO_PRODUCTS', 'Es wurden keine Artikel gefunden, die den Suchkriterien entsprechen.');
define('TEXT_NO_PRODUCTS2', 'Es wurden keine Artikel gefunden, die den Suchkriterien entsprechen.');
define('TEXT_BUY', '1 x \'');
define('TEXT_NOW', '\' bestellen');
?>