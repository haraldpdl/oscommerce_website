<?php
/*
  $Id: ot_total.php,v 1.2 2002/04/17 12:01:46 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_TOTAL_TITLE', '<b>Summe</b>');
  define('MODULE_ORDER_TOTAL_TOTAL_DESCRIPTION', 'Summe der Bestellung');
?>