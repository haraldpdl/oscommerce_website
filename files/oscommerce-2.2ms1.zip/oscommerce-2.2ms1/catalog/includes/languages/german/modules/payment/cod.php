<?php
/*
  $Id: cod.php,v 1.7 2002/04/17 20:31:18 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_COD_TEXT_TITLE', 'Nachnahme');
  define('MODULE_PAYMENT_COD_TEXT_DESCRIPTION', 'Nachnahme');
?>