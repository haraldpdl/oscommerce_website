# osCommerce Online Merchant
#
# @copyright Copyright (c) 2011 osCommerce; http://www.oscommerce.com
# @license BSD License; http://www.oscommerce.com/bsdlicense.txt

admin_dashboard_module_errorlog_title = Error Log
admin_dashboard_module_errorlog_table_heading_date = Date
admin_dashboard_module_errorlog_table_heading_message = Message
admin_dashboard_module_errorlog_no_errors_found = No errors found.
admin_dashboard_module_errorlog_not_writable = Cannot write to %s