<? include("includes/sysenv.php"); ?>
<?
  if (($HTTP_GET_VARS["action"] == "delete_customer") && ($HTTP_GET_VARS["customers_id"])) {
    $db_query("delete from customers where customers_id = $HTTP_GET_VARS[customers_id]");
    $db_query("delete from customers_info where customers_id = $HTTP_GET_VARS[customers_id]");
    $db_query("delete from customers_basket where customers_id = $HTTP_GET_VARS[customers_id]");
    $reviews = $db_query("select reviews_id from reviews_extra where customers_id = $HTTP_GET_VARS[customers_id]");
    while ($reviews_values = $db_fetch_array($reviews)) {
      $db_query("delete from reviews where reviews_id = $reviews_values[reviews_id]");
    }
    $db_query("delete from reviews_extra where customers_id = $HTTP_GET_VARS[customers_id]");
    $address_book = $db_query("select address_book_id from address_book_to_customers where customers_id = $HTTP_GET_VARS[customers_id]");
    while ($address_book_values = $db_fetch_array($address_book)) {
      $db_query("delete from address_book where address_book_id = $address_book_values[address_book_id]");
    }
    $db_query("delete from address_book_to_customers where customers_id = $HTTP_GET_VARS[customers_id]");
    header("Location: customers.php");
  }
?>

<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/customers_modify.php?order_by="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Customers&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  if ($HTTP_GET_VARS["customers_id"]) {
    $customers = $db_query("select customers_gender, customers_firstname, customers_lastname, customers_dob, customers_email_address, customers_street_address, customers_suburb, customers_postcode, customers_city, customers_state, customers_country, customers_telephone, customers_fax from customers where customers_id = $HTTP_GET_VARS[customers_id]");
    $customers_values = $db_fetch_array($customers);
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Delete Customer&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_account.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="100%"><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Personal ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Gender:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?
  if ($customers_values["customers_gender"] == "m") {
    echo 'Male';
  } else {
    echo 'Female';
  } ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;First Name:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_firstname"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Last Name:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_lastname"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Date of Birth:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?
  $dob_formatted = date("l, jS F, Y", mktime(0,0,0,substr($customers_values["customers_dob"], 4, 2),substr($customers_values["customers_dob"], -2),substr($customers_values["customers_dob"], 0, 4)));
  echo $dob_formatted; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;E-Mail Address:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_email_address"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Address ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Street Address:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_street_address"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Suburb:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_suburb"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Post Code:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_postcode"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;City:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_city"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;State:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_state"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Country:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_country"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Contact ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Telephone No.:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_telephone"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Fax No.:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?=$customers_values["customers_fax"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Password ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Password:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;--HIDDEN--&nbsp;</small></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><a href="customers_remove.php?action=delete_customer&customers_id=<?=$HTTP_GET_VARS["customers_id"];?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;&nbsp;<a href="customers_remove.php"><img src="images/button_cancel.gif" width="50" height="14" border="0" alt=" cancel "></a>&nbsp;&nbsp;</font></td>
      </tr>
<?
  } else {
    if ($HTTP_GET_VARS["order_by"]) {
      $order_by = $HTTP_GET_VARS["order_by"];
    } else {
      $order_by = "customers_id";
    }
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Customers&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="customers_lastname"<? if ($order_by == "customers_lastname") { echo ' SELECTED'; } ?>>customers_lastname</option><option value="customers_id"<? if ($order_by == "customers_id") { echo ' SELECTED'; } ?>>customers_id</option><option value="customers_country"<? if ($order_by == "customers_country") { echo ' SELECTED'; } ?>>customers_country</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="customers" action="customers.php?action=add_customers" method="post" onSubmit="return checkForm();">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;customers_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers_firstname&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers_lastname&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers_country&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    $customers = $db_query("select customers_id, customers_firstname, customers_lastname, customers_city, customers_country from customers order by $order_by");
    while ($customers_values = $db_fetch_array($customers)) {
      $rows++;
      if (floor($rows/2) == ($rows/2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_firstname"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_lastname"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_country"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="customers_remove.php?customers_id=<?=$customers_values["customers_id"];?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;</font></td>
          </tr>
<?
      $ids[] = $customers_values["customers_id"];
      rsort($ids);
      $next_id = ($ids[0] + 1);
    }
?>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr></form>
<?
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>