<?
//  session_start(); // we dont use sessions on the administration..
  
// define our database connection and query variables

  $db_server = $HTTP_ENV_VARS["HOSTNAME"];
  $db_server_user = "mysql";
  $db_server_user_password = "";
  $db_database = "catalog";
  
  $db_pconnect = "mysql_pconnect"; // yah, persistent connections..
  $db_select_db = "mysql_select_db";

  $db_query = "mysql_query";
  $db_fetch_row = "mysql_fetch_row";
  $db_fetch_array = "mysql_fetch_array";
  $db_num_rows = "mysql_num_rows";
  $db_insert_id = "mysql_insert_id";
  $db_free_result = "mysql_free_result";
  $db_data_seek = "mysql_data_seek";
  
  $db_link = $db_pconnect("$db_server","$db_server_user","$db_server_user_password");
  $db_select_db("$db_database", $db_link);

  $document_root = "/opt/www"; // needed for image checking (file_exists)
  $admin_root = "/admin"; // where the admin pages are stored after server_root
  $catalog_root = "/catalog"; // where catalog pages are stored after server_root
?>