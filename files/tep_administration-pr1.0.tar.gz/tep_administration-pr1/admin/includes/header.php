<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor="#AABBDD">
    <td align="left" valign="middle"><img src="images/header_exchange_logo.gif" width="57" height="50" border="0" alt="The Exchange Project"><img src="images/pixel_trans.gif" width="6" height="1" border="0" alt=""><img src="images/header_exchange.gif" width="351" height="50" border="0" alt="The Exchange Project"></td>
    <td align="right"><a href="http://theexchangeproject.org"><img src="images/header_support.gif" width="50" height="50" border="0" alt=" Support Site "></a>&nbsp;&nbsp;<a href="/catalog/default.php"><img src="images/header_checkout.gif" width="53" height="50" border="0" alt=" Online Demo "></a>&nbsp;&nbsp;<a href="default.php"><img src="images/header_administration.gif" width="50" height="50" border="0" alt=" Administration "></a>&nbsp;&nbsp;</td>
  </tr>
  <tr bgcolor="#000000" height="19">
    <td align="left"><font face="Verdana, Arial" color="#FFFFFF" size="2"><b>&nbsp;&nbsp;<a href="default.php" class="whitelink">Administration</a></b></font></td>
    <td align="right"><font face="Verdana, Arial" color="#FFFFFF" size="2"><b><a href="http://theexchangeproject.org" class="whitelink">Support&nbsp;Site</a> &nbsp;|&nbsp; <a href="/catalog/default.php" class="whitelink">Online&nbsp;Demo</a> &nbsp;|&nbsp; <a href="default.php" class="whitelink">Administration</a>&nbsp;&nbsp;</b></font></td>
  </tr>
</table>
