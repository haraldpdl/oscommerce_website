          <tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;Customers&nbsp;</font></td>
          </tr>
          <tr>
            <td nowrap><font face="Verdana, Arial" size="1">&nbsp;<u>Customers</u>&nbsp;<br>&nbsp;&nbsp;&middot;&nbsp;<? if ($PHP_SELF == $admin_root . "/customers.php") { echo '<b>Add / Display</b>'; } else { echo '<a href="customers.php">Add / Display</a>'; } ?>&nbsp;<br>&nbsp;&nbsp;&middot;&nbsp;<? if ($PHP_SELF == $admin_root . "/customers_modify.php") { echo '<b>Modify</b>'; } else { echo '<a href="customers_modify.php">Modify</a>'; } ?>&nbsp;<br>&nbsp;&nbsp;&middot;&nbsp;<? if ($PHP_SELF == $admin_root . "/customers_remove.php") { echo '<b>Remove</b>'; } else { echo '<a href="customers_remove.php">Remove</a>'; } ?>&nbsp;<br></font></td>
          </tr>
