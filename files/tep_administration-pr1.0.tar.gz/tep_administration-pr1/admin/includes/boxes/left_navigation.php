<!-- contents //-->
<?
  include("includes/boxes/contents.php");
?>
<!-- contents_eof //-->
<!-- customers //-->
<?
  include("includes/boxes/customers.php");
?>
<!-- customers_eof //-->
<!-- statistics //-->
<?
  include("includes/boxes/statistics.php");
?>
<!-- statistics_eof //-->
