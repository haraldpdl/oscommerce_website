          <tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;Statistics&nbsp;</font></td>
          </tr>
          <tr>
            <td nowrap><font face="Verdana, Arial" size="1">&nbsp;<u>Products</u>&nbsp;<br>&nbsp;&nbsp;&middot;&nbsp;<? if ($PHP_SELF == $admin_root . "/stats_products_viewed.php") { echo '<b>Most Viewed</b>'; } else { echo '<a href="stats_products_viewed.php">Most Viewed</a>'; } ?>&nbsp;<br>&nbsp;&nbsp;&middot;&nbsp;<? if ($PHP_SELF == $admin_root . "/stats_products_purchased.php") { echo '<b>Most Purchased</b>'; } else { echo '<a href="stats_products_purchased.php">Most Purchased</a>'; } ?>&nbsp;<br>&nbsp;<u>Customers</u>&nbsp;<br>&nbsp;&nbsp;&middot;&nbsp;<? if ($PHP_SELF == $admin_root . "/stats_customers.php") { echo '<b>Most Total</b>'; } else { echo '<a href="stats_customers.php">Most Total</a>'; } ?>&nbsp;<br></font></td>
          </tr>
