<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if (($HTTP_GET_VARS["action"] == "update_products")) {
      $db_query("update products set products_name = '$HTTP_POST_VARS[products_name]', products_description = '$HTTP_POST_VARS[products_description]', products_quantity = $HTTP_POST_VARS[products_quantity], products_model = '$HTTP_POST_VARS[products_model]', products_image = '$HTTP_POST_VARS[products_image]', products_url = '$HTTP_POST_VARS[products_url]', products_price = $HTTP_POST_VARS[products_price] where products_id = $HTTP_POST_VARS[products_id]");
/* manufacturers */
      $manufacturers_id = $HTTP_POST_VARS["manufacturers_id"];
      $number_manufacturers = sizeof($manufacturers_id);
      for ($i=0;$i<$number_manufacturers;$i++) {
        $manufacturer_info = explode("_", $manufacturers_id[$i]); // products_to_manufacturers_id . "_" . manufacturers_id
        $check_link = $db_query("select products_id, manufacturers_id from products_to_manufacturers where products_to_manufacturers_id = '   $manufacturer_info[0]'");
        $check_link_values = $db_fetch_array($check_link);
        if ($check_link_values["manufacturers_id"] == $manufacturer_info[1]) {
          $manufacturers_id_match = "1"; // manufacturers match.. no updated needed
        } else {
          $manufacturers_id_match = "0"; // manufactuers mismatch.. update or remove?
        }
        if ($manufacturers_id_match == "0") {
          if ($manufacturer_info[1] == "none") { // the manufacturer has been updated to be deleted..
            $db_query("delete from products_to_manufacturers where products_to_manufacturers_id = $manufacturer_info[0]");
          } else { // the manufacturer has been updated to another manufacturer
            $db_query("update products_to_manufacturers set manufacturers_id = $manufacturer_info[1] where products_to_manufacturers_id = $manufacturer_info[0]");
          }
        }
        if (($manufacturer_info[0]) && (!$manufacturer_info[1])) { // insert a new manufacturer
          $db_query("insert into products_to_manufacturers values ('', $HTTP_POST_VARS[products_id], $manufacturer_info[0])");
        }
      }
/* subcategories */
      $subcategories_id = $HTTP_POST_VARS["subcategories_id"];
      $number_subcategories = sizeof($subcategories_id);
      for ($i=0;$i<$number_subcategories;$i++) {
        $subcategory_info = explode("_", $subcategories_id[$i]); // products_to_subcategories_id . "_" . subcategories_id
        $check_link = $db_query("select products_id, subcategories_id from products_to_subcategories where products_to_subcategories_id = '   $subcategory_info[0]'");
        $check_link_values = $db_fetch_array($check_link);
        if ($check_link_values["subcategories_id"] == $subcategory_info[1]) {
          $subcategories_id_match = "1"; // subcategories match.. no updated needed
        } else {
          $subcategories_id_match = "0"; // subcategories mismatch.. update or remove?
        }
        if ($subcategories_id_match == "0") {
          if ($subcategory_info[1] == "none") { // the subcategory has been updated to be deleted..
            $db_query("delete from products_to_subcategories where products_to_subcategories_id = $subcategory_info[0]");
          } else { // the subcategory has been updated to another subcategory
            $db_query("update products_to_subcategories set subcategories_id = $subcategory_info[1] where products_to_subcategories_id = $subcategory_info[0]");
          }
        }
        if (($subcategory_info[0]) && (!$subcategory_info[1])) { // insert a new subcategory
          $db_query("insert into products_to_subcategories values ('', $HTTP_POST_VARS[products_id], $subcategory_info[0])");
        }
      }
      header("Location: products_modify.php?products_id=" . $HTTP_POST_VARS["products_id"]);
    }
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<?
  if ($HTTP_GET_VARS["products_id"]) {
?>
<script language="javascript"><!--
function checkForm(form) {
  var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
  var error = 0;
  var products_description = document.products.products_description.value;
  var products_price = document.products.products_price.value;
  var products_quantity = document.products.products_quantity.value;
  var products_model = document.products.products_model.value;
  var products_image = document.products.products_image.value;

  if (products_description.length < 1) {
    error_message = error_message + "* The new product needs a description\n";
    error = 1;
  }

  if (products_price.length < 1) {
    error_message = error_message + "* The new product needs a price value\n";
    error = 1;
  }

  if (products_quantity.length < 1) {
    error_message = error_message + "* The new product needs a quantity value\n";
    error = 1;
  }

  if (products_model.length < 1) {
    error_message = error_message + "* The new product needs a model value\n";
    error = 1;
  }

  if (products_image.length < 1) {
    error_message = error_message + "* The new product needs an image value\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
<?
  }
?>
<script language="javascript"><!--
function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/products_modify.php?order_by="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Products&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  if ($HTTP_GET_VARS["products_id"]) {
    $products = $db_query("select products_id, products_name, products_description, products_quantity, products_model, products_image, products_url, products_price from products where products_id = '$HTTP_GET_VARS[products_id]'");
    $products_values = $db_fetch_array($products);
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;"<?=$products_values["products_name"];?>"&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/pixel_trans.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="products" action="products_modify.php?action=update_products" method="post" onSubmit="return checkForm();">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Products Name:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_name" value="<?=$products_values["products_name"];?>">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Manufacturers:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?
    $products_manufacturers = $db_query("select manufacturers.manufacturers_id, products_to_manufacturers.products_to_manufacturers_id from manufacturers, products_to_manufacturers where products_to_manufacturers.products_id = '$products_values[products_id]' and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by manufacturers.manufacturers_name");
    $manufacturers = $db_query("select manufacturers.manufacturers_id, manufacturers.manufacturers_name, category_top.category_top_name from manufacturers, manufacturers_to_category, category_top where manufacturers.manufacturers_id = manufacturers_to_category.manufacturers_id and manufacturers_to_category.category_top_id = category_top.category_top_id order by manufacturers_name");
    while ($products_manufacturers_values = $db_fetch_array($products_manufacturers)) {
      echo '<select name="manufacturers_id[]"><option name="none" value="' . $products_manufacturers_values["products_to_manufacturers_id"] . '_none"></option>';
      $db_data_seek($manufacturers, 0);
      while ($manufacturers_values = $db_fetch_array($manufacturers)) {
        echo '<option name="' . $manufacturers_values["manufacturers_name"] . '" value="' . $products_manufacturers_values["products_to_manufacturers_id"] . '_' . $manufacturers_values["manufacturers_id"] . '"';
        if ($products_manufacturers_values["manufacturers_id"] == $manufacturers_values["manufacturers_id"]) {
          echo ' SELECTED';
        }
        echo '>' . $manufacturers_values["manufacturers_name"] . ' (' . $manufacturers_values["category_top_name"] . ')</option>';
      }
      echo '</select>&nbsp;&nbsp;';
    } ?><select name="manufacturers_id[]"><option name="none" value="none"></option><?
    $db_data_seek($manufacturers, 0);
    while ($manufacturers_values = $db_fetch_array($manufacturers)) {
      echo '<option name="' . $manufacturers_values["manufacturers_name"] . '" value="' . $manufacturers_values["manufacturers_id"] . '">' . $manufacturers_values["manufacturers_name"] . ' (' . $manufacturers_values["category_top_name"] . ')</option>';
    }
    ?></select></font></td>
          </tr>
          <tr>
            <td ><font face="Verdana, Arial" size="1"><b>&nbsp;Subcategories:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?
    $products_subcategories = $db_query("select subcategories.subcategories_id, products_to_subcategories.products_to_subcategories_id from subcategories, products_to_subcategories where products_to_subcategories.products_id = '$products_values[products_id]' and products_to_subcategories.subcategories_id = subcategories.subcategories_id order by subcategories.subcategories_name");
    $subcategories = $db_query("select subcategories.subcategories_id, subcategories.subcategories_name, category_top.category_top_name from subcategories, subcategories_to_category, category_top where subcategories.subcategories_id = subcategories_to_category.subcategories_id and subcategories_to_category.category_top_id = category_top.category_top_id order by subcategories_name");
    while ($products_subcategories_values = $db_fetch_array($products_subcategories)) {
      echo '<select name="subcategories_id[]"><option name="none" value="' . $products_subcategories_values["products_to_subcategories_id"] . '_none"></option>';
      $db_data_seek($subcategories, 0);
      while ($subcategories_values = $db_fetch_array($subcategories)) {
        echo '<option name="' . $subcategories_values["subcategories_name"] . '" value="' . $products_subcategories_values["products_to_subcategories_id"] . '_' . $subcategories_values["subcategories_id"] . '"';
        if ($products_subcategories_values["subcategories_id"] == $subcategories_values["subcategories_id"]) {
          echo ' SELECTED';
        }
        echo '>' . $subcategories_values["subcategories_name"] . ' (' . $subcategories_values["category_top_name"] . ')</option>';
      }
      echo '</select>&nbsp;&nbsp;';
    } ?><select name="subcategories_id[]"><option name="none" value="none"></option><?
    $db_data_seek($subcategories, 0);
    while ($subcategories_values = $db_fetch_array($subcategories)) {
      echo '<option name="' . $subcategories_values["subcategories_name"] . '" value="' . $subcategories_values["subcategories_id"] . '">' . $subcategories_values["subcategories_name"] . ' (' . $subcategories_values["category_top_name"] . ')</option>';
    } ?></select></font></td>
          </tr>
          <tr>
            <td valign="top"><font face="Verdana, Arial" size="1"><b>&nbsp;Description:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<textarea name="products_description" wrap="soft" cols="60" rows="15"><?=$products_values["products_description"];?></textarea>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Price:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_price" value="<?=$products_values["products_price"];?>" size="10">&nbsp;<small>(eg, 45.95)</small>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Quantity:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_quantity" value="<?=$products_values["products_quantity"];?>" size="3">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Model:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_model" value="<?=$products_values["products_model"];?>" size="10">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Image:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_image" value="<?=$products_values["products_image"];?>" size="20">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Webpage:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_url" value="<?=$products_values["products_url"];?>" size="20">&nbsp;<small>(optional + without http://)</small>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="right" colspan="5"><font face="Verdama, Arial" size="2"><input type="image" src="images/button_update.gif" width="50" height="14" border="0" alt=" update ">&nbsp;&nbsp;<a href="products_modify.php"><img src="images/button_cancel.gif" width="50" height="14" border="0" alt=" cancel "></a>&nbsp;&nbsp;</font></td>
          </tr>
        </table></td>
      </tr><input type="hidden" name="products_id" value="<?=$HTTP_GET_VARS["products_id"];?>"></form>
<?
  }  else {
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
<?
    if ($HTTP_GET_VARS["order_by"]) {
      $order_by = $HTTP_GET_VARS["order_by"];
    } else {
      $order_by = "products_name";
    }
?>
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Products&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="products_name"<? if ($order_by == "products_name") { echo ' SELECTED'; } ?>>products_name</option><option value="products_id"<? if ($order_by == "products_id") { echo ' SELECTED'; } ?>>products_id</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;products_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;products_name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    $products = $db_query("select products_id, products_name from products order by $order_by");
    while ($products_values = $db_fetch_array($products)) {
      $products_subcategories = "";
      $subcategories = $db_query("select subcategories.subcategories_name from subcategories, products_to_subcategories where products_to_subcategories.products_id = $products_values[products_id] and products_to_subcategories.subcategories_id = subcategories.subcategories_id order by subcategories.subcategories_name");
      while ($subcategories_values = $db_fetch_array($subcategories)) {
        $products_subcategories.=$subcategories_values["subcategories_name"] . ' / ';
      }
      $products_subcategories = substr($products_subcategories, 0, -3); // remove the last ' / '
      $rows++;
      if (floor($rows/2) == ($rows/2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_subcategories;?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_name"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="products_modify.php?products_id=<?=$products_values["products_id"];?>"><img src="images/button_modify.gif" width="50" height="14" border="0" alt=" modify "></a>&nbsp;</font></td>
          </tr>
<?
      $ids[] = $products_values["products_id"];
      rsort($ids);
      $next_id = ($ids[0] + 1);
    }
?>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr>
<?
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>