<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if (($HTTP_GET_VARS["action"] == "add_products") && ($HTTP_POST_VARS["insert"] == "1")) {
      $date_now = date("Ymd");
      $db_query("insert into products values ('', '$HTTP_POST_VARS[products_name]', '$HTTP_POST_VARS[products_description]', $HTTP_POST_VARS[products_quantity], '$HTTP_POST_VARS[products_model]', '$HTTP_POST_VARS[products_image]', '$HTTP_POST_VARS[products_url]', $HTTP_POST_VARS[products_price], '$date_now', 0)");
      $products_id = $db_insert_id($db_link);
      $db_query("insert into products_to_subcategories values ('', $products_id, $HTTP_POST_VARS[subcategories_id])");
      $db_query("insert into products_to_manufacturers values ('', $products_id, $HTTP_POST_VARS[manufacturers_id])");
      header("Location: products.php");
    }
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function checkForm(form) {
  if (form == "2") {
    var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
    var error = 0;
    var products_description = document.products.products_description.value;
    var products_price = document.products.products_price.value;
    var products_quantity = document.products.products_quantity.value;
    var products_model = document.products.products_model.value;
    var products_image = document.products.products_image.value;

    if (products_description.length < 1) {
      error_message = error_message + "* The new product needs a description\n";
      error = 1;
    }

    if (products_price.length < 1) {
      error_message = error_message + "* The new product needs a price value\n";
      error = 1;
    }

    if (products_quantity.length < 1) {
      error_message = error_message + "* The new product needs a quantity value\n";
      error = 1;
    }

    if (products_model.length < 1) {
      error_message = error_message + "* The new product needs a model value\n";
      error = 1;
    }

    if (products_image.length < 1) {
      error_message = error_message + "* The new product needs an image value\n";
      error = 1;
    }

    if (error == 1) {
      alert(error_message);
      return false;
    } else {
      return true;
    }
  } else if (form == "1") {
    var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
    var error = 0;
    var products_name = document.products.products_name.value;

    if (products_name.length < 1) {
      error_message = error_message + "* The new product needs a name\n";
      error = 1;
    }

    if (error == 1) {
      alert(error_message);
      return false;
    } else {
      return true;
    }
  }
}

function new_win(image) {
  window.open(image,"image","height=80,width=120,toolbar=no,statusbar=no,scrollbars=no").focus();
}

function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/products.php?order_by="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Products&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  if (($HTTP_GET_VARS["action"] == "add_products") && (!$HTTP_POST_VARS["insert"])) {
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;"<?=$HTTP_POST_VARS["products_name"];?>"&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/pixel_trans.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="products" action="products.php?action=add_products" method="post" onSubmit="return checkForm('2');">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td valign="top"><font face="Verdana, Arial" size="1"><b>&nbsp;Manufacturer:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<select name="manufacturers_id"><?
    $manufacturers = $db_query("select manufacturers_id, manufacturers_name from manufacturers order by manufacturers_name");
    while ($manufacturers_values = $db_fetch_array($manufacturers)) {
      echo '<option name="' . $manufacturers_values["manufacturers_name"] . '" value="' . $manufacturers_values["manufacturers_id"] . '">' . $manufacturers_values["manufacturers_name"] . '</option>';
    } ?></select>&nbsp;<br>&nbsp;<small><font color="#FF0000">NOTE:</font> To add this product to multiple manufacturers, store it first<br>&nbsp;with 1 manufacturer, and modify it afterwards to add the others.</small></font></td>
          </tr>
          <tr>
            <td valign="top"><font face="Verdana, Arial" size="1"><b>&nbsp;Subcategory:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<select name="subcategories_id"><?
    $subcategories = $db_query("select subcategories_id, subcategories_name from subcategories order by subcategories_name");
    while ($subcategories_values = $db_fetch_array($subcategories)) {
      echo '<option name="' . $subcategories_values["subcategories_name"] . '" value="' . $subcategories_values["subcategories_id"] . '"';
      if ($HTTP_POST_VARS["subcategories_id"] == $subcategories_values["subcategories_id"]) {
        echo ' SELECTED';
      }
      echo '>' . $subcategories_values["subcategories_name"] . '</option>';
    } ?></select>&nbsp;<br>&nbsp;<small><font color="#FF0000">NOTE:</font> To add this product to multiple subcategories, store it first<br>&nbsp;with 1 subcategory, and modify it afterwards to add the others.</small></font></td>
          </tr>
          <tr>
            <td valign="top"><font face="Verdana, Arial" size="1"><b>&nbsp;Description:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<textarea name="products_description" wrap="soft" cols="60" rows="15"></textarea>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Price:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_price" value="" size="10">&nbsp;<small>(eg, 45.95)</small>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Quantity:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_quantity" value="" size="3">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Model:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_model" value="" size="10">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Image:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_image" value="" size="20">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;Webpage:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_url" value="" size="20">&nbsp;<small>(optional + without http://)</small>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="right" colspan="5"><font face="Verdama, Arial" size="2"><input type="image" src="images/button_insert.gif" width="50" height="14" border="0" alt=" insert ">&nbsp;&nbsp;<a href="products.php"><img src="images/button_cancel.gif" width="50" height="14" border="0" alt=" cancel "></a>&nbsp;&nbsp;</font></td>
          </tr>
        </table></td>
      </tr><input type="hidden" name="products_name" value="<?=$HTTP_POST_VARS["products_name"];?>"><input type="hidden" name="insert" value="1"></form>
<?
  } else {
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
<?
    if ($HTTP_GET_VARS["order_by"]) {
      $order_by = $HTTP_GET_VARS["order_by"];
    } else {
      $order_by = "products_name";
    }
?>
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Products&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="products_name"<? if ($order_by == "products_name") { echo ' SELECTED'; } ?>>products_name</option><option value="products_id"<? if ($order_by == "products_id") { echo ' SELECTED'; } ?>>products_id</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="products" action="products.php?action=add_products" method="post" onSubmit="return checkForm('1');">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;products_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;products_name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    $products = $db_query("select products_id, products_name, products_image from products order by $order_by");
    while ($products_values = $db_fetch_array($products)) {
      $products_subcategories = "";
      $subcategories = $db_query("select subcategories.subcategories_name from subcategories, products_to_subcategories where products_to_subcategories.products_id = $products_values[products_id] and products_to_subcategories.subcategories_id = subcategories.subcategories_id order by subcategories.subcategories_name");
      while ($subcategories_values = $db_fetch_array($subcategories)) {
        $products_subcategories.=$subcategories_values["subcategories_name"] . ' / ';
      }
      $products_subcategories = substr($products_subcategories, 0, -3); // remove the last ' / '
      $rows++;
      if (floor($rows/2) == ($rows/2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_subcategories;?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?
    if ((file_exists($document_root . $catalog_root . '/' . $products_values["products_image"])) && ($products_values["products_image"])) {
      echo '<img src="images/dot_green.gif" width="4" height="4" border="0" alt=" Image Exists ">';
    } else {
      echo '<img src="images/dot_red.gif" width="4" height="4" border="0" alt=" Image Non-Existant ">';
    } ?>&nbsp;<a href="javascript:new_win('<?=$catalog_root . '/' . $products_values["products_image"];?>')"><?=$products_values["products_name"];?></a>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="products_modify.php?products_id=<?=$products_values["products_id"];?>"><img src="images/button_modify.gif" width="50" height="14" border="0" alt=" modify "></a>&nbsp;<a href="products_remove.php?products_id=<?=$products_values["products_id"];?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;</font></td>
          </tr>
<?
      $ids[] = $products_values["products_id"];
      rsort($ids);
      $next_id = ($ids[0] + 1);
    }
?>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    if (floor($rows/2) == ($rows/2)) {
      echo '          <tr bgcolor="#f4f7fd">' . "\n";
    } else {
      echo '          <tr bgcolor="#ffffff">' . "\n";
    }
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<select name="subcategories_id"><?
    $subcategories = $db_query("select subcategories_id, subcategories_name from subcategories order by subcategories_name");
    while ($subcategories_values = $db_fetch_array($subcategories)) {
      echo '<option name="' . $subcategories_values["subcategories_name"] . '" value="' . $subcategories_values["subcategories_id"] . '">' . $subcategories_values["subcategories_name"] . '</option>';
    } ?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$next_id;?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="products_name" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;<input type="image" src="images/button_insert.gif" width="50" height="14" border="0" alt=" insert ">&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="right" colspan="4"><font face="Verdana, Arial" size="1"><img src="images/dot_green.gif" width="4" height="4" border="0" alt="Green Dot"> Image Exists&nbsp;&nbsp;&nbsp;<img src="images/dot_red.gif" width="4" height="4" border="0" alt="Red Dot"> Image Does Not Exist&nbsp;&nbsp;</font></td>
          </tr>
        </table></td>
      </tr></form>
<?
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>