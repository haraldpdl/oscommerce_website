<? include("includes/sysenv.php"); ?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/stats_customers.php?limit="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Statistics&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
<?
  if ($HTTP_GET_VARS["limit"]) {
    $limit = $HTTP_GET_VARS["limit"];
  } else {
    $limit = "10";
  }
?>
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Most Customer Totals&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="10"<? if ($limit == "10") { echo ' SELECTED'; } ?>>10</option><option value="20"<? if ($limit == "20") { echo ' SELECTED'; } ?>>20</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="products" action="products.php?action=add_products" method="post" onSubmit="return checkForm('1');">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;#&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="1"><b>&nbsp;total purchased&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $customers = $db_query("select customers.customers_firstname, customers.customers_lastname, sum(orders_products.products_quantity * orders_products.products_price) as ordersum from customers, orders_products, orders where customers.customers_id = orders.customers_id and orders.orders_id = orders_products.orders_id group by customers.customers_firstname, customers.customers_lastname order by ordersum DESC limit $limit");
  while ($customers_values = $db_fetch_array($customers)) {
    $rows++;
    if (floor($rows/2) == ($rows/2)) {
      echo '          <tr bgcolor="#ffffff">' . "\n";
    } else {
      echo '          <tr bgcolor="#f4f7fd">' . "\n";
    }
    if (strlen($rows) < 2) {
      $rows = '0' . $rows;
    }
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$rows;?>.&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_firstname"] . ' ' . $customers_values["customers_lastname"];?>&nbsp;</font></td>
            <td align="right"><font face="Verdana, Arial" size="1">&nbsp;$<?=$customers_values["ordersum"];?>&nbsp;</font></td>
          </tr>
<?
  }
?>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr></form>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>