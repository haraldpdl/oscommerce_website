<? include("includes/sysenv.php"); ?>
<?
  if (($HTTP_GET_VARS["action"] == "add_customers") && ($HTTP_POST_VARS["insert"])) {
    $date_now = date("Ymd");
    $dob_ordered = substr($HTTP_POST_VARS["dob"], -4) . substr($HTTP_POST_VARS["dob"], 3, 2) . substr($HTTP_POST_VARS["dob"], 0, 2);

    $db_query("insert into customers values ('', '$HTTP_POST_VARS[gender]', '$HTTP_POST_VARS[firstname]', '$HTTP_POST_VARS[lastname]', '$dob_ordered', '$HTTP_POST_VARS[email_address]', '$HTTP_POST_VARS[street_address]', '$HTTP_POST_VARS[suburb]', '$HTTP_POST_VARS[postcode]', '$HTTP_POST_VARS[city]', '$HTTP_POST_VARS[state]', '$HTTP_POST_VARS[country]', '$HTTP_POST_VARS[telephone]', '$HTTP_POST_VARS[fax]', '$HTTP_POST_VARS[password]')");
    $insert_id = $db_insert_id();
    $db_query("insert into customers_info values ($insert_id, '', '0', '$date_now', '')");
    header("Location: customers.php");
  }
?>

<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
<?
  if (($HTTP_GET_VARS["action"] == "add_customers") && (!$HTTP_POST_VARS["insert"])) {
?>
function check_form() {
  var error = 0;
  var error_message = "Errors have occured during the process of your form!\nPlease make the following corrections:\n\n";

  var firstname = document.customers.firstname.value;
  var lastname = document.customers.lastname.value;
  var dob = document.customers.dob.value;
  var email_address = document.customers.email_address.value;  
  var street_address = document.customers.street_address.value;
  var postcode = document.customers.postcode.value;
  var city = document.customers.city.value;
  var country = document.customers.country.value;
  var telephone = document.customers.telephone.value;
  var password = document.customers.password.value;
  var confirmation = document.customers.confirmation.value;

  if (document.customers.gender[0].checked || document.customers.gender[1].checked) {
  } else {
    error_message = error_message + "* Their 'Gender' must be selected.\n";
    error = 1;
  }
  
  if (firstname = "" || firstname.length < 3) {
    error_message = error_message + "* Their 'First Name' must be atleast 3 characters.\n";
    error = 1;
  }

  if (lastname = "" || lastname.length < 3) {
    error_message = error_message + "* Their 'Last Name' must be atleast 3 characters.\n";
    error = 1;
  }

  if (dob = "" || dob.length < 10) {
    error_message = error_message + "* Their 'Date of Birth' must be in this format: xx/xx/xxxx (date/month/year).\n";
    error = 1;
  }

  if (email_address = "" || email_address.length < 6) {
    error_message = error_message + "* Their 'E-Mail Address' must be atleast 6 characters.\n";
    error = 1;
  }

  if (street_address = "" || street_address.length < 5) {
    error_message = error_message + "* Their 'Street Address' must be atleast 5 characters.\n";
    error = 1;
  }

  if (postcode = "" || postcode.length < 4) {
    error_message = error_message + "* Their 'Post Code' must be atleast 4 characters.\n";
    error = 1;
  }

  if (city = "" || city.length < 4) {
    error_message = error_message + "* Their 'City' must be atleast 4 characters.\n";
    error = 1;
  }

  if (country = "" || country.length < 3) {
    error_message = error_message + "* Their 'Country' must be atleast 3 characters.\n";
    error = 1;
  }

  if (telephone = "" || telephone.length < 5) {
    error_message = error_message + "* Their 'Telephone No.' must be atleast 5 characters.\n";
    error = 1;
  }

  if ((password != confirmation) || (password = "" || password.length < 5)) {
    error_message = error_message + "* Their 'Password' amd 'Confirmation' must match amd be atleast 5 characters.\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
<?
  } else {
?>
function checkForm() {
  var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
  var error = 0;
  var customers_firstname = document.customers.customers_firstname.value;
  var customers_lastname = document.customers.customers_lastname.value;
  var customers_country = document.customers.customers_country.value;
  
  if (customers_firstname.length < 1) {
    error_message = error_message + "* The new customer needs to have a firstname\n";
    error = 1;
  }
  
  if (customers_lastname.length < 1) {
    error_message = error_message + "* The new customer needs to have a lastname\n";
    error = 1;
  }
  
  if (customers_country.length < 1) {
    error_message = error_message + "* The new customer needs to have a country set\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
<?
  }
?>

function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/customers.php?order_by="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Customers&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  if (($HTTP_GET_VARS["action"] == "add_customers") && (!$HTTP_POST_VARS["insert"])) {
?>
      <tr><form name="customers" method="post" action="customers.php?action=add_customers" onSubmit="return check_form();"><input type="hidden" name="insert" value="1">
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;New Customer&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_account.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="100%"><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Personal ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Gender:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="radio" name="gender" value="m">&nbsp;&nbsp;Male&nbsp;&nbsp;<input type="radio" name="gender" value="f">&nbsp;&nbsp;Female&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;First Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="firstname" maxlength="32" value="<?=$HTTP_POST_VARS["customers_firstname"];?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Last Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="lastname" maxlength="32" value="<?=$HTTP_POST_VARS["customers_lastname"];?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Date of Birth:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="dob" value="dd/mm/yyyy" maxlength="10">&nbsp;&nbsp;<small>(eg. 21/05/1970) <font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;E-Mail Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="email_address" maxlength="96">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Address ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Street Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="street_address" maxlength="64">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Suburb:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="suburb" maxlength="32">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Post Code:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="postcode" maxlength="8">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;City:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="city" maxlength="32">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;State:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="state" maxlength="32">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Country:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="country" maxlength="32" value="<?=$HTTP_POST_VARS["customers_country"];?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Contact ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Telephone No.:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="telephone" maxlength="32">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Fax No.:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="fax" maxlength="32">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Password ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Password:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="password" name="password" maxlength="12">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Confirmation:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="password" name="confirmation" maxlength="12">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><input type="image" src="images/button_insert.gif" width="50" height="14" border="0" alt=" insert ">&nbsp;&nbsp;<a href="customers.php"><img src="images/button_cancel.gif" width="50" height="14" border="0" alt=" cancel "></a>&nbsp;&nbsp;</font></td>
      </tr></form>
<?
  } else {
    if ($HTTP_GET_VARS["order_by"]) {
      $order_by = $HTTP_GET_VARS["order_by"];
    } else {
      $order_by = "customers_id";
    }
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Customers&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="customers_lastname"<? if ($order_by == "customers_lastname") { echo ' SELECTED'; } ?>>customers_lastname</option><option value="customers_id"<? if ($order_by == "customers_id") { echo ' SELECTED'; } ?>>customers_id</option><option value="customers_country"<? if ($order_by == "customers_country") { echo ' SELECTED'; } ?>>customers_country</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="customers" action="customers.php?action=add_customers" method="post" onSubmit="return checkForm();">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;customers_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers_firstname&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers_lastname&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;customers_country&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    $customers = $db_query("select customers_id, customers_firstname, customers_lastname, customers_city, customers_country from customers order by $order_by");
    while ($customers_values = $db_fetch_array($customers)) {
      $rows++;
      if (floor($rows/2) == ($rows/2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_firstname"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_lastname"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$customers_values["customers_country"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="customers_modify.php?customers_id=<?=$customers_values["customers_id"];?>"><img src="images/button_modify.gif" width="50" height="14" border="0" alt=" modify "></a>&nbsp;&nbsp;<a href="customers_remove.php?customers_id=<?=$customers_values["customers_id"];?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;</font></td>
          </tr>
<?
      $ids[] = $customers_values["customers_id"];
      rsort($ids);
      $next_id = ($ids[0] + 1);
    }
?>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    if (floor($rows/2) == ($rows/2)) {
      echo '          <tr bgcolor="#f4f7fd">' . "\n";
    } else {
      echo '          <tr bgcolor="#ffffff">' . "\n";
    }
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$next_id;?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="customers_firstname" size="20">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="customers_lastname" size="20">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="customers_country" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;<input type="image" src="images/button_insert.gif" width="50" height="14" border="0" alt=" insert ">&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr></form>
<?
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>