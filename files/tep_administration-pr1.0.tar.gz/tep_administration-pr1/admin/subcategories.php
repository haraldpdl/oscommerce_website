<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if ($HTTP_GET_VARS["action"] == "add_subcategory") {
      $db_query("insert into subcategories values ('', '$HTTP_POST_VARS[subcategories_name]', '$HTTP_POST_VARS[subcategories_image]')");
      $subcategories_id = $db_insert_id($db_link);
      $db_query("insert into subcategories_to_category values ('', $subcategories_id, $HTTP_POST_VARS[category_top_id])");
      header("Location: subcategories.php");
    }
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function checkForm() {
  var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
  var error = 0;
  var subcategories_name = document.subcategories.subcategories_name.value;
  var subcategories_image = document.subcategories.subcategories_image.value;
  
  if (subcategories_name.length < 1) {
    error_message = error_message + "* The new subcategory needs a name\n";
    error = 1;
  }
  
  if (subcategories_image.length < 1) {
    error_message = error_message + "* The new subcategory needs an image\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}

function new_win(image) {
  window.open(image,"image","height=80,width=120,toolbar=no,statusbar=no,scrollbars=no").focus();
}

function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/subcategories.php?order_by="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Subcategories&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
<?
  if ($HTTP_GET_VARS["order_by"]) {
    $order_by = $HTTP_GET_VARS["order_by"];
  } else {
    $order_by = "subcategories_name";
  }
?>
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Subcategories&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="subcategories_name"<? if ($order_by == "subcategories_name") { echo ' SELECTED'; } ?>>subcategories_name</option><option value="subcategories_id"<? if ($order_by == "subcategories_id") { echo ' SELECTED'; } ?>>subcategories_id</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="subcategories" action="subcategories.php?action=add_subcategory" method="post" onSubmit="return checkForm();">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_top&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories_name&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories_image&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $subcategories = $db_query("select subcategories_id, subcategories_name, subcategories_image from subcategories order by $order_by");
  while ($subcategories_values = $db_fetch_array($subcategories)) {
    $rows++;
    if (floor($rows/2) == ($rows/2)) {
      echo '          <tr bgcolor="#ffffff">' . "\n";
    } else {
      echo '          <tr bgcolor="#f4f7fd">' . "\n";
    }
    $subcategories_categories = '';
    $categories = $db_query("select category_top.category_top_name from subcategories_to_category, category_top where subcategories_to_category.subcategories_id = $subcategories_values[subcategories_id] and subcategories_to_category.category_top_id = category_top.category_top_id");
    while ($categories_values = $db_fetch_array($categories)) {
      $subcategories_categories.=$categories_values["category_top_name"] . ' / ';
    }
    $subcategories_categories = substr($subcategories_categories, 0, -3); // remove trailing ' / '
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$subcategories_categories;?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$subcategories_values["subcategories_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$subcategories_values["subcategories_name"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?
    if ((file_exists($document_root . $catalog_root . '/' . $subcategories_values["subcategories_image"])) && ($subcategories_values["subcategories_image"])) {
      echo '<img src="images/dot_green.gif" width="4" height="4" border="0" alt=" Image Exists ">';
    } else {
      echo '<img src="images/dot_red.gif" width="4" height="4" border="0" alt=" Image Non-Existant ">';
    } ?>&nbsp;<a href="javascript:new_win('<?=$catalog_root . '/' . $subcategories_values["subcategories_image"];?>')"><?=$subcategories_values["subcategories_image"];?></a>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="subcategories_modify.php?subcategories_id=<?=$subcategories_values["subcategories_id"];?>&order_by=<?=$order_by;?>"><img src="images/button_modify.gif" width="50" height="14" border="0" alt=" modify "></a>&nbsp;&nbsp;<a href="subcategories_remove.php?subcategories_id=<?=$subcategories_values["subcategories_id"];?>&order_by=<?=$order_by;?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;</font></td>
          </tr>
<?
    $ids[] = $subcategories_values["subcategories_id"];
    rsort($ids);
    $next_id = ($ids[0] + 1);
  }
?>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if (floor($rows/2) == ($rows/2)) {
    echo '          <tr bgcolor="#f4f7fd">' . "\n";
  } else {
    echo '          <tr bgcolor="#ffffff">' . "\n";
  }
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<select name="category_top_id"><?
  $categories = $db_query("select category_top_id, category_top_name from category_top order by category_top_id");
  while ($categories_values = $db_fetch_array($categories)) {
    echo '<option name="' . $categories_values["category_top_name"] . '" value="' . $categories_values["category_top_id"] . '">' . $categories_values["category_top_name"] . '</option>';
  } ?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$next_id;?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="subcategories_name" size="20">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="subcategories_image" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;<input type="image" src="images/button_insert.gif" width="50" height="14" border="0" alt=" insert ">&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="right" colspan="5"><font face="Verdana, Arial" size="1"><img src="images/dot_green.gif" width="4" height="4" border="0" alt="Green Dot"> Image Exists&nbsp;&nbsp;&nbsp;<img src="images/dot_red.gif" width="4" height="4" border="0" alt="Red Dot"> Image Does Not Exist&nbsp;&nbsp;</font></td>
          </tr>
        </table></td>
      </tr></form>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>