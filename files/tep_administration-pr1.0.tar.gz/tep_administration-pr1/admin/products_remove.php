<? include("includes/sysenv.php"); ?>
<?
  if (($HTTP_GET_VARS["products_id"]) && ($HTTP_GET_VARS["action"] == "delete_product")) {
    $products = $db_query("select products_image from products where products_id = $HTTP_GET_VARS[products_id]");
    $products_values = $db_fetch_array($products);
    $products_image = $products_values["products_image"];
    $db_query("delete from products where products_id = $HTTP_GET_VARS[products_id]");
    $db_query("delete from products_to_subcategories where products_id = $HTTP_GET_VARS[products_id]");
    $db_query("delete from products_to_manufacturers where products_id = $HTTP_GET_VARS[products_id]");
    $db_query("delete from customers_basket where products_id = $HTTP_GET_VARS[products_id]");
    $reviews = $db_query("select reviews_id from reviews_extra where products_id = $HTTP_GET_VARS[products_id]");
    while (@$reviews_delete = $db_fetch_array($reviews)) { // delete all products reviews
      $db_query("delete from reviews where reviews_id = $reviews_delete[reviews_id]");
    }
    $db_query("delete from reviews_extra where products_id = $HTTP_GET_VARS[products_id]");
    if (file_exists($document_root . $catalog_root . '/' . $products_image)) { // delete products image
      @unlink($document_root . $catalog_root . '/' . $products_image);
    }
    header("Location: products.php");
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function go() {
  if (document.order_by.selected.options[document.order_by.selected.selectedIndex].value != "none") {
    location = "<?=$admin_root;?>/products_remove.php?order_by="+document.order_by.selected.options[document.order_by.selected.selectedIndex].value;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Products&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  if ($HTTP_GET_VARS["products_id"]) {
    $products = $db_query("select products_id, products_name, products_description, products_quantity, products_model, products_image, products_url, products_price, products_date_added from products where products_id = '$HTTP_GET_VARS[products_id]'");
    $products_values = $db_fetch_array($products);
    $manufacturers = $db_query("select manufacturers.manufacturers_name, manufacturers.manufacturers_location, manufacturers.manufacturers_image from manufacturers, products_to_manufacturers where products_to_manufacturers.products_id = $HTTP_GET_VARS[products_id] and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id");
    $products_manufacturers = "";
    $products_manufacturers_images = "";
    if ($db_num_rows($manufacturers) > 1) {
      while ($manufacturers_values = $db_fetch_array($manufacturers)) {
        $products_manufacturers.=$manufacturers_values["manufacturers_name"] . ' / ';
        $products_manufacturers_images.='<img src="' . $catalog_root . '/' . $manufacturers_values["manufacturers_image"] . '" width="85" height="60" border="0" alt="">&nbsp;';
        if ($manufacturers_values["manufacturers_location"] == "1") {
          $manufacturers_location = "1";
        } else {
          if ($manufacturers_location == "1") {
            $manufacturers_location = "1";
          } else {
            $manufacturers_location = "0";
          }
        }
      }
      $products_manufacturers = substr($products_manufacturers, 0, -3);
    } else {
      $manufacturers_values = $db_fetch_array($manufacturers);
      $products_manufacturers = $manufacturers_values["manufacturers_name"];
      $products_manufacturers_images = '<img src="' . $catalog_root . '/' . $manufacturers_values["manufacturers_image"] . '" width="85" height="60" border="0" alt="">&nbsp;';
      $manufacturers_location = $manufacturers_values["manufacturers_location"];
    }
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
<?
    if ($manufacturers_location == "0") {
      echo '            <td><font face="Verdana, Arial" size="4">&nbsp;' . $products_manufacturers . ' ' . $products_values["products_name"] . ' @ $' . $products_values["products_price"] . '&nbsp;</font></td>' . "\n";
    } else {
      echo '            <td><font face="Verdana, Arial" size="4">&nbsp;' . $products_values["products_name"] . ' (' . $products_manufacturers . ') @ $' . $products_values["products_price"] . '&nbsp;</font></td>' . "\n";
    }
?>
            <td align="right">&nbsp;<?=$products_manufacturers_images;?></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
      <tr>
<?
    echo '        <td><font face="Verdana, Arial" size="2"><img src="' . $catalog_root . '/' . $products_values["products_image"] . '" border="0" alt="';
    if ($manufacturers_location == "0") {
      echo $products_manufacturers . ' ' . $products_values["products_name"];
    } else {
      echo $products_values["products_name"] . ' (' . $products_manufacturers . ')';
    }
    echo '" align="right" width="100" hieght="80" hspace="5" vspace="5">' . $products_values["products_description"] . '</font></td>' . "\n";
?>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
<?
    $reviews = $db_query("select count(*) as count from reviews_extra where products_id = $HTTP_GET_VARS[products_id]");
    $reviews_values = $db_fetch_array($reviews);
?>
      <tr>
        <td><font face="Verdana, Arial" size="2">Current Reviews: <? echo $reviews_values["count"]; ?><br>&nbsp;</font></td>
      </tr>
<?
    if ($products_values["products_url"]) {
?>
      <tr>
        <td><font face="Verdana, Arial" size="2">For more information, please visit this products <a href="http://<? echo $products_values["products_url"]; ?>" target="_blank"><u>internet address</u></a>.<br>&nbsp;</font></td>
      </tr>
<?
    }

    $raw_date_added = $products_values["products_date_added"];
    $date_added = date("l, jS F, Y", mktime(0,0,0,substr($raw_date_added, 4, 2),substr($raw_date_added, -2),substr($raw_date_added, 0, 4)));
?>
      <tr>
        <td align="center"><font face="Verdana, Arial" size="2"><small>This product was added to our catalog on <? echo $date_added; ?>.</small></font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
      <tr>
        <td width="100%"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="1">&nbsp;<a href="products_remove.php?products_id=<?=$HTTP_GET_VARS["products_id"];?>&action=delete_product"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;&nbsp;<a href="products_remove.php"><img src="images/button_cancel.gif" width="50" height="14" border="0" alt=" cancel "></a>&nbsp;</font></td>
      </tr>
<?
  }  else {
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
<?
    if ($HTTP_GET_VARS["order_by"]) {
      $order_by = $HTTP_GET_VARS["order_by"];
    } else {
      $order_by = "products_name";
    }
?>
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Products&nbsp;</font></td>
            <td align="right"><br><form name="order_by"><select name="selected" onChange="go()"><option value="products_name"<? if ($order_by == "products_name") { echo ' SELECTED'; } ?>>products_name</option><option value="products_id"<? if ($order_by == "products_id") { echo ' SELECTED'; } ?>>products_id</option></select>&nbsp;&nbsp;</form></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;products_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;products_name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    $products = $db_query("select products_id, products_name from products order by $order_by");
    while ($products_values = $db_fetch_array($products)) {
      $products_subcategories = "";
      $subcategories = $db_query("select subcategories.subcategories_name from subcategories, products_to_subcategories where products_to_subcategories.products_id = $products_values[products_id] and products_to_subcategories.subcategories_id = subcategories.subcategories_id order by subcategories.subcategories_name");
      while ($subcategories_values = $db_fetch_array($subcategories)) {
        $products_subcategories.=$subcategories_values["subcategories_name"] . ' / ';
      }
      $products_subcategories = substr($products_subcategories, 0, -3); // remove the last ' / '
      $rows++;
      if (floor($rows/2) == ($rows/2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_subcategories;?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_name"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="products_remove.php?products_id=<?=$products_values["products_id"];?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;</font></td>
          </tr>
<?
    }
?>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr>
<?
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>