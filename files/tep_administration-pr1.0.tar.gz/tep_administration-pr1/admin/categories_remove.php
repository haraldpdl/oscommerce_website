<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if ($HTTP_GET_VARS["action"] == "remove_all") {
      $category_subcategories = $db_query("select subcategories_id from subcategories_to_category where category_top_id = $HTTP_GET_VARS[category_id]");
      while ($category_subcategories_values = $db_fetch_array($category_subcategories)) {
        $products = $db_query("select products_id from products_to_subcategories where subcategories_id = $category_subcategories_values[subcategories_id]");
        while ($products_delete = $db_fetch_array($products)) {
          $subcategories = $db_query("select count(*) as count from products_to_subcategories where products_id = $products_delete[products_id]");
          $subcategories_values = $db_fetch_array($subcategories);
          if ($subcategories_values["count"] > 1) { // product has more than one subcategory - only delete selected subcategory link
            $db_query("delete from products_to_subcategories where products_id = $products_delete[products_id] and subcategories_id = $category_subcategories_values[subcategories_id]");
          } else { // product has only one subcategory.. delete all related data with this products_id
            $products_image = $db_query("select products_image from products where products_id = $products_delete[products_id]");
            $products_image_values = $db_fetch_array($products_image);
            $products_image = $products_image_values["products_image"];
            $db_query("delete from products where products_id = $products_delete[products_id]"); // delete the product
            $db_query("delete from customers_basket where products_id = $products_delete[products_id]"); // delete the product from customers basket
            $reviews = $db_query("select reviews_id from reviews_extra where products_id = $products_delete[products_id]");
            while (@$reviews_delete = $db_fetch_array($reviews)) { // delete all products reviews
              $db_query("delete from reviews where reviews_id = $reviews_delete[reviews_id]");
            }
            $db_query("delete from reviews_extra where products_id = $products_delete[products_id]");
            $db_query("delete from specials where products_id = $products_delete[products_id]"); // delete products specials
            $db_query("delete from products_to_subcategories where products_id = $products_delete[products_id]"); // delete links
            $db_query("delete from products_to_subcategories where products_id = $products_delete[products_id]"); // delete links
            if (file_exists($document_root . $catalog_root . '/' . $products_image)) { // delete products image
              @unlink($document_root . $catalog_root . '/' . $products_image);
            }
          }
          $subcategories = $db_query("select subcategories_image from subcategories where subcategories_id = $category_subcategories_values[subcategories_id]");
          $subcategories_values = $db_fetch_array($subcategories);
          $subcategories_image = $subcategories_values["subcategories_image"];
          $db_query("delete from subcategories where subcategories_id = $categories_subcategories_values[subcategories_id]"); // delete subcategory
          if (file_exists($document_root . $catalog_root . '/' . $subcategories_image)) { // delete subcategories image
            @unlink($document_root . $catalog_root . '/' . $subcategories_image);
          }
        }
      }
      $db_query("delete from category_top where category_top_id = $HTTP_GET_VARS[category_id]");
      $indexes = $db_query("select category_index_id from category_index_to_top where category_top_id = $HTTP_GET_VARS[category_id]");
      while ($indexes_values = $db_fetch_array($indexes)) {
        $db_query("delete from category_index where category_index_id = $indexes_values[category_index_id]");
      }
      $db_query("delete from category_index_to_top where category_top_id = $HTTP_GET_VARS[products_id]");
      header("Location: categories.php");
    }
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function remove_all() {
  if (confirm("*** WARNING ***\n\nDo you really want to remove this subcategory AND all products linked to it?")) {
    document.location = "<?=$admin_root;?>/categories_remove.php?action=remove_all&category_id=<?=$HTTP_GET_VARS["category_id"];?>";
  } else {
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Categories&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  if ($HTTP_GET_VARS["category_id"]) {
    $category_top = $db_query("select category_top.category_top_name, category_top.category_image from category_top where category_top_id = $HTTP_GET_VARS[category_id]");
    $category_top_values = $db_fetch_array($category_top);
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;<?=$category_top_values["category_top_name"];?>&nbsp;</font></td>
            <td align="right">&nbsp;<img src="<?=$catalog_root . '/' . $category_top_values["category_image"];?>" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
    $products = $db_query("select distinct products.products_id, products.products_name, products.products_image from products, products_to_subcategories, subcategories_to_category where subcategories_to_category.category_top_id = $HTTP_GET_VARS[category_id] and subcategories_to_category.subcategories_id = products_to_subcategories.subcategories_id and products_to_subcategories.products_id = products.products_id order by products_name");
    if ($db_num_rows($products)) {
?>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;products_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;products_name&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;subcategories&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
      while ($products_values = $db_fetch_array($products)) {
        $products_subcategories = "";
        $subcategories = $db_query("select subcategories.subcategories_name from subcategories, products_to_subcategories where products_to_subcategories.products_id = $products_values[products_id] and products_to_subcategories.subcategories_id = subcategories.subcategories_id order by subcategories.subcategories_name");
        while ($subcategories_values = $db_fetch_array($subcategories)) {
          $products_subcategories.=$subcategories_values["subcategories_name"] . ' / ';
        }
        $products_subcategories = substr($products_subcategories, 0, -3); // remove the last ' / '
        $rows++;
        if (floor($rows/2) == ($rows/2)) {
          echo '          <tr bgcolor="#ffffff">' . "\n";
        } else {
          echo '          <tr bgcolor="#f4f7fd">' . "\n";
        }
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_values["products_name"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$products_subcategories;?>&nbsp;</font></td>
          </tr>
<?
      }
?>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td colspan="3"><br><font face="Verdana, Arial" size="2">Before removing this category, it is recommened to delete the above products or change their current category. If you continue to remove this category with products still linked to it, it could cause the database model to break.</font></td>
          </tr>
          <tr>
            <td align="right" colspan="3"><br><font face="Verdana, Arial" size="2"><a href="javascript:remove_all();"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;&nbsp;<a href="categories_remove.php"><img src="images/button_cancel.gif" width="50" height="14" border="0" alt=" cancel "></a>&nbsp;&nbsp;</font></td>
          </tr>
<?
    } else {
?>
          <tr>
            <td colspan="3"><br><font face="Verdana, Arial" size="2">This category has no products linked to it - it is safe to delete it.</font></td>
          </tr>
          <tr>
            <td align="right" colspan="3"><br><font face="Verdana, Arial" size="2"><a href="categories_remove.php?action=remove_all&category_id=<?=$HTTP_GET_VARS["category_id"];?>">delete</a>&nbsp;&nbsp;&nbsp;<a href="categories_remove.php">cancel</a>&nbsp;&nbsp;</font></td>
          </tr>
<?
    }
?>
        </table></td>
      </tr>
<?
  } else {
?>
      <tr><form name="category_top" action="categories_modify.php?action=update_category" method="post" onSubmit="return checkForm();">
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Categories&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/pixel_trans.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;category_top_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_top_name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;sort_order&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_image&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    $categories = $db_query("select category_top_id, category_top_name, sort_order, category_image from category_top order by category_top_id");
    $rows = 0;
    while ($categories_values = $db_fetch_array($categories)) {
      $rows++;
      if (floor($rows/2) == ($rows/2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_top_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_top_name"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["sort_order"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_image"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="categories_remove.php?category_id=<?=$categories_values["category_top_id"];?>"><img src="images/button_delete.gif" width="50" height="14" border="0" alt=" delete "></a>&nbsp;</font></td>
          </tr>
<?
    }
?>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  }
?>
        </table></td>
      </tr></form>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>