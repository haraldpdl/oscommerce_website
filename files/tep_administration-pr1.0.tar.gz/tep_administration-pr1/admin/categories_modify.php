<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if ($HTTP_GET_VARS["action"] == "update_category") {
      $db_query("update category_top set category_top_name = '$HTTP_POST_VARS[category_top_name]', sort_order = '$HTTP_POST_VARS[sort_order]', category_image = '$HTTP_POST_VARS[category_image]' where category_top_id = $HTTP_POST_VARS[category_id]");
      header("Location: categories_modify.php");
    }
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function checkForm() {
  var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
  var error = 0;
  var category_top_name = document.category_top.category_top_name.value;
  var sort_order = document.category_top.sort_order.value;
  var category_image = document.category_top.category_image.value;
  
  if (category_top_name.length < 1) {
    error_message = error_message + "* The category needs a name\n";
    error = 1;
  }
  
  if (sort_order = "" || sort_order.length < 1) {
    error_message = error_message + "* A numeric sort order is needed for the category\n";
    error = 1;
  }
  
  if (category_image.length < 1) {
    error_message = error_message + "* An image is required for the category\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Categories&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="category_top" action="categories_modify.php?action=update_category" method="post" onSubmit="return checkForm();">
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Categories&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/pixel_trans.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;category_top_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_top_name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;sort_order&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_image&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $categories = $db_query("select category_top_id, category_top_name, sort_order, category_image from category_top order by category_top_id");
  $rows = 0;
  while ($categories_values = $db_fetch_array($categories)) {
    $rows++;
    if (floor($rows/2) == ($rows/2)) {
      echo '          <tr bgcolor="#ffffff">' . "\n";
    } else {
      echo '          <tr bgcolor="#f4f7fd">' . "\n";
    }
    if ($HTTP_GET_VARS["category_id"] == $categories_values["category_top_id"]) {
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_top_id"];?><input type="hidden" name="category_id" value="<?=$categories_values["category_top_id"];?>">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="category_top_name" value="<?=$categories_values["category_top_name"];?>" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="sort_order" value="<?=$categories_values["sort_order"];?>" size="2">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="category_image" value="<?=$categories_values["category_image"];?>" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<input type="image" src="images/button_update_red.gif" width="50" height="14" border="0" alt=" update ">&nbsp;</font></td>
          </tr>
<?
    } else {
?>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_top_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_top_name"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["sort_order"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$categories_values["category_image"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="categories_modify.php?category_id=<?=$categories_values["category_top_id"];?>"><img src="images/button_modify.gif" width="50" height="14" border="0" alt=" modify "></a>&nbsp;</font></td>
          </tr>
<?
    }
  }
?>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr></form>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>