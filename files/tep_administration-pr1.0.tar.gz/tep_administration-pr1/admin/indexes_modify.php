<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if ($HTTP_GET_VARS["action"] == "update_index") {
      $db_query("update category_index set category_index_name = '$HTTP_POST_VARS[category_index_name]', sql_select = '$HTTP_POST_VARS[sql_select]' where category_index_id = $HTTP_POST_VARS[category_index_id]");
      $db_query("update category_index_to_top set category_top_id = $HTTP_POST_VARS[category_top_id], sort_order = $HTTP_POST_VARS[sort_order] where category_index_to_top_id = $HTTP_POST_VARS[category_index_to_top_id]");
      header("Location: indexes_modify.php");
    }
  }
?>
<html>
<head>
<title>The Exchange Project: Administrator</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function checkForm() {
  var error_message = "Errors have occured during the process of this form.\nPlease make the following corrections:\n\n";
  var error = 0;
  var category_index_name = document.category_index.category_index_name.value;
  var sql_select = document.category_index.sql_select.value;
  var sort_order = document.category_index.sort_order.value;
  
  if (category_index_name.length < 1) {
    error_message = error_message + "* The new index needs a name\n";
    error = 1;
  }
  
  if (sort_order.length < 1) {
    error_message = error_message + "* The new index needs a sort order number\n";
    error = 1;
  }

  if (sql_select.length < 1) {
    error_message = error_message + "* sql_select needs a value\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  include("includes/boxes/left_navigation.php");
?>
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Indexes&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Indexes&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/pixel_trans.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr><form name="category_index" action="indexes_modify.php?action=update_index" method="post" onSubmit="return checkForm();">
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td colspan="6"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_top&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;category_index_id&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;category_index_name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;sort_order&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="1"><b>&nbsp;sql_select&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="1"><b>&nbsp;action&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="6"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $indexes = $db_query("select category_top.category_top_name, category_index.category_index_id, category_index.category_index_name, category_index.sql_select, category_index_to_top.sort_order, category_index_to_top.category_index_to_top_id from category_index, category_index_to_top, category_top where category_index.category_index_id = category_index_to_top.category_index_id and category_index_to_top.category_top_id = category_top.category_top_id order by category_top.category_top_id, category_index_to_top.sort_order");
  $rows = 0;
  while ($indexes_values = $db_fetch_array($indexes)) {
    $rows++;
    if (floor($rows/2) == ($rows/2)) {
      echo '          <tr bgcolor="#ffffff">' . "\n";
    } else {
      echo '          <tr bgcolor="#f4f7fd">' . "\n";
    }
    if ($HTTP_GET_VARS["index_id"] == $indexes_values["category_index_id"]) {
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<select name="category_top_id"><?
      $categories = $db_query("select category_top_id, category_top_name from category_top order by category_top_id");
      while($categories_values = $db_fetch_array($categories)) {
        if ($indexes_values["category_top_name"] == $categories_values["category_top_name"]) {
          echo '<option name="' . $categories_values["category_top_name"] . '" value="' . $categories_values["category_top_id"] . '" SELECTED>' . $categories_values["category_top_name"] . '</option>';
        } else {
          echo '<option name="' . $categories_values["category_top_name"] . '" value="' . $categories_values["category_top_id"] . '">' . $categories_values["category_top_name"] . '</option>';
        }
      } ?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$indexes_values["category_index_id"];?><input type="hidden" name="category_index_id" value="<?=$indexes_values["category_index_id"];?>"><input type="hidden" name="category_index_to_top_id" value="<?=$indexes_values["category_index_to_top_id"];?>">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="category_index_name" value="<?=$indexes_values["category_index_name"];?>" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="sort_order" value="<?=$indexes_values["sort_order"];?>" size="2">&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<input type="text" name="sql_select" value="<?=$indexes_values["sql_select"];?>" size="20">&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<input type="image" src="images/button_update_red.gif" width="50" height="14" border="0" alt=" update ">&nbsp;</font></td>
          </tr>
<?
    } else {
?>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$indexes_values["category_top_name"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$indexes_values["category_index_id"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$indexes_values["category_index_name"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<?=$indexes_values["sort_order"];?>&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="1">&nbsp;<?=$indexes_values["sql_select"];?>&nbsp;</font></td>
            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<a href="indexes_modify.php?index_id=<?=$indexes_values["category_index_id"];?>"><img src="images/button_modify.gif" width="50" height="14" border="0" alt=" modify "></a>&nbsp;</font></td>
          </tr>
<?      
    }
  }
?>
          <tr>
            <td colspan="6"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
        </table></td>
      </tr></form>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>