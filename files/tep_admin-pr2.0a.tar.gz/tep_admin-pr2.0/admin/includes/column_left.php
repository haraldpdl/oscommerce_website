<?
  include('includes/boxes/configuration.php');
  include('includes/boxes/catalog.php');
  include('includes/boxes/customers.php');
  include('includes/boxes/taxes.php');
  include('includes/boxes/statistics.php');
?>
