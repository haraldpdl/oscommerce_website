<?
/*
Spanish Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('TOP_BAR_TITLE', 'Tipos de Impuesto');
define('HEADING_TITLE', 'Tipos de Impuesto');

define('TABLE_HEADING_TAX_CLASSES', 'Tipos de Impuesto');
define('TABLE_HEADING_ACTION', 'Accion');

define('TEXT_INFO_DATE_ADDED', 'Creado:');
define('TEXT_INFO_LAST_MODIFIED', 'Modificado:');
define('TEXT_INFO_EDIT_INTRO', 'Haga los cambios necesarios');
define('TEXT_INFO_CLASS_TITLE', 'Nombre del Impuesto:');
define('TEXT_INFO_CLASS_DESCRIPTION', 'Descripcion:');
define('TEXT_INFO_INSERT_INTRO', 'Introduzca los datos del nuevo tipo de impuesto');
define('TEXT_INFO_DELETE_INTRO', 'Seguro que desea eliminar este tipo de impuesto?');
define('TEXT_INFO_HEADING_NEW_TAX_CLASS', 'Nuevo Tipo de Impuesto');
?>
