<?
/*
Spanish Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('TOP_BAR_TITLE', 'Clientes');
define('HEADING_TITLE', 'Clientes');
define('HEADING_TITLE_SEARCH', 'Busqueda por palabra clave (Nombre / Apellido):');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_FIRSTNAME', 'Nombre');
define('TABLE_HEADING_LASTNAME', 'Apellido');
define('TABLE_HEADING_ACCOUNT_CREATED', 'Cuenta Creada');
define('TABLE_HEADING_ACTION', 'Accion');

define('TEXT_DATE_ACCOUNT_CREATED', 'Cuenta Creada:');
define('TEXT_DATE_ACCOUNT_LAST_MODIFIED', 'Ultima Modificacion:');
define('TEXT_INFO_DATE_LAST_LOGON', 'Ultima Visita:');
define('TEXT_INFO_NUMBER_OF_LOGONS', 'Numero de visitas:');
define('TEXT_INFO_COUNTRY', 'Pais:');
define('TEXT_INFO_NUMBER_OF_REVIEWS', 'Numero de Comentarios:');
?>
