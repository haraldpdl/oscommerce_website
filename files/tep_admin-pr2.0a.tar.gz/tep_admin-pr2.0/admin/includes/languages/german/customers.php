<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('TOP_BAR_TITLE', 'Kunden');
define('HEADING_TITLE', 'Kunden');
define('HEADING_TITLE_SEARCH', 'Schl&uuml;sselwortsuche (Vorname / Nachname):');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_FIRSTNAME', 'Vorname');
define('TABLE_HEADING_LASTNAME', 'Nachname');
define('TABLE_HEADING_ACCOUNT_CREATED', 'Account erstellt am');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_DATE_ACCOUNT_CREATED', 'Account erstellt am:');
define('TEXT_DATE_ACCOUNT_LAST_MODIFIED', 'Letzte &Auml;nderung:');
define('TEXT_INFO_DATE_LAST_LOGON', 'Letzte Anmeldung:');
define('TEXT_INFO_NUMBER_OF_LOGONS', 'Anzahl der Anmeldungen:');
define('TEXT_INFO_COUNTRY', 'Land:');
define('TEXT_INFO_NUMBER_OF_REVIEWS', 'Anzahl der Berichte:');
?>
