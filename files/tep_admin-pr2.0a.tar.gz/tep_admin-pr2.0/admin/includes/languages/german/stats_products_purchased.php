<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('TOP_BAR_TITLE', 'Statistiken');
define('HEADING_TITLE', 'meistgekaufte Artikel');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_PURCHASED', 'Anzahl gekauft');
?>