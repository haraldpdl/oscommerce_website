<?
/*
German Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('TOP_BAR_TITLE', 'Steuerklassen');
define('HEADING_TITLE', 'Steuerklassen');

define('TABLE_HEADING_TAX_CLASSES', 'Steuerklassen');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_DATE_ADDED', 'hinzugef&uuml;gt am:');
define('TEXT_INFO_LAST_MODIFIED', 'Letzte &Auml;nderung:');
define('TEXT_INFO_EDIT_INTRO', 'Bitte f&uuml;hren Sie die notwendigen &Auml;nderungen durch');
define('TEXT_INFO_CLASS_TITLE', 'Name der Steuerklasse:');
define('TEXT_INFO_CLASS_DESCRIPTION', 'Beschreibung:');
define('TEXT_INFO_INSERT_INTRO', 'Bitte geben Sie die neue Steuerklasse mit den dazugeh&ouml;rigen Angaben ein.');
define('TEXT_INFO_DELETE_INTRO', 'Sind Sie sicher, dass sie diese Steuerklasse l&ouml;schen m&ouml;chten?');
define('TEXT_INFO_HEADING_NEW_TAX_CLASS', 'Neue Steuerklasse');
?>