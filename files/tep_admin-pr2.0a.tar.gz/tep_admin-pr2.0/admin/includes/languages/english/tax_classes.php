<?
/*
English Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 02/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('TOP_BAR_TITLE', 'Tax Classes');
define('HEADING_TITLE', 'Tax Classes');

define('TABLE_HEADING_TAX_CLASSES', 'Tax Classes');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_DATE_ADDED', 'Date Added:');
define('TEXT_INFO_LAST_MODIFIED', 'Last Modified:');
define('TEXT_INFO_EDIT_INTRO', 'Please make any necessary changes');
define('TEXT_INFO_CLASS_TITLE', 'Tax Class Title:');
define('TEXT_INFO_CLASS_DESCRIPTION', 'Description:');
define('TEXT_INFO_INSERT_INTRO', 'Please enter the new tax class with its related data');
define('TEXT_INFO_DELETE_INTRO', 'Are you sure you want to delete this tax class?');
define('TEXT_INFO_HEADING_NEW_TAX_CLASS', 'New Tax Class');
?>