<? echo phpinfo(); ?>
