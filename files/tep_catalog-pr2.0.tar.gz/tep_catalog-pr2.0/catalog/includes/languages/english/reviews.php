<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Reviews');
define('TOP_BAR_TITLE', 'New Product Reviews');
define('HEADING_TITLE', 'Read What Others Are Saying');
define('TEXT_OF_5_STARS', '%s of 5 Stars!');

define('IMAGE_MAIN_MENU', 'Main Menu');
?>