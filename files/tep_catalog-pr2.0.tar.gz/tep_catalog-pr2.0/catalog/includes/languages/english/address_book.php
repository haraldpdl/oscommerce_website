<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Address Book');
define('TOP_BAR_TITLE', 'Address Book Entries');
define('HEADING_TITLE', 'My Personal Address Book');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_CITY_COUNTRY', 'City / Country');
define('TEXT_NO_ENTRIES_IN_ADDRESS_BOOK', 'You have no entries in your address book!');
define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTE:</b></font> A maximum of ' . MAX_ADDRESS_BOOK_ENTRIES . ' address book entries allowed.');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>NOTE:</b></font> Maximum of ' . MAX_ADDRESS_BOOK_ENTRIES . ' address book entries reached.');

define('IMAGE_ADD_ENTRY', 'Add Entry');
define('IMAGE_BACK', 'Back');
?>