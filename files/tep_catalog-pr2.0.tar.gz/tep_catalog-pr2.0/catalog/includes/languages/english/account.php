<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'My Account');
define('TOP_BAR_TITLE', 'My Account');
define('HEADING_TITLE', 'My Account Information');

define('IMAGE_EDIT_ACCOUNT', 'Edit Account');
define('IMAGE_ADDRESS_BOOK', 'Address Book');
define('IMAGE_HISTORY', 'History');
?>