<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Reviews');
define('TOP_BAR_TITLE', 'Product Reviews');
define('HEADING_TITLE', ' %s Reviews');
define('SUB_TITLE_PRODUCT', 'Product:');
define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_DATE', 'Date:');
define('SUB_TITLE_REVIEW', 'Review:');
define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_OF_5_STARS', '%s of 5 Stars!');

define('IMAGE_WRITE_A_REVIEW', 'Write a Review');
define('IMAGE_BACK', 'Back');
?>