<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE', 'Search Results');
define('TOP_BAR_TITLE', 'Search Results');
define('HEADING_TITLE', 'Can\'t Find What Your Looking For?');
define('TABLE_HEADING_MODEL', 'Products Model');
define('TABLE_HEADING_PRODUCTS', 'Products Name');
define('TABLE_HEADING_PRICE', 'Products Price');
define('TEXT_NO_PRODUCTS', 'There is no product that matches the search criteria.');
?>