<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'History');
define('TOP_BAR_TITLE', 'Account History');
define('HEADING_TITLE', 'My Purchase History');
define('TABLE_HEADING_ORDER_NUMBER', 'Order No.');
define('TABLE_HEADING_ORDER_DATE', 'Order Date');
define('TABLE_HEADING_ORDER_COST', 'Order Cost');
define('TABLE_HEADING_ORDER_STATUS', 'Order Status');
define('TEXT_NO_PURCHASES', 'You have not yet made any purchases with us..');
define('TABLE_TEXT', 'Click on the \'Order Date\' to view the order information');

define('IMAGE_BACK', 'Back');
?>