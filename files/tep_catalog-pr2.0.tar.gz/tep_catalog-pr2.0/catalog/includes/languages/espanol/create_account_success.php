<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE_1', 'Crear una Cuenta');
define('NAVBAR_TITLE_2', 'Exito');
define('TOP_BAR_TITLE', 'Cuenta Creada con Exito!');
define('HEADING_TITLE', 'Su cuenta ha sido creada!');
define('TEXT_ACCOUNT_CREATED', 'Enhorabuena! Su cuenta ha sido creada con exito! Ahora puede disfrutar de las ventajas de disponer de una cuenta para mejorar su navegacion en nuestro catalogo. Si tiene <small><b>CUALQUIER</b></small> pregunta sobre el funcionamiento del catalogo, por favor comuniquela a <a href="mailto:' . STORE_OWNER_EMAIL_ADDRESS . '">' . STORE_OWNER_EMAIL_ADDRESS . '</a>.<br><br>Se ha enviado una confirmacion a la direccion de correo que nos ha proporcionado. Si no lo ha recibido en 1 hora pongase en contacto con nosotros.');

define('IMAGE_LETS_SHOP', 'A Comprar!');
?>