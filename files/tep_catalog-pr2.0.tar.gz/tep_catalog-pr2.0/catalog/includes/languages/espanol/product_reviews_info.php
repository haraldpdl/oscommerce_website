<?
/*
Spanish Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): David Garcia Watkins (dgw@q-logic.org)
*/

define('NAVBAR_TITLE', 'Comentarios');
define('TOP_BAR_TITLE', 'Comentarios');
define('HEADING_TITLE', ' %s Comentarios');
define('SUB_TITLE_PRODUCT', 'Producto:');
define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_DATE', 'Fecha:');
define('SUB_TITLE_REVIEW', 'Comentario:');
define('SUB_TITLE_RATING', 'Evaluacion:');
define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');

define('IMAGE_WRITE_A_REVIEW', 'Deje su Comentario');
define('IMAGE_BACK', 'Volver');
?>