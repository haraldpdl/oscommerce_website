<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Mein Konto');
define('NAVBAR_TITLE_2', 'Adre&szlig;buch');
define('NAVBAR_TITLE_ADD_ENTRY', 'Neuer Eintrag');
define('NAVBAR_TITLE_MODIFY_ENTRY', 'Eintrag &auml;ndern');
define('TOP_BAR_TITLE_ADD_ENTRY', 'Neuer Adre&szlig;bucheintag :');
define('TOP_BAR_TITLE_MODIFY_ENTRY', '&Auml;nderung des Eintrags');
define('HEADING_TITLE_ADD_ENTRY', 'Neuer Adre&szlig;bucheintrag :');
define('HEADING_TITLE_MODIFY_ENTRY', 'Adre&szlig;bucheintrag :');
define('PLEASE_SELECT', 'Bitte w&auml;hlen');

define('IMAGE_INSERT', 'Einf&uuml;gen');
define('IMAGE_CANCEL', 'Abbrechen');
define('IMAGE_UPDATE', 'Aktualisieren');
define('IMAGE_DELETE', 'L&ouml;schen');
?>