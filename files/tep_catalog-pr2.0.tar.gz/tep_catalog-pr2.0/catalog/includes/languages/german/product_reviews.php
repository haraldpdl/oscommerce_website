<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Meinungen');
define('TOP_BAR_TITLE', 'Meinungen');
define('HEADING_TITLE', '%s Meinungen');
define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_AUTHOR', 'Autor');
define('TABLE_HEADING_RATING', 'Bewertung');
define('TABLE_HEADING_READ', 'Wurde gelesen');
define('TABLE_HEADING_DATE_ADDED', 'Datum');
define('TEXT_OF_5_STARS', '%s von 5 Stars!');
define('TEXT_NO_REVIEWS', 'Es gibt keine meinungen &uuml;ber dieses Produkt!');

define('IMAGE_WRITE_A_REVIEW', 'Meinung Erstellen');
define('IMAGE_BACK', 'Zur&uuml;ck');
?>