<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Meinungen');
define('TOP_BAR_TITLE', '%s Meinungen');
define('HEADING_TITLE', 'Was sagen Sie dazu?');
define('SUB_TITLE_PRODUCT', 'Produkt:');
define('SUB_TITLE_FROM', 'Autor:');
define('SUB_TITLE_REVIEW', 'Meinung:');
define('SUB_TITLE_RATING', 'Bewertung:');
define('TEXT_NO_HTML', '<small><font color="#ff0000"><b>ACHTUNG:</b></font></small>&nbsp;HTML ist nicht unterst&uuml;tzt!');
define('TEXT_BAD', '<small><font color="#ff0000"><b>SCHLECHT</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>SEHR GUT</b></font></small>');

define('IMAGE_INSERT', 'Einf&uuml;gen');
define('IMAGE_CANCEL', 'Abbrechen');
?>