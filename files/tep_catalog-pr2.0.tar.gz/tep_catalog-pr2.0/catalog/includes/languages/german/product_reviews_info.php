<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Meinungen');
define('TOP_BAR_TITLE', 'Meinungen');
define('HEADING_TITLE', '%s Meinungen');
define('SUB_TITLE_PRODUCT', 'Produkt:');
define('SUB_TITLE_FROM', 'Autor:');
define('SUB_TITLE_DATE', 'Datum:');
define('SUB_TITLE_REVIEW', 'Meinung:');
define('SUB_TITLE_RATING', 'Bewertung:');
define('TEXT_OF_5_STARS', '%s von 5 Stars!');

define('IMAGE_WRITE_A_REVIEW', 'Meinung Erstellen');
define('IMAGE_BACK', 'Zur&uuml;ck');
?>