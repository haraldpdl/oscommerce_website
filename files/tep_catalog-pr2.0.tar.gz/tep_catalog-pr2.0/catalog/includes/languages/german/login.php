<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE', 'Anmelden');
define('TOP_BAR_TITLE', 'Anmelden zu dem \'' . STORE_NAME .  '\'');
define('HEADING_TITLE', 'Melden Sie sich an');
define('ENTRY_EMAIL_ADDRESS', 'E-Mail Adresse:');
define('ENTRY_PASSWORD', 'Passwort:');
define('TEXT_COOKIE', 'Speichern Sie die Anmeldeinformation in einem cookie?');
define('TEXT_PASSWORD_FORGOTTEN', 'Passwort Vergessen? Klicken Sie hier.');
define('TEXT_CREATE_ACCOUNT', 'Kein Konto?  Klicken Sie hier, um ein zu erstellen.');
define('TEXT_VISITORS_CART', '<font color="#ff0000"><b>ACHTUNG:</b></font> Ihre Besuchereingaben werden automatisch mit ihrem Mitgliedschaft Konto verbunden. <a href="javascript:session_win();">[Mehr Information]</a>');
define('TEXT_LOGIN_ERROR', '<font color="#ff0000"><b>FEHLER:</b></font> Keine &Uuml;bereinstimmung der \'E-Mail Adresse\' und/oder dem \'Passwort\'.');

define('IMAGE_LOGIN', 'Anmelden');
?>
