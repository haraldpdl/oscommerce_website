<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Best&auml;tigung');
define('TOP_BAR_TITLE', 'Bestellassistent');
define('HEADING_TITLE', 'Bestellung absenden :');
define('TABLE_HEADING_QUANTITY', 'Menge');
define('TABLE_HEADING_PRODUCTS', 'Produkte');
define('TABLE_HEADING_TAX', 'Mwst.');
define('TABLE_HEADING_TOTAL', 'Summe');
define('TABLE_HEADING_DELIVERY_ADDRESS', 'Lieferanschrift');
define('TABLE_HEADING_PAYMENT_METHOD', 'Zahlungsweise');
define('SUB_TITLE_SUB_TOTAL', 'Zwischensumme:');
define('SUB_TITLE_TAX', 'Mwst.:');
define('SUB_TITLE_SHIPPING', 'Versandkosten:');
define('SUB_TITLE_TOTAL', 'Summe:');
define('TEXT_CASH_ON_DELIVERY', 'Nachnahme');
define('TEXT_CREDIT_CARD', 'Kreditkarte');
define('TEXT_TYPE', 'Typ:');
define('TEXT_OWNER', 'Eigent&uuml;mer:');
define('TEXT_NUMBER', 'Nummer:');
define('TEXT_EXPIRES', 'G&uuml;ltig bis:');
define('TEXT_VAL', 'Kredit Karte Fehler!');
define('TEXT_PAYPAL', 'PayPal');

define('TEXT_PAYMENT', 'Payment');

define('IMAGE_PROCESS', 'Best&auml;tigung');
define('IMAGE_BACK', 'Zur&uuml;ck');
?>
