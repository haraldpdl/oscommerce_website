<?
/*
German Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Mathias Kowalkowski (mathias@zoomed.de)
*/

define('NAVBAR_TITLE_1', 'Kasse');
define('NAVBAR_TITLE_2', 'Lieferanschrift');
define('TOP_BAR_TITLE', 'Bestellassistent');
define('HEADING_TITLE', 'M&ouml;gliche Lieferadressen :');
define('TABLE_HEADING_MY_ADDRESS', 'Meine Adresse');
define('TABLE_HEADING_DELIVER_TO', 'ausew&auml;hlte Adresse');
define('TABLE_HEADING_SHIPPING_INFO', 'Lieferung per');
define('TABLE_HEADING_ADDRESS_BOOK', 'Adre&szlig;bucheintr&auml;ge');
define('TEXT_ADDRESS_BOOK_NO_ENTRIES', 'Ihr Adre&szlig;buch ist leer!');
define('TEXT_MAXIMUM_ENTRIES_REACHED', '<font color="#ff0000"><b>ACHTUNG:</b></font> Sie haben die maximale Anzahl(' . MAX_ADDRESS_BOOK_ENTRIES . ') an Adre&szlig;bucheintr&auml;gen erreicht!');

define('IMAGE_ADD_ENTRY', 'Neuer Eintr&auml;g');
define('IMAGE_NEXT', 'Weiter');
?>
