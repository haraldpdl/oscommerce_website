<? include("includes/sysenv.php"); ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
<?
  if ($HTTP_GET_VARS["category_id"]) {
?>
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;New&nbsp;Products&nbsp;In&nbsp;This&nbsp;Category&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
    $top_category = $db_query("select category_top_name, category_image from category_top where category_top_id = $HTTP_GET_VARS[category_id]");
    $top_category_values = $db_fetch_array($top_category);
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Whats New Here?&nbsp;</font></td>
            <td align="right">&nbsp;<img src="<? echo $top_category_values["category_image"]; ?>" width="85" height="60" border="0" alt=" <? echo $top_category_values["category_top_name"]; ?> ">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr bgcolor="#f4f7fd">
            <td><font face="Verdana, Arial" size="1">&nbsp;Categories&nbsp;</font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
    if (($HTTP_GET_VARS[category_id]) && (!$HTTP_GET_VARS[index_id])) {
?>
          <tr>
<?
      $categories = $db_query("select category_index.category_index_id, category_index.category_index_name from category_index, category_index_to_top where category_index_to_top.category_top_id = $HTTP_GET_VARS[category_id] and category_index_to_top.category_index_id = category_index.category_index_id");
      echo '            <td><font face="Verdana, Arial" size="1">';
      while ($categories_values = $db_fetch_array($categories)) {
        echo '&nbsp;<a href="default.php?category_id=' . $HTTP_GET_VARS[category_id] . '&index_id=' . $categories_values["category_index_id"] . '">' . $categories_values["category_index_name"] . '</a><br>';
      }
      echo "</font></td>\n";
?>
          </tr>
<?
    } elseif (($HTTP_GET_VARS[category_id]) && ($HTTP_GET_VARS[index_id])) {
?>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
<?
      $categories_count = $db_query("select count(*) as count from subcategories, subcategories_to_category where subcategories.subcategories_id = subcategories_to_category.subcategories_id and subcategories_to_category.category_top_id = $HTTP_GET_VARS[category_id]");
      $categories_count_values = $db_fetch_array($categories_count);

      $listby_query = $db_query("select sql_select from category_index where category_index_id = $HTTP_GET_VARS[index_id]");
      $listby_values = $db_fetch_array($listby_query);
      $listby = $listby_values["sql_select"];

      $subcategories = $db_query("select " . $listby . "." . $listby . "_id as id, " . $listby . "." . $listby . "_name as name, " . $listby . "." . $listby . "_image as image from " . $listby . ", " . $listby . "_to_category where " . $listby . "_to_category.category_top_id = $HTTP_GET_VARS[category_id] and " . $listby . "_to_category." . $listby . "_id = " . $listby . "." . $listby . "_id order by " . $listby . "." . $listby . "_name");
      $row = 0;
      while ($subcategories_values = $db_fetch_array($subcategories)) {
        $row++;
        $number_of_products = $db_query("select count(*) as total from products_to_" . $listby . " where " . $listby . "_id = $subcategories_values[id]");
        $number_of_products_values = $db_fetch_array($number_of_products);
        echo '                <td align="center"><font face="Verdana, Arial" size="2">&nbsp;<a href="product_list.php?category_id=' . $HTTP_GET_VARS[category_id] . '&index_id=' . $HTTP_GET_VARS[index_id] . '&subcategory_id=' . $subcategories_values["id"] . '"><img src="' . $subcategories_values["image"] . '" width="100" height="57" border="0" alt=" ' . $subcategories_values["name"] . ' "></a>&nbsp;<br>&nbsp;<a href="product_list.php?category_id=' . $HTTP_GET_VARS[category_id] . '&index_id=' . $HTTP_GET_VARS[index_id] . '&subcategory_id=' . $subcategories_values["id"] . '">' . $subcategories_values["name"] . '</a>&nbsp;(' . $number_of_products_values["total"] . ')&nbsp;</font></td>' . "\n";
        if ((($row / 3) == floor($row / 3)) && ($row != $categories_count_values["count"])) {
          echo '              </tr>' . "\n";
          echo '              <tr>' . "\n";
          echo '                <td>&nbsp;</td>' . "\n";
          echo '              </tr>' . "\n";
          echo '              <tr>' . "\n";
        }    
      }
?>
              </tr>
            </table></td>
          </tr>
<?
    }
?>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2"><a name="general"></a><br><b>&nbsp;New Products For <? echo date("F, Y"); ?>&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
<?
    $new = $db_query("select products.products_id, products.products_name, products.products_image, manufacturers.manufacturers_name, manufacturers.manufacturers_location from products, products_to_manufacturers, manufacturers, products_to_subcategories, subcategories_to_category where products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id and products.products_id = products_to_subcategories.products_id and products_to_subcategories.subcategories_id = subcategories_to_category.subcategories_id and subcategories_to_category.category_top_id = $HTTP_GET_VARS[category_id] order by products.products_date_added DESC, products.products_id DESC limit $max_display_new_products");
    $current_row = 0;
    while ($new_values = $db_fetch_array($new)) {
      $current_row++;
      if ($new_values["manufacturers_location"] == 0) {
        $product_name = $new_values["manufacturers_name"] . ' ' . $new_values["products_name"];
      } else {
        $product_name = $new_values["products_name"] . ' (' . $new_values["manufacturers_name"] . ')';
      }
      echo '                <td align="center"><font face="Verdana, Arial" size="2"><a href="product_info.php?products_id=' . $new_values["products_id"] . '"><img src="' . $new_values["products_image"] . '" width="100" height="80" border="0" alt="' . $product_name . '"></a><br><a href="product_info.php?products_id=' . $new_values["products_id"] . '">' . $product_name . '</a></font></td>' . "\n";
      if ((($current_row / 3) == floor($current_row / 3)) && ($current_row != $db_num_rows($new))) {
        echo '              </tr>' . "\n";
        echo '              <tr>' . "\n";
        echo '                <td>&nbsp;</td>' . "\n";
        echo '              </tr>' . "\n";
        echo '              <tr>' . "\n";
      }
    }
?>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
<?
  } else {
?>
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Welcome&nbsp;To&nbsp;The&nbsp;Exchange&nbsp;Project!&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Whats New Here?&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_default.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr bgcolor="#f4f7fd">
            <td><font face="Verdana, Arial" size="1">&nbsp;Sunday, 6th February, 2000&nbsp;</font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">Welcome to the Exchange Project! This is a demonstration online-shop, these prices do not reflect their retail price, and any products purchased will not be delivered nor billed. Any information seen on these products are to be treated fictional.<br><br>If you wish to download this sample shop, or to contribute to this project, please go to the <a href="/">support site</a>.</font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2"><a name="general"></a><br><b>&nbsp;New Products For <? echo date("F, Y"); ?>&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
<?
    $new = $db_query("select products.products_id, products.products_name, products.products_image, manufacturers.manufacturers_name, manufacturers.manufacturers_location from products, products_to_manufacturers, manufacturers where products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by products.products_date_added DESC, products.products_id DESC limit $max_display_new_products_start");
    $current_row = 0;
    while ($new_values = $db_fetch_array($new)) {
      $current_row++;
      if ($new_values["manufacturers_location"] == 0) {
        $product_name = $new_values["manufacturers_name"] . ' ' . $new_values["products_name"];
      } else {
        $product_name = $new_values["products_name"] . ' (' . $new_values["manufacturers_name"] . ')';
      }
      echo '                <td align="center"><font face="Verdana, Arial" size="2"><a href="product_info.php?products_id=' . $new_values["products_id"] . '"><img src="' . $new_values["products_image"] . '" width="100" height="80" border="0" alt="' . $product_name . '"></a><br><a href="product_info.php?products_id=' . $new_values["products_id"] . '">' . $product_name . '</a></font></td>' . "\n";
      if ((($current_row / 3) == floor($current_row / 3)) && ($current_row != $max_display_new_products_start)) {
        echo '              </tr>' . "\n";
        echo '              <tr>' . "\n";
        echo '                <td>&nbsp;</td>' . "\n";
        echo '              </tr>' . "\n";
        echo '              <tr>' . "\n";
      }
    }
?>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
              <tr>
                <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
              </tr>
              <tr>
                <td><font face="Verdana, Arial" size="2"><b>&nbsp;Upcoming Products&nbsp;</b></font></td>
                <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Date&nbsp;Expected&nbsp;</b></font></td>
              </tr>
              <tr>
                <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
              </tr>
              <tr>
<?
    $expected = $db_query("select products_name, date_expected from products_expected order by date_expected DESC limit $max_upcoming_products");
    $current_row = 0;
    while ($expected_values = $db_fetch_array($expected)) {
      $current_row++;
      if (($current_row / 2) == floor($current_row / 2)) {
        echo '              <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '              <tr bgcolor="#f4f7fd">' . "\n";
      }
      echo '                <td><font face="Verdana, Arial" size="1">&nbsp;' . $expected_values["products_name"] . '&nbsp;</font></td>' . "\n";
      echo '                <td align="right"><font face="Verdana, Arial" size="1">&nbsp;' . date("d/m/Y", mktime(0,0,0,substr($expected_values["date_expected"], 4, 2), substr($expected_values["date_expected"], -2), substr($expected_values["date_expected"], 0, 4))) . '&nbsp;</font></td>' . "\n";
      echo '              </tr>' . "\n";
    }
?>
              <tr>
                <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
<?
  }
?>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
