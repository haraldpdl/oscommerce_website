<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="account.php" class="whitelink">My Account</a> : <a href="account_edit.php" class="whitelink">Edit Account</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<script language="javascript"><!--
function check_form() {
  var error = 0;
  var error_message = "Errors have occured during the process of your form!\nPlease make the following corrections:\n\n";

  var firstname = document.account_edit.firstname.value;
  var lastname = document.account_edit.lastname.value;
  var dob = document.account_edit.dob.value;
  var email_address = document.account_edit.email_address.value;  
  var street_address = document.account_edit.street_address.value;
  var postcode = document.account_edit.postcode.value;
  var city = document.account_edit.city.value;
  var country = document.account_edit.country.value;
  var telephone = document.account_edit.telephone.value;
  var password = document.account_edit.password.value;
  var confirmation = document.account_edit.confirmation.value;

  if (document.account_edit.gender[0].checked || document.account_edit.gender[1].checked) {
  } else {
    error_message = error_message + "* Your 'Gender' must be selected.\n";
    error = 1;
  }
  
  if (firstname = "" || firstname.length < 3) {
    error_message = error_message + "* Your 'First Name' must be atleast 3 characters.\n";
    error = 1;
  }

  if (lastname = "" || lastname.length < 3) {
    error_message = error_message + "* Your 'Last Name' must be atleast 3 characters.\n";
    error = 1;
  }

  if (dob = "" || dob.length < 10) {
    error_message = error_message + "* Your 'Date of Birth' must be in this format: xx/xx/xxxx (date/month/year).\n";
    error = 1;
  }

  if (email_address = "" || email_address.length < 6) {
    error_message = error_message + "* Your 'E-Mail Address' must be atleast 6 characters.\n";
    error = 1;
  }

  if (street_address = "" || street_address.length < 5) {
    error_message = error_message + "* Your 'Street Address' must be atleast 5 characters.\n";
    error = 1;
  }

  if (postcode = "" || postcode.length < 4) {
    error_message = error_message + "* Your 'Post Code' must be atleast 4 characters.\n";
    error = 1;
  }

  if (city = "" || city.length < 4) {
    error_message = error_message + "* Your 'City' must be atleast 4 characters.\n";
    error = 1;
  }

  if (country = "" || country.length < 3) {
    error_message = error_message + "* Your 'Country' must be atleast 3 characters.\n";
    error = 1;
  }

  if (telephone = "" || telephone.length < 5) {
    error_message = error_message + "* Your 'Telephone No.' must be atleast 5 characters.\n";
    error = 1;
  }

  if ((password != confirmation) || (password = "" || password.length < 5)) {
    error_message = error_message + "* Your 'Password' amd 'Confirmation' must match amd be atleast 5 characters.\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
<?
  $account = $db_query("select customers_gender, customers_firstname, customers_lastname, customers_dob, customers_email_address, customers_street_address, customers_suburb, customers_postcode, customers_city, customers_state, customers_country, customers_telephone, customers_fax, customers_password from customers where customers_id = $customer_id");
  $account_values = $db_fetch_array($account);
?>
    <td width="100%" valign="top"><form name="account_edit" method="post" <? echo 'action="account_edit_process.php?' . SID . '"'; ?> onSubmit="return check_form();"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;My Account</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;My Account Information&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_account.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="100%"><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Personal ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Gender:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="radio" name="gender" value="m"<?
  if ($account_values["customers_gender"] == "m") {
    echo ' CHECKED';
  } ?>>&nbsp;&nbsp;Male&nbsp;&nbsp;<input type="radio" name="gender" value="f"<?
  if ($account_values["customers_gender"] == "f") {
    echo ' CHECKED';
  } ?>>&nbsp;&nbsp;Female&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>


          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;First Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="firstname" maxlength="32" value="<? echo $account_values["customers_firstname"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Last Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="lastname" maxlength="32" value="<? echo $account_values["customers_lastname"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Date of Birth:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="dob" value="<? echo substr($account_values["customers_dob"], -2) . "/" . substr($account_values["customers_dob"], 4, 2) . "/" . substr($account_values["customers_dob"], 0, 4); ?>" maxlength="10">&nbsp;&nbsp;<small>(eg. 21/05/1970) <font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;E-Mail Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="email_address" maxlength="96" value="<? echo $account_values["customers_email_address"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Address ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Street Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="street_address" maxlength="64" value="<? echo $account_values["customers_street_address"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Suburb:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="suburb" maxlength="32" value="<? echo $account_values["customers_suburb"]; ?>">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Post Code:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="postcode" maxlength="8" value="<? echo $account_values["customers_postcode"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;City:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="city" maxlength="32" value="<? echo $account_values["customers_city"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;State:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="state" maxlength="32" value="<? echo $account_values["customers_state"]; ?>">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Country:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="country" maxlength="32" value="<? echo $account_values["customers_country"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Contact ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Telephone No.:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="telephone" maxlength="32" value="<? echo $account_values["customers_telephone"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Fax No.:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="fax" maxlength="32" value="<? echo $account_values["customers_fax"]; ?>">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Password ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Password:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="password" name="password" maxlength="12" value="<? echo $account_values["customers_password"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Confirmation:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="password" name="confirmation" maxlength="12" value="<? echo $account_values["customers_password"]; ?>">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2">&nbsp;<input type="image" src="images/button_update.gif" width="78" height="24" border="0" alt=" Update ">&nbsp;&nbsp;&nbsp;&nbsp;<a href="account.php"><img src="images/button_cancel.gif" width="72" height="24" border="0" alt=" Cancel "></a>&nbsp;</font></td>
      </tr>
    </table></form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
