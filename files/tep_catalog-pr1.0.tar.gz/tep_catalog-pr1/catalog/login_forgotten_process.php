<? include("includes/sysenv.php"); ?>
<?  include("includes/counter.php"); ?>
<?
  $check_customer = $db_query("select customers_password from customers where customers_email_address = '$HTTP_POST_VARS[email_address]'");
  if ($db_num_rows($check_customer)) {
    $check_customer_values = $db_fetch_array($check_customer);
    mail("$HTTP_POST_VARS[email_address]", "Exchange - Password Reminder", "A password reminder has been requested by $REMOTE_ADDR.

Your password to Exchange is:
    
$check_customer_values[customers_password]
","From: Harald Ponce de Leon <hap@theexchangeproject.org>");

    header("Location: login.php?" . SID);
  } else {
    header("Location: login_forgotten.php?email=nonexistent&" . SID);
  }
?>
