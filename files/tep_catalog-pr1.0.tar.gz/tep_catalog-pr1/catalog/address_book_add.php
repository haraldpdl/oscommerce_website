<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="account.php" class="whitelink">My Account</a> : <a href="address_book.php" class="whitelink">Address Book</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<script language="javascript"><!--
function check_form() {
  var error = 0;
  var error_message = "Errors have occured during the process of your form!\nPlease make the following corrections:\n\n";

  var firstname = document.add_entry.firstname.value;
  var lastname = document.add_entry.lastname.value;
  var street_address = document.add_entry.street_address.value;
  var postcode = document.add_entry.postcode.value;
  var city = document.add_entry.city.value;
  var country = document.add_entry.country.value;

  if (document.add_entry.gender[0].checked || document.add_entry.gender[1].checked) {
  } else {
    error_message = error_message + "* Their 'Gender' must be selected.\n";
    error = 1;
  }

  if (firstname = "" || firstname.length < 3) {
    error_message = error_message + "* Their 'First Name' must be atleast 3 characters.\n";
    error = 1;
  }

  if (lastname = "" || lastname.length < 3) {
    error_message = error_message + "* Their 'Last Name' must be atleast 3 characters.\n";
    error = 1;
  }

  if (street_address = "" || street_address.length < 5) {
    error_message = error_message + "* Their 'Street Address' must be atleast 5 characters.\n";
    error = 1;
  }

  if (postcode = "" || postcode.length < 4) {
    error_message = error_message + "* Their 'Post Code' must be atleast 4 characters.\n";
    error = 1;
  }

  if (city = "" || city.length < 4) {
    error_message = error_message + "* Their 'City' must be atleast 4 characters.\n";
    error = 1;
  }

  if (country = "" || country.length < 3) {
    error_message = error_message + "* Their 'Country' must be atleast 3 characters.\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><form name="add_entry" method="post" <? echo 'action="address_book_add_process.php?' . SID . '"'; ?> onSubmit="return check_form();"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Address Book Entries</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;New Address Book Entry&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_address_book.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="100%"><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="6"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Personal ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Gender:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="radio" name="gender" value="m">&nbsp;&nbsp;Male&nbsp;&nbsp;<input type="radio" name="gender" value="f">&nbsp;&nbsp;Female&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;First Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="firstname" maxlength="32">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Last Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="lastname" maxlength="32">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Address ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Street Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="street_address" maxlength="64">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Suburb:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="suburb" maxlength="32">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Post Code:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="postcode" maxlength="8">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;City:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="city" maxlength="32">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;State:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="state" maxlength="32">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Country:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="country" maxlength="32">&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><input type="image" src="images/button_insert.gif" width="70" height="24" alt=" Insert ">&nbsp;&nbsp;&nbsp;&nbsp;<? if ($HTTP_GET_VARS["origin"]) { echo '<a href="' . $HTTP_GET_VARS["origin"] . '.php">'; } else { echo '<a href="address_book.php">'; } ?><img src="images/button_cancel.gif" width="72" height="24" border="0" alt=" Cancel "></a>&nbsp;</font></td>
      </tr>
    </table><? if ($HTTP_GET_VARS["origin"]) { echo '<input type="hidden" name="origin" value="' . $HTTP_GET_VARS["origin"] . '">'; } ?></form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
