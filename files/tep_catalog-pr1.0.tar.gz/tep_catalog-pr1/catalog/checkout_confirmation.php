<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="checkout.php" class="whitelink">Checkout</a> : Confirmation'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><form name="checkout_confirmation" <? echo 'action="checkout_process.php?' . SID . '"'; ?> method="post"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Checkout Procedure&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;I'm Ready To Purchase!&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_confirmation.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Qty&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Product&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Total&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $check_cart = $db_query("select customers_basket.customers_basket_quantity, manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_id, products.products_name, products.products_price from customers_basket, manufacturers, products_to_manufacturers, products where customers_basket.customers_id = $customer_id and customers_basket.products_id = products.products_id and products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by customers_basket.customers_basket_id");
  $total_cost = 0;
  while ($check_cart_values = $db_fetch_array($check_cart)) {
    $price = $check_cart_values["products_price"];
    $check_special = $db_query("select specials_new_products_price from specials where products_id = " . $check_cart_values["products_id"]);
    if ($db_num_rows($check_special)) {
      $check_special_values = $db_fetch_array($check_special);
      $price = $check_special_values["specials_new_products_price"];
    }
    echo '          <tr>' . "\n";
    echo '            <td align="center"><font face="Verdana, Arial" size="2">&nbsp;' . $check_cart_values["customers_basket_quantity"] . '&nbsp;</font></td>' . "\n";
    if ($check_cart_values["manufacturers_location"] == 0) {
      echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $check_cart_values["manufacturers_name"] . ' ' . $check_cart_values["products_name"] . '&nbsp;</font></td>' . "\n";
    } else {
      echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $check_cart_values["products_name"] . ' (' . $check_cart_values["manufacturers_name"] . ')&nbsp;</font></td>' . "\n";
    }
    echo '            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;$' . number_format(($check_cart_values["customers_basket_quantity"] * $price),2) . '&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
    $total_cost = $total_cost + ($check_cart_values["customers_basket_quantity"] * $price);
  }
?>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td colspan="3" align="right"><table border="0" width="100%" cellspacing="0" cellpadding="0" align="right">
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;Sub-Total:&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;$<? echo number_format($total_cost,2); ?>&nbsp;</font></td>
              </tr>
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;Tax (16%):&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;$<? echo number_format(($total_cost * 16/100),2); ?>&nbsp;</font></td>
              </tr>
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;<b>Total:</b>&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;<b>$<? echo number_format((($total_cost * 16/100) + $total_cost),2); ?></b>&nbsp;</font></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Delivery Address&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if ($HTTP_POST_VARS["sendto"] == 0) {
    $address = $db_query("select customers_firstname as firstname, customers_lastname as lastname, customers_street_address as street_address, customers_suburb as suburb, customers_postcode as postcode, customers_city as city, customers_state as state, customers_country as country from customers where customers_id = $customer_id");
  } else {
    $address = $db_query("select entry_firstname as firstname, entry_lastname as lastname, entry_street_address as street_address, entry_suburb as suburb, entry_postcode as postcode, entry_city as city, entry_state as state, entry_country as country from address_book where address_book_id = $HTTP_POST_VARS[sendto]");
  }
  $address_values = $db_fetch_array($address);
?>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["firstname"] . ' ' . $address_values["lastname"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["street_address"]; ?>&nbsp;</font></td>
          </tr>
<?
  if ($address_values["suburb"] != "") {
    echo '          <tr>' . "\n";
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $address_values["suburb"] . '&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
  }
?>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["city"] . ', ' . $address_values["postcode"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
<?
  if ($address_values["state"] != "") {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $address_values["state"] . ', ' . $address_values["country"] . '&nbsp;</font></td>' . "\n";
  } else {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $address_values["country"] . '&nbsp;</font></td>' . "\n";
  }
?>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Payment Method&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if ($HTTP_POST_VARS["payment"] == "cod") {
    echo '          <tr>' . "\n";
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;Cash on Delivery&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
  } else if ($HTTP_POST_VARS["payment"] == "cc") {
?>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Credit Card&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Type:&nbsp;<? echo $HTTP_POST_VARS["cc_type"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Owner:&nbsp;<? echo $HTTP_POST_VARS["cc_owner"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Number:&nbsp;<? echo $HTTP_POST_VARS["cc_number"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Expires:&nbsp;<? echo $HTTP_POST_VARS["cc_expires"]; ?>&nbsp;</font></td>
          </tr>
<?
  }
?>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td align="right"><br><font face="Verdana, Arial" size="2">&nbsp;<input type="image" src="images/button_process.gif" width="78" height="24" border="0" alt=" Process ">&nbsp;</font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="1" color="#AABBDD">&nbsp;[ cart contents | delivery address | payment method | <font color="#000000">confirmation</font> | finished! ]&nbsp;</font></td>
      </tr>
    </table>
    <input type="hidden" name="sendto" value="<? echo $HTTP_POST_VARS["sendto"]; ?>">
    <input type="hidden" name="payment" value="<? echo $HTTP_POST_VARS["payment"]; ?>">
<?
  if ($HTTP_POST_VARS["payment"] == "cc") {
?>
    <input type="hidden" name="cc_type" value="<? echo $HTTP_POST_VARS["cc_type"]; ?>">
    <input type="hidden" name="cc_owner" value="<? echo $HTTP_POST_VARS["cc_owner"]; ?>">
    <input type="hidden" name="cc_number" value="<? echo $HTTP_POST_VARS["cc_number"]; ?>">
    <input type="hidden" name="cc_expires" value="<? echo $HTTP_POST_VARS["cc_expires"]; ?>">
<?
  }
?>
    </form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
