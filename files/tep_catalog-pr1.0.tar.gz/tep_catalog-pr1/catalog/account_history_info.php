<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="account.php" class="whitelink">My Account</a> : <a href="account_history.php" class="whitelink">History</a> : <a href="account_history_info.php?order_id=' . $HTTP_GET_VARS["order_id"] . '" class="whitelink">Order Information</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Order History&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Order Information&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_history.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Qty&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Product&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Total&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $orders_products = $db_query("select products_name, products_price, products_quantity from orders_products where orders_id = $HTTP_GET_VARS[order_id]");
  $total_cost = 0;
  while ($orders_products_values = $db_fetch_array($orders_products)) {
    echo '          <tr>' . "\n";
    echo '            <td align="center"><font face="Verdana, Arial" size="2">&nbsp;' . $orders_products_values["products_quantity"] . '&nbsp;</font></td>' . "\n";
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $orders_products_values["products_name"] . '&nbsp;</font></td>' . "\n";
    echo '            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;$' . number_format(($orders_products_values["products_quantity"] * $orders_products_values["products_price"]),2) . '&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
    $total_cost = $total_cost + ($orders_products_values["products_quantity"] * $orders_products_values["products_price"]);
  }
?>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td colspan="3" align="right"><table border="0" width="100%" cellspacing="0" cellpadding="0" align="right">
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;Sub-Total:&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;$<? echo number_format($total_cost,2); ?>&nbsp;</font></td>
              </tr>
<?
  $order = $db_query("select delivery_name, delivery_street_address, delivery_suburb, delivery_city, delivery_postcode, delivery_state, delivery_country, products_tax, payment_method from orders where orders_id = $HTTP_GET_VARS[order_id]");
  $order_values = $db_fetch_array($order);
?>
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;Tax (<? echo $order_values["products_tax"]; ?>%):&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;$<? echo number_format(($total_cost * $order_values["products_tax"]/100),2); ?>&nbsp;</font></td>
              </tr>
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;<b>Total:</b>&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;<b>$<? echo number_format((($total_cost * $order_values["products_tax"]/100) + $total_cost),2); ?></b>&nbsp;</font></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Delivery Address&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $order_values["delivery_name"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $order_values["delivery_street_address"]; ?>&nbsp;</font></td>
          </tr>
<?
  if ($order_values["delivery_suburb"] != "") {
    echo '          <tr>' . "\n";
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $order_values["delivery_suburb"] . '&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
  }
?>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $order_values["delivery_city"] . ', ' . $order_values["delivery_postcode"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
<?
  if ($order_values["delivery_state"] != "") {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $order_values["delivery_state"] . ', ' . $order_values["delivery_country"] . '&nbsp;</font></td>' . "\n";
  } else {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $order_values["delivery_country"] . '&nbsp;</font></td>' . "\n";
  }
?>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Payment Method&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if ($order_values["payment_method"] == "cod") {
    echo '          <tr>' . "\n";
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;Cash on Delivery&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
  } elseif ($order_values["payment_method"] == "cc") {
?>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Credit Card&nbsp;</font></td>
          </tr>
<?
  }
?>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td align="right"><br><font face="Verdana, Arial" size="2">&nbsp;<a href="account_history.php"><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
