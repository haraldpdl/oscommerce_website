<? include("includes/sysenv.php"); ?>
<html>
<head>
<title>Visitors Cart / Members Cart</title>
<style><!--
A { color:#000000; text-decoration:none; }
A:hover { color:#AABBDD; text-decoration:underline; }
//--></style>
</head>
<body>
<font face="Verdana, Arial" size="2">
<p><b>Visitors Cart / Members Cart</b><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></p>
<p><b><i>Visitors Cart</i></b><br>Every visitor to our online shop will be given a 'Visitors Cart'. This allows the visitor to store their products in a temporary shopping cart. Once the visitor leaves the online shop, so will the contents of their shopping cart.</p>
<p><b><i>Members Cart</i></b><br>Every member to our online shop that logs in is given a 'Members Cart'. This allows the member to add products to their shopping cart, and come back at a later date to finalize their checkout. All products remain in their shopping cart until the member has  checked them out, or removed the products themselves.</p>
<p><b><i>Info</i></b><br>If a member adds products to their 'Visitors Cart' and decides to log in to the online shop to use their 'Members Cart', the contents of their 'Visitors Cart' will merge with their 'Members Cart' contents automatically.</p>
<p align="right"><a href="javascript:window.close();"><font color="#AABBDD">[ close window ]</font></a></p>
</font>
</body>
</html>
<?  include("includes/counter.php"); ?>