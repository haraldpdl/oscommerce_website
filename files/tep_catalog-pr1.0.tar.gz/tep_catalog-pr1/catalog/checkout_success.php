<? include("includes/sysenv.php"); ?>
<? $page_location = ' : Checkout : Process Complete'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Checkout Procedure Complete!&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="5">
          <tr>
            <td><img src="images/table_background_man_on_board.gif" width="175" height="198" border="0" alt=""></td>
            <td><font face="Verdana, Arial" size="2"><div align="center"><font size="4"><br>Your Checkout Has Been Processed!<br>&nbsp;</font></div>Your checkout has been successfully processed! Your products will arrive at their destination within 2-5 working days.<br><br>You can view your order history by going to your <a href="account.php">'My Account'</a> page and by clicking on <a href="account_history.php">'History'</a>.<br><br>If you have any questions about the checkout procedure, please direct them to the <a href="mailto:hap@theexchangeproject.org">webmaster</a>.<br><br><font size="3">Thanks for shopping with us online!</font></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
<?
  if ($SSLCheckout == "1") {
    if (getenv("HTTPS") == "on") {
      echo '        <td align="right"><br><a href="http://' . getenv("HTTP_HOST") . '/catalog/default.php?' . SID . '"><img src="images/button_main_menu.gif" width="112" height="24" border="0" alt=" Main Menu "></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>' . "\n";
    } else {
      echo '        <td align="right"><br><a href="default.php?' . SID . '"><img src="images/button_main_menu.gif" width="112" height="24" border="0" alt=" Main Menu "></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>' . "\n";
    }
  } else {
      echo '        <td align="right"><br><a href="default.php?' . SID . '"><img src="images/button_main_menu.gif" width="112" height="24" border="0" alt=" Main Menu "></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>' . "\n";
  }
?>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
