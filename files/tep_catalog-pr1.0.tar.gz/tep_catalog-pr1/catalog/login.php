<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="login.php" class="whitelink">Login</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<?
  if ($nonsess_cart) {
?>
<script language="javascript"><!--
function session_win() {
  window.open("info_shopping_cart.php","info_shopping_cart","height=460,width=400,toolbar=no,statusbar=no,scrollbars=yes").focus();
}
//--></script>
<?
  }
?>
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Login to 'Exchange'</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Let Me In!&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_login.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><form name="login" method="post" <? echo 'action="login_process.php?' . SID . '"'; ?>><br><table border="0" width="100%" cellspacing="0" cellpadding="3">
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;E-Mail Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="text" name="email_address" maxlength="96" value="<? if (($HTTP_COOKIE_VARS["email_address"]) && ($HTTP_COOKIE_VARS["password"])) { echo $HTTP_COOKIE_VARS["email_address"]; } ?>">&nbsp;&nbsp;</font></td>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Password:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<input type="password" name="password" maxlength="12" value="<? if (($HTTP_COOKIE_VARS["email_address"]) && ($HTTP_COOKIE_VARS["password"])) { echo $HTTP_COOKIE_VARS["password"]; } ?>">&nbsp;&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="4"><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td valign="top" colspan="2"><font face="Verdana, Arial" size="2"><small>&nbsp;<label for="setcookie"><input type="checkbox" name="setcookie" value="1" id="setcookie" <? if (($HTTP_COOKIE_VARS["email_address"]) && ($HTTP_COOKIE_VARS["password"])) { echo 'CHECKED'; } ?>>&nbsp;Save login information in a cookie?</label>&nbsp;</font></td>
            <td align="right" valign="top" colspan="2"><input type="image" src="images/button_log_in.gif" width="67" height="24" border="0" alt=" Log In ">&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td align="right" colspan="4"><font face="Verdana, Arial" size="2"><small>&nbsp;<a href="login_forgotten.php">Password forgotten? Click here to get it sent to you.</a>&nbsp;</small></font></td>
          </tr>
<?
  if ($nonsess_cart) {
?>
          <tr>
            <td colspan="4"><font face="Verdana, Arial" size="2" color="#AABBDD"><br><small>Note: Your "Visitors Cart" contents will be merged with your "Members Cart" contents once you have logged on. <a href="javascript:session_win();"><font color="#AABBDD">[More Info]</font></a></small></font></td>
          </tr>
<?
  }
  if ($HTTP_GET_VARS["login"] == "fail") {
?>
          <tr>
            <td colspan="4"><font face="Verdana, Arial" size="2" color="#FF0000"><small>Error: No match for 'E-Mail Address' and/or 'Password'.</small></font></td>
          </tr>
<?
  }
?>
        </table><? if ($HTTP_GET_VARS["origin"]) { echo '<input type="hidden" name="origin" value="' . $HTTP_GET_VARS["origin"] . '">'; } ?><? if ($HTTP_GET_VARS["products_id"]) { echo '<input type="hidden" name="products_id" value="' . $HTTP_GET_VARS["products_id"] . '">'; } ?></form></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
