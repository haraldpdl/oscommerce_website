<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="specials.php" class="whitelink">Specials</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Specials&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Get Them While Their Hot!&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_specials.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><a name="general"></a><b>&nbsp;Specials For <? echo date("F, Y"); ?>&nbsp;</b></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
<?
    $new = $db_query("select products.products_id, products.products_name, products.products_price, products.products_image, manufacturers.manufacturers_name, manufacturers.manufacturers_location, specials.specials_new_products_price from products, products_to_manufacturers, manufacturers, specials where products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id and specials.products_id = products.products_id order by specials.specials_date_added DESC limit 9");
    $row = 0;
    while ($new_values = $db_fetch_array($new)) {
      $row++;
      if ($new_values["manufacturers_location"] == 0) {
        $product_name = $new_values["manufacturers_name"] . ' ' . $new_values["products_name"];
      } else {
        $product_name = $new_values["products_name"] . ' (' . $new_values["manufacturers_name"] . ')';
      }
      echo '                <td align="center"><font face="Verdana, Arial" size="2"><a href="product_info.php?products_id=' . $new_values["products_id"] . '"><img src="' . $new_values["products_image"] . '" width="100" height="80" border="0" alt="' . $product_name . '"></a><br><a href="product_info.php?products_id=' . $new_values["products_id"] . '">' . $product_name . '</a><br><s>$' . $new_values["products_price"] . '</s>&nbsp;<font color="#FF0000">$' . $new_values["specials_new_products_price"] . '</font></font></td>' . "\n";
      if ((($row / 3) == floor($row / 3)) && ($row != 9)) {
        echo '              </tr>' . "\n";
        echo '              <tr>' . "\n";
        echo '                <td>&nbsp;</td>' . "\n";
        echo '              </tr>' . "\n";
        echo '              <tr>' . "\n";
      }    
    }
?>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="right"><br><a href="default.php"><img src="images/button_main_menu.gif" width="112" height="24" border="0" alt=" Main Menu "></a></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
