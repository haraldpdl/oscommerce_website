<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="checkout.php" class="whitelink">Checkout</a> : Cart Contents'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Checkout Procedure&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;I'm Ready To Purchase!&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_checkout.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
<?
  if (session_is_registered("customer_id")) {
    $check_cart = $db_query("select customers_basket.customers_basket_quantity, manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_id, products.products_name, products.products_price from customers_basket, manufacturers, products_to_manufacturers, products where customers_basket.customers_id = $customer_id and customers_basket.products_id = products.products_id and products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by customers_basket.customers_basket_id");
    $total_cost = 0;
    if ($db_num_rows($check_cart)) {
?>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Qty&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Product&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Total&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
      while ($check_cart_values = $db_fetch_array($check_cart)) {
        $price = $check_cart_values["products_price"];
        $check_special = $db_query("select specials_new_products_price from specials where products_id = " . $check_cart_values["products_id"]);
        if ($db_num_rows($check_special)) {
          $check_special_values = $db_fetch_array($check_special);
          $price = $check_special_values["specials_new_products_price"];
        }
        echo '          <tr>' . "\n";
        echo '            <td align="center"><font face="Verdana, Arial" size="2">&nbsp;' . $check_cart_values["customers_basket_quantity"] . '&nbsp;</font></td>' . "\n";
        if ($check_cart_values["manufacturers_location"] == 0) {
          echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $check_cart_values["manufacturers_name"] . ' ' . $check_cart_values["products_name"] . '&nbsp;</font></td>' . "\n";
        } else {
          echo '            <td><font face="Verdana, Arial" size="2">&nbsp;' . $check_cart_values["products_name"] . ' (' . $check_cart_values["manufacturers_name"] . ')&nbsp;</font></td>' . "\n";
        }
        echo '            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;$' . number_format(($check_cart_values["customers_basket_quantity"] * $price),2) . '&nbsp;</font></td>' . "\n";
        echo '          </tr>' . "\n";
        $total_cost = $total_cost + ($check_cart_values["customers_basket_quantity"] * $price);
      }
    } else {
      $cart_empty = 1;
    }
  } else {
    if (session_is_registered("nonsess_cart")) {
  ?>
            <tr>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Qty&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Product&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Total&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
      $total_cost = 0;
      $product_in_cart = 0;
      $nonsess_cart_contents = explode("|", $nonsess_cart);
      $row_number = 1;
      for ($i=0;$i<sizeof($nonsess_cart_contents);$i++) {
        $product_info = explode(":", $nonsess_cart_contents[$i]);
        if (($product_info[0] != 0) && ($product_info[1] != 0)) {
          $product_in_cart = 1;
          $check_cart = $db_query("select manufacturers.manufacturers_name, manufacturers.manufacturers_location, products_name, products_price from manufacturers, products, products_to_manufacturers where products.products_id = $product_info[0] and products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id");
          $check_cart_values = $db_fetch_array($check_cart);
          $price = $check_cart_values["products_price"];
          echo '          <tr>' . "\n";
          echo '            <td align="center"><font face="Verdana, Arial" size="2">&nbsp;' . $product_info[1] . '&nbsp;</font></td>' . "\n";
          if ($check_cart_values["manufacturers_location"] == 0) {
            echo '            <td><font face="Verdana, Arial" size="2">&nbsp;<a href="product_info.php?products_id=' . $product_info[0] . '">' . $check_cart_values["manufacturers_name"] . ' ' . $check_cart_values["products_name"] . '</a>&nbsp;</font></td>' . "\n";
          } else {
            echo '            <td><font face="Verdana, Arial" size="2">&nbsp;<a href="product_info.php?products_id=' . $product_info[0] . '">' . $check_cart_values["products_name"] . ' (' . $check_cart_values["manufacturers_name"] . ')</a>&nbsp;</font></td>' . "\n";
          }
          echo '            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;$' . ($product_info[1] * $check_cart_values["products_price"]) . '&nbsp;</font></td>' . "\n";
          echo '          </tr>' . "\n";
          $check_special = $db_query("select specials_new_products_price from specials where products_id = " . $product_info[0]);
          if ($db_num_rows($check_special)) {
            $check_special_values = $db_fetch_array($check_special);
            $price = $check_special_values["specials_new_products_price"];
          }
          $total_cost = $total_cost + ($product_info[1] * $price);
        }
        $row_number++;
      }
    }
    if ($product_in_cart == 0) {
      session_unregister("nonsess_cart");
    }
    if (!session_is_registered("nonsess_cart")) {
      $cart_empty = 1;
    }
  }
  if ($cart_empty == 1) {
    echo '          <tr>' . "\n";
    echo '            <td colspan="3"><font face="Verdana, Arial" size="2">&nbsp;Your Shopping Cart is empty!&nbsp;</font></td>' . "\n";
    echo '          </tr>' . "\n";
  }
?>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if ($cart_empty != 1) {
?>
          <tr>
            <td colspan="3" align="right"><table border="0" width="100%" cellspacing="0" cellpadding="0" align="right">
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;Sub-Total:&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;$<? echo number_format($total_cost,2); ?>&nbsp;</font></td>
              </tr>
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;Tax (16%):&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;$<? echo number_format(($total_cost * 16/100),2); ?>&nbsp;</font></td>
              </tr>
              <tr>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;<b>Total:</b>&nbsp;</font></td>
                <td align="right" width="100%"><font face="Verdana, Arial" size="2">&nbsp;<b>$<? echo number_format((($total_cost * 16/100) + $total_cost),2); ?></b>&nbsp;</font></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
<?
  if ($SSLCheckout == "1") {
    if (getenv("HTTPS") == "on") {
      echo '            <td><font face="Verdana, Arial" size="2">&nbsp;Current Status (click to change)&nbsp;<br>&nbsp;<a href="http://' . getenv("HTTP_HOST") . '/catalog/checkout.php?' . SID . '"><img src="images/button_secure_server.gif" width="157" height="24" border="0" alt=" Secure Server "></a>&nbsp;</font></td>' . "\n";
    } else {
      echo '            <td><font face="Verdana, Arial" size="2">&nbsp;Current Status (click to change)&nbsp;<br>&nbsp;<a href="https://' . getenv("HTTP_HOST") . '/catalog/checkout.php?' . SID . '"><img src="images/button_unsecure_server.gif" width="177" height="24" border="0" alt=" Unsecure Server "></a>&nbsp;</font></td>' . "\n";
    }
  } else {
      echo '            <td><font face="Verdana, Arial" size="2">&nbsp;</td>' . "\n";
  }
?>
            <td colspan="2" align="right"><br><font face="Verdana, Arial" size="2">&nbsp;<a href="checkout_address.php"><img src="images/button_next.gif" width="50" height="24" border="0" alt=" Next "></a>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="3"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="3" align="right"><font face="Verdana, Arial" size="1" color="#AABBDD">&nbsp;[ <font color="#000000">cart contents</font> | delivery address | payment method | confirmation | finished! ]&nbsp;</font></td>
          </tr>
<?
  }
?>
        </table></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
