<? include("includes/sysenv.php"); ?>
<?
  if (!session_is_registered("customer_id")) {
    header("Location: login.php?origin=product_reviews_write&products_id=" . $HTTP_GET_VARS["products_id"] . "&" . SID);
  }

// lets retrieve all $HTTP_GET_VARS keys and values..
  $keys = array_keys($HTTP_GET_VARS);
  $values = array_values($HTTP_GET_VARS);

  $get_params = "";
  $get_params_back = ""; // for back button
  for ($i=0;$i<sizeof($keys);$i++) {
    $get_params.=$keys[$i] . '=' . $values[$i] . '&';
    if ($keys[$i] != "reviews_id") {
      $get_params_back.=$keys[$i] . '=' . $values[$i] . '&';
    }
  }
  $get_params = substr($get_params, 0, -1); //remove trailing &
  if ($get_params_back != "") {
    $get_params_back = substr($get_params_back, 0, -1); //remove trailing &
  } else {
    $get_params_back = $get_params;
  }
?>
<? $page_location = ' : <a href="product_reviews_write.php?' . $get_params . '" class="whitelink">Reviews</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function checkForm() {
  var error = 0;
  var error_message = "Errors have occured during the process of your form!\nPlease make the following corrections:\n\n";

  var review = document.product_reviews_write.review.value;

  if (review.length < 50) {
    error_message = error_message + "* The review text must be atleast 50 characters.\n";
    error = 1;
  }

  if ((document.product_reviews_write.rating[0].checked) || (document.product_reviews_write.rating[1].checked) || (document.product_reviews_write.rating[2].checked) || (document.product_reviews_write.rating[3].checked) || (document.product_reviews_write.rating[4].checked)) {
  } else {
    error_message = error_message + "* You must rate the product.\n";
    error = 1;
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><form name="product_reviews_write" <? echo 'action="product_reviews_write_process.php?products_id=' . $HTTP_GET_VARS["products_id"] . '&' . SID . '"'; ?> method="post" onSubmit="return checkForm();"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
<?
  $product = $db_query("select manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_name from manufacturers, products_to_manufacturers, products where products.products_id = $HTTP_GET_VARS[products_id] and products_to_manufacturers.products_id = products.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id");
  $product_values = $db_fetch_array($product);

  if ($product_values["manufacturers_location"] == 0) {
    $products_name = $product_values["manufacturers_name"] . ' ' . $product_values["products_name"];
  } else {
    $products_name = $product_values["products_name"] . ' (' . $product_values["manufacturers_name"] . ')';
  }

  $customer = $db_query("select customers_firstname, customers_lastname from customers where customers_id = $customer_id");
  $customer_values = $db_fetch_array($customer);
?>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;<? echo $products_name; ?> Reviews&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Got Something To Say?&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_reviews.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><br><font face="Verdana, Arial" size="2"><b>&nbsp;From: </b><? echo $customer_values["customers_firstname"] . ' ' . $customer_values["customers_lastname"]; ?>&nbsp;</font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2"><b>&nbsp;Product: </b><? echo $products_name; ?>&nbsp;</font></td>
      </tr>
      <tr>
        <td><br><table witdh="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="top"><font face="Verdana, Arial" size="2"><b>&nbsp;Review:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><textarea name="review" wrap="soft" cols="60" rows="15"></textarea></font></td>
          </tr>
          <tr>
            <td align="right" colspan="2"><font face="Verdana, Arial" size="1">&nbsp;<font color="#FF0000">Note:</font>&nbsp;HTML is not translated&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2"><br><b>&nbsp;Rating:&nbsp;</b>&nbsp;bad&nbsp;<input type="radio" name="rating" value="1">&nbsp;<input type="radio" name="rating" value="2">&nbsp;<input type="radio" name="rating" value="3">&nbsp;<input type="radio" name="rating" value="4">&nbsp;<input type="radio" name="rating" value="5">&nbsp;good&nbsp;</font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><br><input type="image" src="images/button_insert.gif" width="70" height="24" border="0" alt=" Insert ">&nbsp;<?
    $reviews = $db_query("select count(*) as count from reviews_extra where products_id = $HTTP_GET_VARS[products_id]");
    $reviews_values = $db_fetch_array($reviews);
    if ($reviews_values["count"] == "0") {
      echo '<a href="product_info.php?' . $get_params_back . '">';
    } else {
      echo '<a href="product_reviews.php?' . $get_params_back . '">';
    } ?><img src="images/button_cancel.gif" width="72" height="24" border="0" alt=" Cancel "></a>&nbsp;</font></td>
      </tr>
    </table><input type="hidden" name="get_params" value="<? echo $get_params; ?>"></form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
