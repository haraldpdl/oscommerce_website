<?
  $newest_review = $db_query("select reviews.reviews_id, reviews.reviews_text, reviews.reviews_rating, reviews_extra.date_added, products.products_id, products.products_name, products.products_image, manufacturers.manufacturers_name, manufacturers.manufacturers_location, customers.customers_firstname, customers.customers_lastname from reviews, reviews_extra, products, manufacturers, products_to_manufacturers, customers where reviews.reviews_id = reviews_extra.reviews_id and reviews_extra.products_id = products.products_id and reviews_extra.customers_id = customers.customers_id and reviews_extra.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by reviews.reviews_id DESC limit 1");
  $newest_review_values = $db_fetch_array($newest_review);

  if ($newest_review_values["manufacturers_location"] == 0) {
    $products_name = $newest_review_values["manufacturers_name"] . ' ' . $newest_review_values["products_name"];
  } else {
    $products_name = $newest_review_values["products_name"] . ' (' . $newest_review_values["manufacturers_name"] . ')';
  }
?>
          <tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;<a href="reviews.php" class="blacklink">Reviews</a>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><div align="center"><? echo '<a href="product_reviews_info.php?products_id=' . $newest_review_values["products_id"] . '&reviews_id=' . $newest_review_values["reviews_id"] . '">'; ?><img src="<? echo $newest_review_values["products_image"]; ?>" width="100" height="80" border="0" alt="<? echo $products_name; ?>"></a></div><? echo '<a href="product_reviews_info.php?products_id=' . $newest_review_values["products_id"] . '&reviews_id=' . $newest_review_values["reviews_id"] . '">'; ?><? echo substr($newest_review_values["reviews_text"], 0, 60); ?> ..</a><br><div align="center"><img src="images/stars_<? echo $newest_review_values["reviews_rating"]; ?>.gif" width="59" height="12" border="0" alt=" <? echo $newest_review_values["reviews_rating"]; ?> of 5 Stars! "><br><a href="reviews.php">More reviews..</a></div></font></td>
          </tr>         
