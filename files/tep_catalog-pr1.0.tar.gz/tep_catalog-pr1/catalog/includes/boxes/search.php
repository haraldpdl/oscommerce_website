          <form name="quick_find" <? echo 'action="search.php?' . SID . '"'; ?> method="post"><tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;Quick Find&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><div align="center"><input type="text" name="query" size="10" maxlength="10"<? if ($HTTP_POST_VARS["query"]) { echo ' value="' . $HTTP_POST_VARS["query"] . '"'; } ?>>&nbsp;<input type="image" src="images/button_quick_find.gif" width="16" height="17" border="0" alt="Quick Find"></div>Use a single keyword to find what your looking for.</font></td>
          </tr></form>
