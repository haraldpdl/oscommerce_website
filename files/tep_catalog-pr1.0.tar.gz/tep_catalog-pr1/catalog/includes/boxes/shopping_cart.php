          <tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;<a href="shopping_cart.php" class="blacklink">Shopping Cart</a>&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><?
  if (session_is_registered("customer_id")) {
    $check_cart = $db_query("select customers_basket.products_id, customers_basket.customers_basket_quantity, products.products_model, products.products_price from customers_basket, products where customers_basket.customers_id = $customer_id and customers_basket.products_id = products.products_id");
    $total_cost = 0;
    if ($db_num_rows($check_cart)) {
      while ($check_cart_values = $db_fetch_array($check_cart)) {
        echo '<a href="product_info.php?products_id=' . $check_cart_values["products_id"] . '">' . $check_cart_values["customers_basket_quantity"] . 'x ' . $check_cart_values["products_model"] . '</a><br>';
        $price = $check_cart_values["products_price"];
        $check_special = $db_query("select specials_new_products_price from specials where products_id = " . $check_cart_values["products_id"]);
        if ($db_num_rows($check_special)) {
          $check_special_values = $db_fetch_array($check_special);
          $price = $check_special_values["specials_new_products_price"];
        }
        $total_cost = $total_cost + ($check_cart_values["customers_basket_quantity"] * $price);
      }
    } else {
      $cart_empty = 1;
      echo '..empty!';
    }
  } else {
    if (session_is_registered("nonsess_cart")) {
      $total_cost = 0;
      $product_in_cart = 0;
      $nonsess_cart_contents = explode("|", $nonsess_cart);
      for ($i=0;$i<sizeof($nonsess_cart_contents);$i++) {
        $product_info = explode(":", $nonsess_cart_contents[$i]);
        if (($product_info[0] != 0) && ($product_info[1] != 0)) {
          $product_in_cart = 1;
          $check_cart = $db_query("select products_model, products_price from products where products_id = " . $product_info[0]);
          $check_cart_values = $db_fetch_array($check_cart);
          $price = $check_cart_values["products_price"];
          echo '<a href="product_info.php?products_id=' . $product_info[0] . '">' . $product_info[1] . 'x ' . $check_cart_values["products_model"] . '</a><br>';
          $check_special = $db_query("select specials_new_products_price from specials where products_id = " . $product_info[0]);
          if ($db_num_rows($check_special)) {
            $check_special_values = $db_fetch_array($check_special);
            $price = $check_special_values["specials_new_products_price"];
          }
          $total_cost = $total_cost + ($product_info[1] * $price);
        }
      }
    }
    if ($product_in_cart == 0) {
      session_unregister("nonsess_cart");
    }
    if (!session_is_registered("nonsess_cart")) {
      $cart_empty = 1;
      echo '..empty!';
    }
  } ?></font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if (!$cart_empty == 1) {
?>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="1">Sub-Total: $<? echo number_format($total_cost,2); ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="1"><a href="shopping_cart.php">View All Contents</a></font></td>
          </tr>
<?
  }
?>