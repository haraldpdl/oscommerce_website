          <form name="quick_add" action="shopping_cart.php" method="get"><tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;Add a Quickie!&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="1"><div align="center"><input type="hidden" name="action" value="add_product"><input type="text" name="products_id" size="10">&nbsp;<input type="image" src="images/button_add_quick.gif" width="16" height="17" border="0" alt="Add a Quickie!"></div>Enter the ID of the product you wish to add to your shopping cart.</font><input type="hidden" name="<? echo session_name(); ?>" value="<? echo session_id(); ?>"></td>
          </tr></form>
