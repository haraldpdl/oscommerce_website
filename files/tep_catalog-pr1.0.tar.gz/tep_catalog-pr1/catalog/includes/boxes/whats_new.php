<?
    $whats_new_query = $db_query("select products.products_id, products.products_name, products.products_image, manufacturers.manufacturers_name, manufacturers.manufacturers_location from products, products_to_manufacturers, manufacturers where products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by products.products_date_added desc limit 10");
    $whats_new_num_rows = ($db_num_rows($whats_new_query) - 1);
    srand((double)microtime()*1000000);
    $whats_new_random = rand(0,$whats_new_num_rows);
    mysql_data_seek($whats_new_query, $whats_new_random);
    $whats_new_values = $db_fetch_array($whats_new_query);
?>
          <tr>
            <td bgcolor="#AABBDD" class="boxborder"><font face="Verdana, Arial" size="2">&nbsp;Whats New?&nbsp;</font></td>
          </tr>
          <tr>
            <td align="center"><font face="Verdana, Arial" size="1">
<?
  if ($whats_new_values["manufacturers_location"] == 0) {
    echo '<a href="product_info.php?products_id=' . $whats_new_values["products_id"] . '"><img src="' . $whats_new_values["products_image"] . '" width="100" height="80" border="0" alt="' . $whats_new_values["manufacturers_name"] . ' ' . $whats_new_values["products_name"] . '"></a><br><a href="product_info.php?products_id=' . $whats_new_values["products_id"] . '">' . $whats_new_values["manufacturers_name"] . ' ' . $whats_new_values["products_name"] . '</a></font></td>' . "\n";
  } else {
    echo '<a href="product_info.php?products_id=' . $whats_new_values["products_id"] . '"><img src="' . $whats_new_values["products_image"] . '" width="100" height="80" border="0" alt="' . $whats_new_values["products_name"] . ' (' . $whats_new_values["manufacturers_name"] . ')"></a><br><a href="product_info.php?products_id=' . $whats_new_values["products_id"] . '">' . $whats_new_values["products_name"] . ' (' . $whats_new_values["manufacturers_name"] . ')</a></font></td>' . "\n";
  }
?>
          </tr>
