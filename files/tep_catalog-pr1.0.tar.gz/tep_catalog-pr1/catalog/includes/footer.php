<? include("includes/counter.php"); ?>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor="#000000" height="19">
    <td align="left"><font face="Verdana, Arial" color="#FFFFFF" size="2"><b>&nbsp;&nbsp;<? echo date("l, jS F, Y"); ?></b></font></td>
    <td align="right"><font face="Verdana, Arial" color="#FFFFFF" size="2"><b><? echo $counter_now; ?> requests since <? echo $counter_startdate_formatted; ?>&nbsp;&nbsp;</b></font></td>
  </tr>
</table>
<br>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center"><font face="Verdana, Arial" size="1">&copy; 2000 <a href="http://theexchangeproject.org">The Exchange Project</a> : <a href="mailto:hap@theexchangeproject.org">Harald Ponce de Leon</a> @ <a href="http://www.xcom.de">XCOM AG - The Solution People</a></font></td>
  </tr>
</table>
