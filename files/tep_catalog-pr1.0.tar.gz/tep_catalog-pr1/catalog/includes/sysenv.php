<?
  session_start();
  
// define our database connection and query variables

  $db_server = "exchange";
  $db_server_user = "mysql";
  $db_server_user_password = "";
  $db_database = "catalog";
  
  $db_pconnect = "mysql_pconnect"; // yah, persistent connections..
  $db_select_db = "mysql_select_db";

  $db_query = "mysql_query";
  $db_fetch_row = "mysql_fetch_row";
  $db_fetch_array = "mysql_fetch_array";
  $db_num_rows = "mysql_num_rows";
  $db_insert_id = "mysql_insert_id";
  $db_free_result = "mysql_free_result";
  
  $db_link = $db_pconnect("$db_server","$db_server_user","$db_server_user_password");
  $db_select_db("$db_database", $db_link);

  $max_address_book_entries = 5;
  $search_rows = 30;
  $max_display_new_products_start = 6; // for main page, how many new products are shown
  $max_display_new_products = 9; // used when user has chosen a category, how many new products are shown
  $max_upcoming_products = 10;  // how many upcoming products should be displayed on the main page

  $SSLCheckout = 1; // SSL is enabled by default.. if you dont have an SSL server, disable it with the value of 0
?>
