<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr bgcolor="#AABBDD">
    <td align="left" valign="middle"><img src="images/header_exchange_logo.gif" width="57" height="50" border="0" alt="The Exchange Project"><img src="images/pixel_trans.gif" width="6" height="1" border="0" alt=""><img src="images/header_exchange.gif" width="351" height="50" border="0" alt="The Exchange Project"></td>
    <td align="right"><?
  if ($customer_id) {
    echo '<a href="account.php"><img src="images/header_account.gif" width="50" height="50" border="0" alt="My Account"></a>';
  } else {
    echo '<a href="create_account.php"><img src="images/header_account.gif" width="50" height="50" border="0" alt="Create an Account"></a>';
  } ?>&nbsp;&nbsp;<a href="shopping_cart.php"><img src="images/header_cart.gif" width="50" height="50" border="0" alt="Cart Contents"></a>&nbsp;&nbsp;<a href="checkout.php"><img src="images/header_checkout.gif" width="53" height="50" border="0" alt="Checkout"></a>&nbsp;&nbsp;</td>
  </tr>
  <tr bgcolor="#000000" height="19">
    <td align="left"><font face="Verdana, Arial" color="#FFFFFF" size="2"><b>&nbsp;&nbsp;<a href="../default.php" class="whitelink">Top</a> : <a href="default.php" class="whitelink">Catalog</a><?
  if ($HTTP_GET_VARS["category_id"]) {
    $category_top = $db_query("select category_top_name from category_top where category_top_id = $HTTP_GET_VARS[category_id]");
    $category_top_values = $db_fetch_array($category_top);
    echo ' : <a href="default.php?category_id=' . $HTTP_GET_VARS["category_id"] . '" class="whitelink">' . $category_top_values["category_top_name"] . '</a>';
  }
  if (($HTTP_GET_VARS["category_id"]) && ($HTTP_GET_VARS["index_id"])) {
    $category_index = $db_query("select category_index_name from category_index where category_index_id = $HTTP_GET_VARS[index_id]");
    $category_index_values = $db_fetch_array($category_index);
    echo ' : <a href="default.php?category_id=' . $HTTP_GET_VARS["category_id"] . '&index_id=' . $HTTP_GET_VARS["index_id"] . '" class="whitelink">' . $category_index_values["category_index_name"] . '</a>';
  }
  if (($HTTP_GET_VARS["category_id"]) && ($HTTP_GET_VARS["index_id"]) && ($HTTP_GET_VARS["subcategory_id"])) {
    $listby_query = $db_query("select sql_select from category_index where category_index_id = $HTTP_GET_VARS[index_id]");
    $listby_values = $db_fetch_array($listby_query);
    $listby = $listby_values["sql_select"];

    $subcategory = $db_query("select " . $listby . "_name as name from " . $listby . " where " . $listby . "_id = $HTTP_GET_VARS[subcategory_id]");
    $subcategory_values = $db_fetch_array($subcategory);
    echo ' : <a href="product_list.php?category_id=' . $HTTP_GET_VARS["category_id"] . '&index_id=' . $HTTP_GET_VARS["index_id"] . '&subcategory_id=' . $HTTP_GET_VARS["subcategory_id"] . '" class="whitelink">' . $subcategory_values["name"] . '</a>';
  }
  if ($HTTP_GET_VARS["products_id"]) {
    $model = $db_query("select products_model from products where products_id = $HTTP_GET_VARS[products_id]");
    $model_values = $db_fetch_array($model);

    echo ' : <a href="product_info.php?category_id=' . $HTTP_GET_VARS["category_id"] . '&index_id=' . $HTTP_GET_VARS["index_id"] . '&subcategory_id=' . $HTTP_GET_VARS["subcategory_id"] . '&products_id=' . $HTTP_GET_VARS["products_id"] . '" class="whitelink">' . $model_values["products_model"] . '</a>';
  }
  if ($page_location) {
    echo $page_location;
  }
  echo '</b></font></td>' . "\n";
?>
    <td align="right"><font face="Verdana, Arial" color="#FFFFFF" size="2"><b><?
  if (session_is_registered("customer_id")) {
    echo '<a href="logoff.php" class="whitelink">Log&nbsp;Off</a> &nbsp;|&nbsp; <a href="account.php" class="whitelink">My&nbsp;Account</a> &nbsp;|&nbsp; <a href="shopping_cart.php" class="whitelink">Cart&nbsp;Contents</a> &nbsp;|&nbsp; <a href="checkout.php" class="whitelink">Checkout</a>&nbsp;&nbsp;';
  } else {
    echo '<a href="login.php" class="whitelink">Log&nbsp;In</a> &nbsp;|&nbsp; <a href="create_account.php" class="whitelink">Create&nbsp;an&nbsp;Account</a> &nbsp;|&nbsp; <a href="shopping_cart.php" class="whitelink">Cart&nbsp;Contents</a> &nbsp;|&nbsp; <a href="checkout.php" class="whitelink">Checkout</a>&nbsp;&nbsp;';
  }
?></b></font></td>
  </tr>
</table>
