<? include("includes/sysenv.php"); ?>
<?  include("includes/counter.php"); ?>
<?
  $check_customer = $db_query("select customers_id from customers where customers_email_address = '$HTTP_POST_VARS[email_address]' and customers_password = '$HTTP_POST_VARS[password]'");
  if ($db_num_rows($check_customer)) {
    $check_customer_values = $db_fetch_array($check_customer);

    $customer_id = $check_customer_values["customers_id"];
    session_register("customer_id");
    
    if ($HTTP_POST_VARS["setcookie"] == 1) {
      setcookie("email_address",$HTTP_POST_VARS["email_address"],time()+2592000);
      setcookie("password",$HTTP_POST_VARS["password"],time()+2592000);
    } else {
      setcookie("email_address","");
      setcookie("password","");
    }    

    $date_now = date("Ymd");
    $db_query("update customers_info set customers_info_date_of_last_logon = '$date_now', customers_info_number_of_logons = customers_info_number_of_logons+1 where customers_info_id = $customer_id");

    if (session_is_registered("nonsess_cart")) { //transfer session cart to account cart
      $nonsess_cart_contents = explode("|", $nonsess_cart);
      for ($i=0;$i<sizeof($nonsess_cart_contents);$i++) {
        $product_info = explode(":", $nonsess_cart_contents[$i]);
        if (($product_info[0] != 0) && ($product_info[1] != 0)) {
          $product_in_cart = 1;
          $check_cart = $db_query("select customers_basket_quantity from customers_basket where customers_id = $customer_id and products_id = $product_info[0]");
          if ($db_num_rows($check_cart)) {
            $check_cart_values = $db_fetch_array($check_cart);
            $db_query("update customers_basket set customers_basket_quantity = customers_basket_quantity+$product_info[1] where customers_id = $customer_id and products_id = $product_info[0]");
          } else {
            $db_query("insert into customers_basket values ('', $customer_id, $product_info[0], $product_info[1], '$date_now')");
          }
        }
      }
      session_unregister("nonsess_cart");
    }

    if ($HTTP_POST_VARS["origin"]) {
      if ($HTTP_POST_VARS["products_id"]) {
        header("Location: " . $HTTP_POST_VARS["origin"] . ".php?products_id=" . $HTTP_POST_VARS["products_id"] . "&" . SID);
      } else {
        header("Location: " . $HTTP_POST_VARS["origin"] . ".php?" . SID);
      }
    } else {
      header("Location: default.php?" . SID);
    }
  } else {
    if ($HTTP_POST_VARS["origin"]) {
      if ($HTTP_POST_VARS["products_id"]) {
        header("Location: login.php?login=fail&origin=" . $HTTP_POST_VARS["origin"] . "&products_id=" . $HTTP_POST_VARS["products_id"] . "&" . SID);
      } else {
        header("Location: login.php?login=fail&origin=" . $HTTP_POST_VARS["origin"] . "&" . SID);
      }
    } else {
      header("Location: login.php?login=fail&" . SID);
    }
  }
?>
