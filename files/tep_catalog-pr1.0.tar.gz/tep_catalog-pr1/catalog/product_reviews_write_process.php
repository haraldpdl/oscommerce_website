<? include("includes/sysenv.php"); ?>
<?
  $date_now = date("Ymd");
  $db_query("insert into reviews values ('', '" . htmlspecialchars($HTTP_POST_VARS["review"]) . "', $HTTP_POST_VARS[rating])");
  $insert_id = $db_insert_id();
  $db_query("insert into reviews_extra values ($insert_id, $HTTP_GET_VARS[products_id], $customer_id, $date_now, 0)");
  
  header("Location: product_reviews.php?" . $HTTP_POST_VARS["get_params"] . "&" . SID);
?>