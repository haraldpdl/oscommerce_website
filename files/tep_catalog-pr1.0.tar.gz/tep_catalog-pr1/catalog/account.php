<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="account.php" class="whitelink">My Account</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
<?
  $account = $db_query("select customers_gender, customers_firstname, customers_lastname, customers_dob, customers_email_address, customers_street_address, customers_suburb, customers_postcode, customers_city, customers_state, customers_country, customers_telephone, customers_fax from customers where customers_id = $customer_id");
  $account_values = $db_fetch_array($account);
?>
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;My Account</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;My Account Information&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_account.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="100%"><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Personal ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Gender:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?
  if ($account_values["customers_gender"] == "m") {
    echo 'Male';
  } else {
    echo 'Female';
  } ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;First Name:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_firstname"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Last Name:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_lastname"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Date of Birth:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<?
  $dob_formatted = date("l, jS F, Y", mktime(0,0,0,substr($account_values["customers_dob"], 4, 2),substr($account_values["customers_dob"], -2),substr($account_values["customers_dob"], 0, 4)));
  echo $dob_formatted; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;E-Mail Address:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_email_address"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Address ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Street Address:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_street_address"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Suburb:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_suburb"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Post Code:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_postcode"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;City:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_city"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;State:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_state"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Country:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_country"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Contact ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Telephone No.:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_telephone"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Fax No.:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $account_values["customers_fax"]; ?>&nbsp;</font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="3"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Password ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;Password:&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;--HIDDEN--&nbsp;</small></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><a href="account_edit.php"><img src="images/button_edit_account.gif" width="124" height="24" border="0" alt=" Edit Account "></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="address_book.php"><img src="images/button_address_book.gif" width="130" height="24" border="0" alt=" Address Book "></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="account_history.php"><img src="images/button_history.gif" width="80" height="24" border="0" alt=" History "></a>&nbsp;</font></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
