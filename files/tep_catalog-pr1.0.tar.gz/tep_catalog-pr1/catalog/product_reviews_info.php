<? include("includes/sysenv.php"); ?>
<?
// lets retrieve all $HTTP_GET_VARS keys and values..
  $keys = array_keys($HTTP_GET_VARS);
  $values = array_values($HTTP_GET_VARS);

  $get_params = "";
  for ($i=0;$i<sizeof($keys);$i++) {
    if ($keys[$i] != "reviews_id") {
      $get_params.=$keys[$i] . '=' . $values[$i] . '&';
    }
  }
  $get_params = substr($get_params, 0, -1); //remove trailing &
?>
<? $page_location = ' : <a href="product_reviews.php?' . $get_params . '" class="whitelink">Reviews</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
<?
  $db_query("update reviews_extra set reviews_read = reviews_read+1 where reviews_id = $HTTP_GET_VARS[reviews_id]");

  $reviews = $db_query("select reviews.reviews_text, reviews.reviews_rating, reviews.reviews_id, reviews_extra.products_id, reviews_extra.customers_id, reviews_extra.date_added, reviews_extra.reviews_read from reviews, reviews_extra where reviews.reviews_id = $HTTP_GET_VARS[reviews_id] and reviews_extra.reviews_id = reviews.reviews_id");
  $reviews_values = $db_fetch_array($reviews);

  $product = $db_query("select manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_name from manufacturers, products_to_manufacturers, products where products.products_id = $reviews_values[products_id] and products_to_manufacturers.products_id = products.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id");
  $product_values = $db_fetch_array($product);

  if ($product_values["manufacturers_location"] == 0) {
    $products_name = $product_values["manufacturers_name"] . ' ' . $product_values["products_name"];
  } else {
    $products_name = $product_values["products_name"] . ' (' . $product_values["manufacturers_name"] . ')';
  }

  $customer = $db_query("select customers_firstname, customers_lastname from customers where customers_id = $reviews_values[customers_id]");
  $customer_values = $db_fetch_array($customer);
?>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Product Reviews&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;<? echo $products_name; ?> Reviews&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_reviews.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><br><font face="Verdana, Arial" size="2"><b>&nbsp;Product: </b><? echo $products_name; ?>&nbsp;</font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2"><b>&nbsp;From: </b><? echo $customer_values["customers_firstname"] . ' ' . $customer_values["customers_lastname"]; ?>&nbsp;</font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2"><b>&nbsp;Date: </b><? echo date("l, jS F, Y", mktime(0,0,0,substr($reviews_values["date_added"], 4, 2),substr($reviews_values["date_added"], -2),substr($reviews_values["date_added"], 0, 4))); ?>&nbsp;</font></td>
      </tr>
      <tr>
        <td><br><table witdh="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="top"><font face="Verdana, Arial" size="2"><b>&nbsp;Review:&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><? echo nl2br($reviews_values["reviews_text"]); ?></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2"><br><b>&nbsp;Rating:&nbsp;</b>&nbsp;<img src="images/stars_<? echo $reviews_values["reviews_rating"]; ?>.gif" width="59" height="11" border="0" alt="<? echo $reviews_values["reviews_rating"]; ?> of 5 Stars">&nbsp;&nbsp;<small>[<? echo $reviews_values["reviews_rating"]; ?> of 5 Stars]</small>&nbsp;</font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><br><? echo '<a href="product_reviews_write.php?' . $get_params . '">'; ?><img src="images/button_write_a_review.gif" width="140" height="24" border="0" alt=" Write a Review "></a>&nbsp;&nbsp;&nbsp;&nbsp;<? echo '<a href="product_reviews.php?' . $get_params . '">'; ?><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
