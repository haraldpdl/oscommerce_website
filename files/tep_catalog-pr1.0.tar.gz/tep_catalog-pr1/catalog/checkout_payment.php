<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="checkout.php" class="whitelink">Checkout</a> : Payment Method'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script language="javascript"><!--
function check_form() {
  var error = 0;
  var error_message = "Errors have occured during the process of your form!\nPlease make the following corrections:\n\n";

  var cc_owner = document.payment.cc_owner.value;
  var cc_number = document.payment.cc_number.value;
  var cc_expires = document.payment.cc_expires.value;

  if (document.payment.payment[1].checked) {
    if (cc_owner = "" || cc_owner.length < 3) {
      error_message = error_message + "* The credit card owners name must be atleast 3 characters.\n";
      error = 1;
    }

    if (cc_number = "" || cc_number.length < 10) {
      error_message = error_message + "* The credit card number must be atleast 10 characters.\n";
      error = 1;
    }

    if (cc_expires = "" || cc_expires.length < 4) {
      error_message = error_message + "* The credit card expiry date name must be atleast 4 characters.\n";
      error = 1;
    }
  }

  if (error == 1) {
    alert(error_message);
    return false;
  } else {
    return true;
  }
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><form name="payment" <? echo 'action="checkout_confirmation.php?' . SID . '"'; ?> method="post" onsubmit="return check_form();"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Checkout Procedure&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Payment Method&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_payment.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td><font face="Verdana, Arial" size="2"><b>&nbsp;Methods&nbsp;</b></font></td>
                <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Selection&nbsp;</b></font></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td><font face="Verdana, Arial" size="2">&nbsp;Cash on Delivery&nbsp;</font></td>
                <td align="right"><font face="Verdana, Arial" size="2">&nbsp;<input type="radio" name="payment" value="cod" CHECKED>&nbsp;</font></td>
              </tr>
              <tr>
                <td><br><font face="Verdana, Arial" size="2">&nbsp;Credit Card&nbsp;</font></td>
                <td align="right"><br><font face="Verdana, Arial" size="2">&nbsp;<input type="radio" name="payment" value="cc">&nbsp;</font></td>
              </tr>
              <tr>
                <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
              </tr>
              <tr>
                <td colspan="2"><table border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;Credit Card Type:&nbsp;</font></td>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<select name="cc_type"><option value="Visa">Visa</option><option value="Mastercard">Mastercard</option><option name="American Express">American Express</option></select>&nbsp;</font></td>
                  </tr>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;Credit Card Owner:&nbsp;</font></td>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<input type="text" name="cc_owner">&nbsp;</font></td>
                  </tr>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;Credit Card Number:&nbsp;</font></td>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<input type="text" name="cc_number">&nbsp;</font></td>
                  </tr>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;Credit Card Expiry Date:&nbsp;</font></td>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<input type="text" name="cc_expires">&nbsp;</font></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;<input type="image" src="images/button_next.gif" width="50" height="24" border="0" alt=" Next ">&nbsp;</font></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="1" color="#AABBDD">&nbsp;[ cart contents | delivery address | <font color="#000000">payment method</font> | confirmation | finished! ]&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
    </table><input type="hidden" name="sendto" value="<? echo $HTTP_POST_VARS["sendto"]; ?>"></form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
