<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="account.php" class="whitelink">My Account</a> : <a href="address_book.php" class="whitelink">Address Book</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Address Book Entries&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;My Personal Address Book&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_address_book.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;No.&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Name&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;City / Country&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $address_book = $db_query("select address_book.address_book_id, address_book.entry_firstname, address_book.entry_lastname, address_book.entry_city, address_book.entry_country from address_book, address_book_to_customers where address_book_to_customers.customers_id = $customer_id and address_book_to_customers.address_book_id = address_book.address_book_id order by address_book.address_book_id");
  if (!$db_num_rows($address_book)) {
?>
          <tr bgcolor="#f4f7fd">
            <td colspan="3"><font face="Verdana, Arial" size="2">&nbsp;Your Address Book has currently no entries!&nbsp;</font></td>
          </tr>
<?
  } else {
    $row = 0;
    while ($address_book_values = $db_fetch_array($address_book)) {
      $row++;
      if (($row / 2) == floor($row / 2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;0' . $row . '.&nbsp;</font></td>' . "\n";
      echo '            <td><font face="Verdana, Arial" size="1">&nbsp;<a href="address_book_modify.php?entry_id=' . $address_book_values["address_book_id"] . '">' . $address_book_values["entry_firstname"] . ' ' . $address_book_values["entry_lastname"] . '</a>&nbsp;</font></td>' . "\n";
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_city"] . ' / ' . $address_book_values["entry_country"] . '&nbsp;</font></td>' . "\n";
      echo '          </tr>' . "\n";
    }
  }
?>
          <tr>
            <td colspan="3"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if ($row < $max_address_book_entries) {
?>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;<small><b>NOTE:</b> A maximum of <? echo $max_address_book_entries; ?> address book entries allowed.</small>&nbsp;</font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><br>&nbsp;<a href="address_book_add.php"><img src="images/button_add_entry.gif" width="113" height="24" border="0" alt=" Add Entry "></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="account.php"><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
          </tr>
<?
  } else {
?>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;<small><b>NOTE:</b> Maximum of <? echo $max_address_book_entries; ?> address book entries reached.</small>&nbsp;</font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><br>&nbsp;<a href="account.php"><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
          </tr>
<?
  }
?>
        </table></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
