<? include("includes/sysenv.php"); ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
<?
  if (!$HTTP_GET_VARS["category_id"]) {
    $category = $db_query("select subcategories_to_category.category_top_id from subcategories_to_category, products_to_subcategories where products_to_subcategories.products_id = $HTTP_GET_VARS[products_id] and products_to_subcategories.subcategories_id = subcategories_to_category.subcategories_id");
    $category_values = $db_fetch_array($category);
    $category_id = $category_values["category_top_id"];
  } else {
    $category_id = $HTTP_GET_VARS["category_id"];
  }
?>
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Product Information&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
<?
  $product_info = $db_query("select manufacturers.manufacturers_name, manufacturers.manufacturers_location, manufacturers.manufacturers_image, products.products_id, products.products_name, products.products_description, products.products_model, products.products_quantity, products.products_image, products.products_url, products.products_price, products.products_date_added from manufacturers, products_to_manufacturers, products where products.products_id = $HTTP_GET_VARS[products_id] and products_to_manufacturers.products_id = $HTTP_GET_VARS[products_id] and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id");
  if (!$db_num_rows($product_info)) { // product not found in database
?>
      <tr>
        <td><br><font face="Verdana, Arial" size="2">&nbsp;Product not found!&nbsp;</font></td>
      </tr>
      <tr>
        <td><br><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td align="right"><br><img src="images/button_main_menu.gif" width="112" height="24" border="0" alt=" Main Menu "></td>
      </tr>
<?
  } else {
    $db_query("update products set products_viewed = products_viewed+1 where products_id = $HTTP_GET_VARS[products_id]");
    $product_info_values = $db_fetch_array($product_info);
    $raw_date_added = $product_info_values["products_date_added"];
    $date_added = date("l, jS F, Y", mktime(0,0,0,substr($raw_date_added, 4, 2),substr($raw_date_added, -2),substr($raw_date_added, 0, 4)));

    $check_special = $db_query("select specials.specials_new_products_price from specials where products_id = $product_info_values[products_id]");
    if ($db_num_rows($check_special)) {
      $check_special_values = $db_fetch_array($check_special);
      $new_price = $check_special_values["specials_new_products_price"];
    }
    if ($product_info_values["manufacturers_location"] == 0) {
      $products_name = $product_info_values["manufacturers_name"] . ' ' . $product_info_values["products_name"];
    } else {
      $products_name = $product_info_values["products_name"] . ' (' . $product_info_values["manufacturers_name"] . ')';
    }
    if ($new_price) {
      $products_price = '<s>$' . $product_info_values["products_price"] . '</s>&nbsp;&nbsp;<font color="#FF0000">$' . $new_price . '</font>';
    } else {
       $products_price = ' $' . $product_info_values["products_price"];
    }
?>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;<? echo $products_name . ' @ ' . $products_price; ?>&nbsp;</font></td>
            <td align="right">&nbsp;<img src="<? echo $product_info_values["manufacturers_image"]; ?>" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
      <tr>
<?
    echo '        <td><font face="Verdana, Arial" size="2"><img src="' . $product_info_values["products_image"] . '" border="0" alt="';
    if ($product_info_values["manufacturers_location"] == 0) {
      echo $product_info_values["manufacturers_name"] . ' ' . $product_info_values["products_name"];
    } else {
      echo $product_info_values["products_name"] . ' (' . $product_info_values["manufacturers_name"] . ')';
    }
    echo '" align="right" width="100" hieght="80" hspace="5" vspace="5">' . $product_info_values["products_description"] . '</font></td>' . "\n";
?>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
<?
    $reviews = $db_query("select count(*) as count from reviews_extra where products_id = $HTTP_GET_VARS[products_id]");
    $reviews_values = $db_fetch_array($reviews);
?>
      <tr>
        <td><font face="Verdana, Arial" size="2">Current Reviews: <? echo $reviews_values["count"]; ?><br>&nbsp;</font></td>
      </tr>
<?
    if ($product_info_values["products_url"]) {
?>
      <tr>
        <td><font face="Verdana, Arial" size="2">For more information, please visit this products <a href="http://<? echo $product_info_values["products_url"]; ?>" target="_blank"><u>internet address</u></a>.<br>&nbsp;</font></td>
      </tr>
<?
    }
?>
      <tr>
        <td align="center"><font face="Verdana, Arial" size="2"><small>This product was added to our catalog on <? echo $date_added; ?>.</small></font></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
      <tr>
        <td width="100%"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="1">&nbsp;</font></td>
      </tr>
<?
    if (session_is_registered("customer_id")) {
      $check_products = $db_query("select customers_basket_quantity from customers_basket where customers_id = $customer_id and products_id = $HTTP_GET_VARS[products_id]");
      if ($db_num_rows($check_products)) {
        $check_products_values = $db_fetch_array($check_products);
        $product_exists_in_cart = 1;
        $product_quantity_in_cart = $check_products_values["customers_basket_quantity"];
      } else {
        $product_exists_in_cart = 0;
      }
    } elseif (session_is_registered("nonsess_cart")) {
      $nonsess_cart_contents = explode("|", $nonsess_cart);
      for ($i=0;$i<sizeof($nonsess_cart_contents);$i++) {
        $product_info = explode(":", $nonsess_cart_contents[$i]);
        if ($product_info[0] == $HTTP_GET_VARS[products_id]) {
          $product_exists_in_cart = 1;
          $product_quantity_in_cart = $product_info[1];
        }
      }
    }
?>
      <tr>
<?      
// lets retrieve all $HTTP_GET_VARS keys and values..
    $keys = array_keys($HTTP_GET_VARS);
    $values = array_values($HTTP_GET_VARS);

    $get_params = "";
    $get_params_back = ""; // this one is for the back button (needs to remove the last GET parameter (products_id))
    for ($i=0;$i<sizeof($keys);$i++) {
      $get_params.=$keys[$i] . '=' . $values[$i] . '&';
      if (($i + 1) != sizeof($keys)) {
        $get_params_back.=$keys[$i] . '=' . $values[$i] . '&';
      }
    }
    $get_params = substr($get_params, 0, -1); //remove trailing &
    $get_params_back = substr($get_params_back, 0, -1); //remove trailing &
    if ($product_exists_in_cart == 1) {
?>
        <td><form name="cart_quantity" <? echo 'action="shopping_cart.php?action=update_quantity&' . SID . '"'; ?> method="post"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
<?
  if ($reviews_values["count"] == "0") {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;<a href="product_reviews_write.php?' . $get_params . '"><img src="images/button_write_a_review.gif" width="140" height="24" border="0" alt=" Write a Review "></a>&nbsp;</font></td>' . "\n";
  } else {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;<a href="product_reviews.php?' . $get_params . '"><img src="images/button_reviews.gif" width="78" height="24" border="0" alt=" Reviews "></a>&nbsp;</font></td>' . "\n";
  }
?>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;<input type="text" name="cart_quantity" value="<? echo $product_quantity_in_cart; ?>" maxlength="2" size="2">&nbsp;&nbsp;<input type="hidden" name="products_id" value="<? echo $product_info_values["products_id"]; ?>"><input type="image" src="images/button_update_cart.gif" width="116" height="24" border="0" alt=" Update Cart ">&nbsp;&nbsp;&nbsp;&nbsp;<? echo '<a href="shopping_cart.php?action=remove_product&products_id=' . $product_info_values["products_id"] . '">'; ?><img src="images/button_remove_all.gif" width="113" height="24" border="0" alt=" Remove All "></a>&nbsp;</font></td>
          </td>
        </table></form></td>
<?
    } else {
?>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
<?
  if ($reviews_values["count"] == "0") {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;<a href="product_reviews_write.php?' . $get_params . '"><img src="images/button_write_a_review.gif" width="140" height="24" border="0" alt=" Write a Review "></a>&nbsp;</font></td>' . "\n";
  } else {
    echo '            <td><font face="Verdana, Arial" size="2">&nbsp;<a href="product_reviews.php?' . $get_params . '"><img src="images/button_reviews.gif" width="78" height="24" border="0" alt=" Reviews "></a>&nbsp;</font></td>' . "\n";
  }
?>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;<? echo '<a href="shopping_cart.php?action=add_product&products_id=' . $product_info_values["products_id"] . '">'; ?><img src="images/button_add_to_cart.gif" width="117" height="24" border="0" alt=" Add to Cart "></a><? if ($get_params_back != "") { echo '&nbsp;&nbsp;&nbsp;&nbsp;<a href="product_list.php?' . $get_params_back . '">'; ?><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a> <? } ?>&nbsp;</font></td>
          </tr>
        </table></td>
<?
    }
?>
      </tr>
<?
  }
?>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
