<? include("includes/sysenv.php"); ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Our&nbsp;Online&nbsp;Products&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Let See What We've Got Here&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_list.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Products&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Price&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="2"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $listby_query = $db_query("select sql_select from category_index where category_index_id = $HTTP_GET_VARS[index_id]");
  $listby_values = $db_fetch_array($listby_query);
  $listby = $listby_values["sql_select"];

// we need to look for the sort location of manufacturers_name<>products_name - this method is not the best but it works for now ;)
  $sort_location = $db_query("select manufacturers.manufacturers_location from products, manufacturers, products_to_manufacturers, products_to_subcategories where products_to_" . $listby . "." . $listby . "_id = $HTTP_GET_VARS[subcategory_id] and products_to_subcategories.products_id = products.products_id and products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by manufacturers.manufacturers_name, products.products_name");
  $sort_location_values = $db_fetch_array($sort_location);
  if ($sort_location_values["manufacturers_location"] == 0) { // the location of manufacturers name is to the left of the products name
    $listing = $db_query("select products.products_id, products.products_name, manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_price from products, manufacturers, products_to_manufacturers, products_to_subcategories where products_to_" . $listby . "." . $listby . "_id = $HTTP_GET_VARS[subcategory_id] and products_to_subcategories.products_id = products.products_id and products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by manufacturers.manufacturers_name, products.products_name");
  } else { // its to the right..
    $listing = $db_query("select products.products_id, products.products_name, manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_price from products, manufacturers, products_to_manufacturers, products_to_subcategories where products_to_" . $listby . "." . $listby . "_id = $HTTP_GET_VARS[subcategory_id] and products_to_subcategories.products_id = products.products_id and products.products_id = products_to_manufacturers.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id order by products.products_name, manufacturers.manufacturers_name");
  }
  $db_free_result($sort_location); // lets free the result from memory..
  $number_of_products = 0;
  if (!$db_num_rows($listing)) {
?>
          <tr bgcolor="#f4f7fd">
            <td colspan="2"><font face="Verdana, Arial" size="1">&nbsp;There are currently no products to list in this category.</font></td>
          </tr>
<?
  } else {
    while ($listing_values = $db_fetch_array($listing)) {
      $number_of_products++;
      if (($number_of_products / 2) == floor($number_of_products / 2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
?>
            <td><font face="Verdana, Arial" size="1"><? echo '<a href="product_info.php?category_id=' . $HTTP_GET_VARS["category_id"] . '&index_id=' . $HTTP_GET_VARS["index_id"] . '&subcategory_id=' . $HTTP_GET_VARS["subcategory_id"] . '&products_id=' . $listing_values["products_id"] . '">'; ?>
<?
      if ($listing_values["manufacturers_location"] == 0) {
        echo $listing_values["manufacturers_name"] . ' ' . $listing_values["products_name"];
      } else {
        echo $listing_values["products_name"] . ' (' . $listing_values["manufacturers_name"] . ')';
      }
?></a></font></td>
<?
      $check_special = $db_query("select specials.specials_new_products_price from specials where products_id = $listing_values[products_id]");
      if ($db_num_rows($check_special)) {
        $check_special_values = $db_fetch_array($check_special);
        $new_price = $check_special_values["specials_new_products_price"];
      }
?>
            <td align="right"><font face="Verdana, Arial" size="1">&nbsp;<?
      if ($new_price) {
        echo '<s>$' .  $listing_values["products_price"] . '</s>&nbsp;&nbsp;<font color="#FF0000">$' . $new_price . '</font>';
        unset($new_price);
      } else {
        echo '$' . $listing_values["products_price"];
      } ?></font></td>
          </tr>
<?
    }
  }
?>
        </td></table>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="1">Number of Products: <? echo $number_of_products; ?>&nbsp;&nbsp;</font></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
