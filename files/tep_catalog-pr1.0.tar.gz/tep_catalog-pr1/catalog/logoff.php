<? include("includes/sysenv.php"); ?>
<?
  session_destroy();
  include("includes/counter.php");
  header("Location: default.php?" . SID);
?>