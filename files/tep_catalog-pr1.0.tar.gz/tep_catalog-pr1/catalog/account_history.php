<? include("includes/sysenv.php"); ?>
<? $page_location = ' : <a href="account.php" class="whitelink">My Account</a> : <a href="account_history.php" class="whitelink">History</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Account History&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;My Purchase History&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_history.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Order No.&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;Order Date&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Order Quantity&nbsp;</b></font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Order Cost&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $history = $db_query("select orders_id, date_purchased, products_tax from orders where customers_id = $customer_id order by orders_id DESC");
  if (!$db_num_rows($history)) {
?>
          <tr bgcolor="#f4f7fd">
            <td colspan="4"><font face="Verdana, Arial" size="2">&nbsp;You have not yet purchased with us online..&nbsp;</font></td>
          </tr>
<?
  } else {
    $row = 0;
    while ($history_values = $db_fetch_array($history)) {
      $total_cost = 0;
      $total_quantity = 0;
      $row++;
      $history_total = $db_query("select products_price, products_quantity from orders_products where orders_id = $history_values[orders_id]");
      while ($history_total_values = $db_fetch_array($history_total)) {
        $total_cost = $total_cost + ($history_total_values["products_price"] * $history_total_values["products_quantity"]);
        $total_quantity = $total_quantity + $history_total_values["products_quantity"];
      }
      $total_cost = ($total_cost + ($total_cost * (16/100)));
      $history_date = date("l, dS F, Y", mktime(0,0,0,substr($history_values["date_purchased"], 4, 2),substr($history_values["date_purchased"], -2),substr($history_values["date_purchased"], 0, 4)));
      if (($row / 2) == floor($row / 2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
      if (strlen($row) == 1) {
        $row = '0' . $row;
      }
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;' . $row . '.&nbsp;</font></td>' . "\n";
      echo '            <td><font face="Verdana, Arial" size="1">&nbsp;<a href="account_history_info.php?order_id=' . $history_values["orders_id"] . '">' . $history_date . '</a>&nbsp;</font></td>' . "\n";
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;' . $total_quantity . '&nbsp;</font></td>' . "\n";
      echo '            <td align="right"><font face="Verdana, Arial" size="1">&nbsp;$' . number_format($total_cost, 2) . '&nbsp;</font></td>' . "\n";
      echo '          </tr>' . "\n";
    }
  }
?>
          <tr>
            <td colspan="4"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td colspan="3"><font face="Verdana, Arial" size="2">&nbsp;<small>Click on the 'Order Date' to view the order information</small>&nbsp;</font></td>
            <td align="right"><font face="Verdana, Arial" size="2"><br>&nbsp;<a href="account.php"><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
