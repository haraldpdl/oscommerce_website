<? include("includes/sysenv.php"); ?>
<?
// lets retrieve all $HTTP_GET_VARS keys and values..
  $keys = array_keys($HTTP_GET_VARS);
  $values = array_values($HTTP_GET_VARS);

  $get_params = "";
  $get_params_back = ""; // for back button
  for ($i=0;$i<sizeof($keys);$i++) {
    $get_params.=$keys[$i] . '=' . $values[$i] . '&';
    if ($keys[$i] != "reviews_id") {
      $get_params_back.=$keys[$i] . '=' . $values[$i] . '&';
    }
  }
  $get_params = substr($get_params, 0, -1); //remove trailing &
  if ($get_params_back != "") {
    $get_params_back = substr($get_params_back, 0, -1); //remove trailing &
  } else {
    $get_params_back = $get_params;
  }
?>
<? $page_location = ' : <a href="product_reviews.php?' . $get_params . '" class="whitelink">Reviews</a>'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
<?
  $product = $db_query("select manufacturers.manufacturers_name, manufacturers.manufacturers_location, products.products_name from manufacturers, products_to_manufacturers, products where products.products_id = $HTTP_GET_VARS[products_id] and products_to_manufacturers.products_id = products.products_id and products_to_manufacturers.manufacturers_id = manufacturers.manufacturers_id");
  $product_values = $db_fetch_array($product);

  if ($product_values["manufacturers_location"] == 0) {
    $products_name = $product_values["manufacturers_name"] . ' ' . $product_values["products_name"];
  } else {
    $products_name = $product_values["products_name"] . ' (' . $product_values["manufacturers_name"] . ')';
  }
?>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Product Reviews&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;<? echo $products_name; ?> Reviews&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_reviews.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;No.&nbsp;</b></font></td>
            <td><font face="Verdana, Arial" size="2"><b>&nbsp;From&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Date Added&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Their Rating&nbsp;</b></font></td>
            <td align="center"><font face="Verdana, Arial" size="2"><b>&nbsp;Times Read&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $reviews = $db_query("select reviews.reviews_rating, reviews.reviews_id, reviews_extra.customers_id, reviews_extra.date_added, reviews_extra.reviews_read from reviews, reviews_extra where reviews_extra.products_id = $HTTP_GET_VARS[products_id] and reviews_extra.reviews_id = reviews.reviews_id order by reviews.reviews_id DESC");
  if (!$db_num_rows($reviews)) {
?>
          <tr bgcolor="#f4f7fd">
            <td colspan="5"><font face="Verdana, Arial" size="1">&nbsp;No reviews have been curently written for this product!&nbsp;</font></td>
          </tr>
<?
  } else {
    $row = 0;
    while ($reviews_values = $db_fetch_array($reviews)) {
      $customers_name = $db_query("select customers_firstname, customers_lastname from customers where customers_id = $reviews_values[customers_id]");
      $customers_name_values = $db_fetch_array($customers_name);
      $row++;
      if (strlen($row) < 2) {
        $row = "0" . $row;
      }
      $date_added = substr($reviews_values["date_added"], -2) . '/' . substr($reviews_values["date_added"], 4, 2) . '/' . substr($reviews_values["date_added"], 0, 4);
      if (($row / 2) == floor($row / 2)) {
        echo '          <tr bgcolor="#ffffff">' . "\n";
      } else {
        echo '          <tr bgcolor="#f4f7fd">' . "\n";
      }
      echo '            <td><font face="Verdana, Arial" size="1">&nbsp;' . $row . '.&nbsp;</font></td>' . "\n";
      echo '            <td><font face="Verdana, Arial" size="1">&nbsp;<a href="product_reviews_info.php?' . $get_params . '&reviews_id=' . $reviews_values["reviews_id"] . '">' . $customers_name_values["customers_firstname"] . ' ' . $customers_name_values["customers_lastname"] . '</a>&nbsp;</font></td>' . "\n";
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;' . $date_added . '&nbsp;</font></td>' . "\n";
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;<img src="images/stars_' . $reviews_values["reviews_rating"] . '.gif" width="59" height="11" border="0" alt="' . $reviews_values["reviews_rating"] . ' Stars">&nbsp;</font></td>' . "\n";
      echo '            <td align="center"><font face="Verdana, Arial" size="1">&nbsp;' . $reviews_values["reviews_read"] . '&nbsp;</font></td>' . "\n";
      echo '          </tr>' . "\n";
    }
  }
?>
          <tr>
            <td colspan="5"><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td align="right" colspan="5"><font face="Verdana, Arial" size="2"><br>&nbsp;<? echo '<a href="product_reviews_write.php?' . $get_params . '">'; ?><img src="images/button_write_a_review.gif" width="140" height="24" border="0" alt=" Write a Review "></a>&nbsp;&nbsp;&nbsp;&nbsp;<? echo '<a href="product_info.php?' . $get_params_back . '">'; ?><img src="images/button_back.gif" width="58" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
