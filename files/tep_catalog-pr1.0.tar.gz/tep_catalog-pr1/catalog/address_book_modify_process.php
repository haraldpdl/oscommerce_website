<? include("includes/sysenv.php"); ?>
<?
  if ($HTTP_GET_VARS["action"]) {
    if ($HTTP_GET_VARS["action"] == "remove_entry") {
      $db_query("delete from address_book where address_book_id = $HTTP_GET_VARS[entry_id]");
      $db_query("delete from address_book_to_customers where address_book_id = $HTTP_GET_VARS[entry_id]");
    }
  } else {
    $db_query("update address_book set entry_gender = '$HTTP_POST_VARS[gender]', entry_firstname = '$HTTP_POST_VARS[firstname]', entry_lastname = '$HTTP_POST_VARS[lastname]', entry_street_address = '$HTTP_POST_VARS[street_address]', entry_suburb = '$HTTP_POST_VARS[suburb]', entry_postcode = '$HTTP_POST_VARS[postcode]', entry_city = '$HTTP_POST_VARS[city]', entry_state = '$HTTP_POST_VARS[state]', entry_country = '$HTTP_POST_VARS[country]' where address_book_id = $HTTP_GET_VARS[entry_id]");
  }
  header("Location: address_book.php?" . SID);
?> 