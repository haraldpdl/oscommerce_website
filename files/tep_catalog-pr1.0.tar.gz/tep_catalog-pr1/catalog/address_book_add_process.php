<? include("includes/sysenv.php"); ?>
<?
  if (($HTTP_POST_VARS["gender"] == "m") || ($HTTP_POST_VARS["gender"] == "f")) {
    $gender_error = 0;
  } else {
    $gender_error = 1;
  }

  if (strlen(trim($HTTP_POST_VARS["firstname"])) < 3) {
    $firstname_error = 1;
  } else {
    $firstname_error = 0;
  }

  if (strlen(trim($HTTP_POST_VARS["lastname"])) < 3) {
    $lastname_error = 1;
  } else {
    $lasttname_error = 0;
  }

  if (strlen(trim($HTTP_POST_VARS["street_address"])) < 5) {
    $street_address_error = 1;
  } else {
    $street_address_error = 0;
  }

  if (strlen(trim($HTTP_POST_VARS["postcode"])) < 4) {
    $postcode_error = 1;
  } else {
    $postcode_error = 0;
  }

  if (strlen(trim($HTTP_POST_VARS["city"])) < 4) {
    $city_error = 1;
  } else {
    $city_error = 0;
  }

  if (strlen(trim($HTTP_POST_VARS["country"])) < 3) {
    $country_error = 1;
  } else {
    $country_error = 0;
  }

  if (($gender_error == 1) || ($firstname_error == 1) || ($lastname_error == 1) || ($street_address_error == 1) || ($postcode_error == 1) || ($city_error == 1) || ($country_error == 1)) {
?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><form name="create_account" method="post" <? echo 'action="address_book_add_process.php?' . SID . '"'; ?>><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Address Book Entries</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;New Address Book Entry&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_address_book.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td width="100%"><br><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="6"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Personal ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Gender:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($gender_error == 1) {
      echo '<input type="radio" name="gender" value="m">&nbsp;&nbsp;Male&nbsp;&nbsp;<input type="radio" name="gender" value="m">&nbsp;&nbsp;Female&nbsp;&nbsp;<small><font color="#AABBDD">required</font></small>';
    } else {
      if ($HTTP_POST_VARS["gender"] == "m") {
        echo 'Male<input type="hidden" name="gender" value="m">';
      } elseif ($HTTP_POST_VARS["gender"] == "f") {
        echo 'Female<input type="hidden" name="gender" value="f">';
      }
    } ?></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;First Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($firstname_error == 1) {            
      echo '<input type="text" name="firstname" maxlength="32" value="' . $HTTP_POST_VARS["firstname"] . '">&nbsp;&nbsp;<small><font color="#FF0000">min 3 chars</font></small>';
    } else {
      echo $HTTP_POST_VARS["firstname"] . '<input type="hidden" name="firstname" value="' . $HTTP_POST_VARS["firstname"] . '">';
    } ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Last Name:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($lastname_error == 1) {
      echo '<input type="text" name="lastname" maxlength="32" value="' . $HTTP_POST_VARS["lastname"] . '">&nbsp;&nbsp;<small><font color="#FF0000">min 3 chars</font></small>';
    } else {
      echo $HTTP_POST_VARS["lastname"] . '<input type="hidden" name="lastname" value="' . $HTTP_POST_VARS["lastname"] . '">';
    } ?></font></td>
          </tr>
          <tr>
            <td colspan="2"><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right" valign="middle" colspan="2" rowspan="7"><font face="Verdana, Arial" size="2" color="#AABBDD"><b>[ Address ]</b></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Street Address:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($street_address_error == 1) {
      echo '<input type="text" name="street_address" maxlength="64" value="' . $HTTP_POST_VARS["street_address"] . '">&nbsp;&nbsp;<small><font color="#FF0000">min 5 chars</font></small>';
    } else {
      echo $HTTP_POST_VARS["street_address"] . '<input type="hidden" name="street_address" value="' . $HTTP_POST_VARS["street_address"] . '">';
    } ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Suburb:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    echo $HTTP_POST_VARS["suburb"] . '<input type="hidden" name="suburb" value="' . $HTTP_POST_VARS["suburb"] . '">&nbsp;&nbsp;'; ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Post Code:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($postcode_error == 1) {
      echo '<input type="text" name="postcode" maxlength="8" value="' . $HTTP_POST_VARS["postcode"] . '">&nbsp;&nbsp;<small><font color="#FF0000">min 4 chars</font></small>';
    } else {
      echo $HTTP_POST_VARS["postcode"] . '<input type="hidden" name="postcode" value="' . $HTTP_POST_VARS["postcode"] . '">';
    } ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;City:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($city_error == 1) {
      echo '<input type="text" name="city" maxlength="32" value="' . $HTTP_POST_VARS["city"] . '">&nbsp;&nbsp;<small><font color="#FF0000">min 4 chars</font></small>';
    } else {
      echo $HTTP_POST_VARS["city"] . '<input type="hidden" name="city" value ="' . $HTTP_POST_VARS["city"] . '">';
    } ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;State:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    echo $HTTP_POST_VARS["state"] . '<input type="hidden" name="state" value="' . $HTTP_POST_VARS["state"] . '">&nbsp;&nbsp;'; ?></font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="2">&nbsp;&nbsp;Country:&nbsp;&nbsp;</font></td>
            <td><font face="Verdana, Arial" size="2">&nbsp;&nbsp;<?
    if ($country_error == 1) {
      echo '<input type="text" name="country" maxlength="32" value="' . $HTTP_POST_VARS["country"] . '">&nbsp;&nbsp;<small><font color="#FF0000">min 3 chars</font></small>';
    } else {
      echo $HTTP_POST_VARS["country"] . '<input type="hidden" name="country" value="' . $HTTP_POST_VARS["country"] . '">';
    } ?></font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
      </tr>
      <tr>
        <td align="right"><font face="Verdana, Arial" size="2"><input type="image" src="images/button_insert.gif" width="70" height="24" alt=" Insert ">&nbsp;&nbsp;&nbsp;&nbsp;<a href="address_book.php"><img src="images/button_cancel.gif" width="72" height="24" border="0" alt=" Back "></a>&nbsp;</font></td>
      </tr>
    </table></form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
<?
  } else {
    $db_query("insert into address_book values ('', '$HTTP_POST_VARS[gender]', '$HTTP_POST_VARS[firstname]', '$HTTP_POST_VARS[lastname]', '$HTTP_POST_VARS[street_address]', '$HTTP_POST_VARS[suburb]', '$HTTP_POST_VARS[postcode]', '$HTTP_POST_VARS[city]', '$HTTP_POST_VARS[state]', '$HTTP_POST_VARS[country]')");
    $insert_id = $db_insert_id();
    $db_query("insert into address_book_to_customers values ('', $insert_id, $customer_id)");

    if ($HTTP_POST_VARS["origin"]) {
      header("Location: " . $HTTP_POST_VARS["origin"] . ".php?" . SID);
    } else {
      header("Location: address_book.php?" . SID);
    }
  }
?>