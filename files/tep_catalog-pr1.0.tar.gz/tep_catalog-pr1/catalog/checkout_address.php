<? include("includes/sysenv.php"); ?>
<?
  if (!session_is_registered("customer_id")) {
    header("Location: create_account.php?origin=checkout_address&" . SID);
  }
?>
<? $page_location = ' : <a href="checkout.php" class="whitelink">Checkout</a> : Delivery Address'; ?>
<html>
<head>
<title>The Exchange Project</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">
<!-- header //-->
<?
  include("includes/header.php");
?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="5" cellpadding="5">
  <tr>
<!-- left_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- categories //-->
<?
  include("includes/boxes/categories.php");
?>
<!-- categories_eof //-->
<!-- whats_new //-->
<?
  include("includes/boxes/whats_new.php");
?>
<!-- whats_new_eof //-->
<!-- search //-->
<?
  include("includes/boxes/search.php");
?>
<!-- search_eof //-->
<!-- add_a_quickie //-->
<?
  include("includes/boxes/add_a_quickie.php");
?>
<!-- add_a_quickie_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- left_navigation_eof //-->
<!-- body_text //-->
    <td width="100%" valign="top"><form name="deliver_to" <? echo 'action="checkout_payment.php?' . SID . '"'; ?> method="post"><table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="2" class="boxborder">
          <tr>
            <td bgcolor="#AABBDD" width="100%"><font face="Verdana, Arial" size="2" color="#000000">&nbsp;Checkout Procedure&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td><font face="Verdana, Arial" size="4">&nbsp;Product Delivery&nbsp;</font></td>
            <td align="right">&nbsp;<img src="images/table_background_delivery.gif" width="85" height="60" border="0" alt="">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
      </tr>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td><font face="Verdana, Arial" size="2"><b>&nbsp;My Address&nbsp;</b></font></td>
                <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Deliver To&nbsp;</b></font></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  if (session_is_registered("customer_id")) {
    $address = $db_query("select customers_firstname, customers_lastname, customers_street_address, customers_suburb, customers_postcode, customers_city, customers_state, customers_country from customers where customers_id = $customer_id");
    $address_values = $db_fetch_array($address);
?>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["customers_firstname"] . ' ' . $address_values["customers_lastname"]; ?>&nbsp;</font></td>
                  </tr>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["customers_street_address"]; ?>&nbsp;</font></td>
                  </tr>
<?
    if ($address_values["customers_suburb"] != "") {
?>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["customers_suburb"]; ?>&nbsp;</font></td>
                  </tr>
<?
  }
?>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["customers_city"] . ', ' . $address_values["customers_postcode"]; ?>&nbsp;</font></td>
                  </tr>
<?
    if ($address_values["customers_state"] != "") {
?>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["customers_state"] . ', ' . $address_values["customers_country"]; ?>&nbsp;</font></td>
                  </tr>
<?
    } else {
?>
                  <tr>
                    <td><font face="Verdana, Arial" size="2">&nbsp;<? echo $address_values["customers_country"]; ?>&nbsp;</font></td>
                  </tr>
<?
    }
?>
                </table></td>
                <td align="right" valign="middle"><font face="Verdana, Arial" size="2">&nbsp;<input type="radio" name="sendto" value="0" CHECKED>&nbsp;</font></td>
              </tr>
            </table></td>
          </tr>
<?
  } elseif (session_is_registered("nonsess_cart")) {
  }
?>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td><font face="Verdana, Arial" size="2"><b>&nbsp;Address Book&nbsp;</b></font></td>
                <td align="right"><font face="Verdana, Arial" size="2"><b>&nbsp;Deliver To&nbsp;</b></font></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
<?
  $address_book = $db_query("select address_book.address_book_id, address_book.entry_firstname, address_book.entry_lastname, address_book.entry_street_address, address_book.entry_suburb, address_book.entry_postcode, address_book.entry_city, address_book.entry_state, address_book.entry_country from address_book, address_book_to_customers where address_book_to_customers.customers_id = $customer_id and address_book_to_customers.address_book_id = address_book.address_book_id order by address_book.address_book_id");
  if (!$db_num_rows($address_book)) {
?>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;Your Address Book has currently no entries!&nbsp;</font></td>
          </tr>
<?
  } else {
?>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
<?
    $row = 0;
    while ($address_book_values = $db_fetch_array($address_book)) {
      $row++;
      echo '              <tr>' . "\n";
      echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;0' . $row . '.&nbsp;</font></td>' . "\n";
      echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_firstname"] . ' ' . $address_book_values["entry_lastname"] . '&nbsp;</font></td>' . "\n";
      echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_street_address"] . '&nbsp;</font></td>' . "\n";
      echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_suburb"] . '&nbsp;</font></td>' . "\n";
      echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_city"] . ', ' . $address_book_values["entry_postcode"] . '&nbsp;</font></td>' . "\n";
      if ($address_book_values["entry_state"] != "") {
        echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_state"] . ', ' . $address_book_values["entry_country"] . '&nbsp;</font></td>' . "\n";
      } else {
        echo '                <td nowrap><font face="Verdana, Arial" size="1">&nbsp;' . $address_book_values["entry_country"] . '&nbsp;</font></td>' . "\n";
      }
      echo '                <td nowrap align="right"><font face="Verdana, Arial" size="1">&nbsp;<input type="radio" name="sendto" value="' . $address_book_values["address_book_id"] . '">&nbsp;</font></td>' . "\n";
      echo '              </tr>' . "\n";
    }
?>
            </table></td>
          </tr>
<?
  }
?>
          <tr>
            <td><img src="images/pixel_black.gif" width="100%" height="1" border="0" alt=""></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
              <tr>
<?
  if ($row < 5) {
    echo '                <td><font face="Verdana, Arial" size="2">&nbsp;<a href="address_book_add.php?origin=checkout_address"><img src="images/button_add_entry.gif" width="113" height="24" border="0" alt=" Add Entry "></a>&nbsp;</font></td>' . "\n";
  } else {
    echo '                <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>' . "\n";
  }
?>
                <td align="right"><font face="Verdana, Arial" size="2">&nbsp;<input type="image" src="images/button_next.gif" width="50" height="24" border="0" alt=" Next ">&nbsp;</font></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td><font face="Verdana, Arial" size="2">&nbsp;</font></td>
          </tr>
          <tr>
            <td align="right"><font face="Verdana, Arial" size="1" color="#AABBDD">&nbsp;[ cart contents | <font color="#000000">delivery address</font> | payment method | confirmation | finished! ]&nbsp;</font></td>
          </tr>
        </table></td>
      </tr>
    </table></form></td>
<!-- body_text_eof //-->
<!-- right_navigation //-->
    <td width="125" valign="top"><table border="0" width="125" cellspacing="0" cellpadding="0">
      <tr>
        <td width="125"><table border="0" width="100%" cellspacing="0" cellpadding="2">
<!-- specials //-->
<?
  include("includes/boxes/specials.php");
?>
<!-- specials_eof //-->
<!-- newest_review //-->
<?
  include("includes/boxes/newest_review.php");
?>
<!-- newest_review_eof //-->
<!-- shopping_cart //-->
<?
  include("includes/boxes/shopping_cart.php");
?>
<!-- shopping_cart_eof //-->
        </table></td>
      </tr>
    </table></td>
<!-- right_navigation_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?
  include("includes/footer.php");
?>
<!-- footer_eof //-->
<br>
</body>
</html>
